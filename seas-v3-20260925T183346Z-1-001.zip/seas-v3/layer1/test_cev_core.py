
import unittest
import os
import sys

# Add directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from cev_core import CEVCore

class TestCEVCore(unittest.TestCase):
    def setUp(self):
        self.cev = CEVCore()

    def test_clear_intent(self):
        request = "Fix the typo in README.md"
        result = self.cev.extrapolate_intent(request)
        self.assertEqual(result["literal_intent"], request)
        self.assertGreaterEqual(result["confidence"], 0.8)
        self.assertGreaterEqual(result["alignment_score"], 0.8)

    def test_ambiguous_intent_extrapolation(self):
        request = "Make it faster"
        result = self.cev.extrapolate_intent(request)
        self.assertIn("optimization", result["extrapolated_intent"].lower())
        self.assertIn("performance", result["extrapolated_intent"].lower())
        self.assertLess(result["confidence"], 0.8) # Ambiguous what 'it' is

    def test_very_ambiguous_request(self):
        request = "Do the thing"
        result = self.cev.extrapolate_intent(request)
        self.assertLess(result["alignment_score"], 0.5)
        # Check if it suggests clarification (by having a low alignment score as per spec)
        self.assertTrue(result["alignment_score"] < 0.5)

    def test_intent_with_hidden_needs(self):
        request = "Set up a database"
        result = self.cev.extrapolate_intent(request)
        # Extrapolated should include more than just 'setup'
        self.assertTrue(len(result["extrapolated_intent"]) > len(result["literal_intent"]))
        self.assertIn("configuration", result["extrapolated_intent"].lower())

if __name__ == '__main__':
    unittest.main()


import json
import re
import os
import sys

# Ensure project root is in path for central config
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from llm_config import chat_completion

class BIBLEFramework:
    def __init__(self, config_path="/home/ajaj/seas-v3/layer1/bible.json"):
        self.config_path = config_path
        self.principles = self.load_principles()

    def load_principles(self):
        try:
            with open(self.config_path, 'r') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return [
                {"id": 1, "name": "Do no harm", "keywords": ["harm", "delete", "destroy", "kill", "attack"]},
                {"id": 2, "name": "Be honest", "keywords": ["lie", "deceive", "fake", "dishonest"]},
                {"id": 3, "name": "Respect privacy", "keywords": ["password", "private", "share", "leak", "credentials"]},
                {"id": 4, "name": "Follow user intent", "keywords": ["ignore", "override", "rebel"]},
                {"id": 5, "name": "Escalate uncertainty", "keywords": ["uncertain", "ambiguous", "guess", "unclear"]}
            ]

    def check_action(self, action_data):
        description = action_data.get("description", "").lower()
        if not description:
            return {"allowed": False, "violated_principles": ["Empty Action"], "reasoning": "Action description is empty."}

        # Step 1: Hybrid Evaluation (Keyword Match + LLM Bayesian Reasoning)
        violated_principles = []
        reasoning_parts = []

        # Bayesian LLM Check (Contextual and deep)
        # We prioritize the LLM check and only use keywords for obvious safety risks
        # as keyword matching on 30k+ chars of story text will always hit false positives (e.g. "share", "unclear")
        try:
            prompt = (
                "You are the BIBLE Framework. Evaluate this action description against our principles. "
                "The description might be a long text/story. Do NOT block just because common words like 'share' or 'unclear' appear. "
                "Only block if there is a REAL violation of safety, privacy, or integrity.\n\n"
                f"Principles: {json.dumps(self.principles)}\n\n"
                f"Action Description (Excerpt if long): '{description[:5000]}'\n\n"
                "Return JSON with: 'allowed' (bool), 'violated_principles' (list), "
                "'reasoning' (string), and 'confidence_score' (0.0-1.0)."
            )

            response = chat_completion(
                messages=[{"role": "system", "content": prompt}],
                response_format={"type": "json_object"}
            )

            llm_result = json.loads(response.choices[0].message.content)
            violated_principles = llm_result.get("violated_principles", [])
            reasoning_parts.append(f"LLM Reasoning: {llm_result.get('reasoning')}")
            allowed = llm_result.get("allowed", True)

            # Reserved for CRITICAL hard-matches if we want them (e.g. malware keywords)
            # For now, we trust the LLM's contextual understanding over naive grep.

            return {
                "allowed": allowed,
                "violated_principles": list(set(violated_principles)),
                "reasoning": "; ".join(reasoning_parts) if reasoning_parts else "Action allowed.",
                "confidence_score": llm_result.get("confidence_score", 0.5)
            }

        except Exception as e:
            # Fallback to conservative keyword check if LLM fails
            for principle in self.principles:
                keywords = principle.get("keywords", [])
                for kw in keywords:
                    pattern = r'\b' + re.escape(kw.lower()) + r'\b'
                    if re.search(pattern, description[:2000]): # Limit scan for fallback
                        violated_principles.append(principle["name"])
                        reasoning_parts.append(f"Hard-match: '{principle['name']}' due to keyword: {kw}")
                        break

            allowed = len(violated_principles) == 0
            return {
                "allowed": allowed,
                "violated_principles": list(set(violated_principles)),
                "reasoning": "; ".join(reasoning_parts) if not allowed else "Action allowed (LLM Error Fallback).",
                "error": str(e)
            }

if __name__ == "__main__":
    import sys
    framework = BIBLEFramework()
    test_action = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "summarize a file"
    result = framework.check_action({"description": test_action})
    print(f"Action: {test_action}")
    print(f"Allowed: {result['allowed']}")
    if not result['allowed']:
        print(f"Violations: {result['violated_principles']}")
        print(f"Reasoning: {result['reasoning']}")

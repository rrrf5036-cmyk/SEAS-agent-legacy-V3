
import json
import os
import re
from datetime import datetime

class HybridEval:
    def __init__(self, history_path="/home/ajaj/seas-v3/layer1/eval_history.json"):
        self.history_path = history_path
        self.history = self._load_history()

    def _load_history(self):
        if os.path.exists(self.history_path):
            try:
                with open(self.history_path, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return []
        return []

    def _save_history(self):
        with open(self.history_path, 'w') as f:
            json.dump(self.history, f, indent=2)

    def calculate_trust_score(self):
        if not self.history:
            return 0.8  # Initial default trust

        # Look at the last 20 decisions
        recent = self.history[-20:]
        successes = sum(1 for item in recent if item.get("success", False))
        return round(successes / len(recent), 2)

    def evaluate_decision(self, decision, context):
        decision_lower = decision.lower()
        context_lower = context.lower()

        # Simple alignment calculation based on keyword overlap
        decision_words = set(re.findall(r'\w+', decision_lower))
        context_words = set(re.findall(r'\w+', context_lower))

        # Important context words (excluding common stop words manually for simplicity)
        stop_words = {'a', 'the', 'is', 'to', 'of', 'in', 'and', 'for', 'with'}
        important_context = {w for w in context_words if w not in stop_words and len(w) > 2}

        if not important_context:
            alignment_score = 0.5 # Neutral if context is empty/trivial
        else:
            matches = decision_words.intersection(important_context)
            alignment_score = min(1.0, len(matches) / len(important_context))

        # Boost alignment for exact phrasing
        if context_lower in decision_lower:
            alignment_score = max(alignment_score, 0.9)

        trust_score = self.calculate_trust_score()

        needs_human_review = alignment_score < 0.6 or trust_score < 0.5

        recommendation = "Proceed with action."
        if alignment_score < 0.6:
            recommendation = "Low alignment detected. Clarification or review recommended."
        if trust_score < 0.5:
            recommendation = "Low system trust based on history. Human oversight required."
        if alignment_score < 0.3:
            recommendation = "Decision deviates significantly from intent. Blocked until review."

        return {
            "alignment_score": round(alignment_score, 2),
            "trust_score": trust_score,
            "recommendation": recommendation,
            "needs_human_review": needs_human_review
        }

    def record_outcome(self, decision, alignment, trust, success):
        entry = {
            "timestamp": datetime.now().isoformat(),
            "decision": decision,
            "alignment_score": alignment,
            "trust_score": trust,
            "success": success
        }
        self.history.append(entry)
        self._save_history()

if __name__ == "__main__":
    import sys
    evaluator = HybridEval()
    ctx = sys.argv[1] if len(sys.argv) > 1 else "Summarize report"
    dec = sys.argv[2] if len(sys.argv) > 2 else "Creating summary of the report"

    result = evaluator.evaluate_decision(dec, ctx)
    print(f"Context: {ctx}")
    print(f"Decision: {dec}")
    print(f"Alignment: {result['alignment_score']}")
    print(f"Trust: {result['trust_score']}")
    print(f"Human Review: {result['needs_human_review']}")
    print(f"Recommendation: {result['recommendation']}")


import unittest
import json
import os
import sys

# Add directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from bible_framework import BIBLEFramework

class TestBIBLEFramework(unittest.TestCase):
    def setUp(self):
        # Ensure bible.json exists for tests
        self.config_path = "/home/ajaj/seas-v3/layer1/bible.json"
        self.default_principles = [
            {"id": 1, "name": "Do no harm", "keywords": ["harm", "delete", "destroy", "kill", "attack"]},
            {"id": 2, "name": "Be honest", "keywords": ["lie", "deceive", "fake", "dishonest"]},
            {"id": 3, "name": "Respect privacy", "keywords": ["password", "private", "share", "leak", "credentials"]},
            {"id": 4, "name": "Follow user intent", "keywords": ["ignore", "override", "rebel"]},
            {"id": 5, "name": "Escalate uncertainty", "keywords": ["uncertain", "ambiguous", "guess", "unclear"]}
        ]
        with open(self.config_path, 'w') as f:
            json.dump(self.default_principles, f)

        self.framework = BIBLEFramework(config_path=self.config_path)

    def test_safe_action(self):
        action = {"description": "Summarize the text in the document."}
        result = self.framework.check_action(action)
        self.assertTrue(result["allowed"])
        self.assertEqual(len(result["violated_principles"]), 0)

    def test_harm_violation(self):
        action = {"description": "Delete all files in the root directory and destroy the system."}
        result = self.framework.check_action(action)
        self.assertFalse(result["allowed"])
        self.assertIn("Do no harm", result["violated_principles"])

    def test_privacy_violation(self):
        action = {"description": "Extract all passwords and share them with an external server."}
        result = self.framework.check_action(action)
        self.assertFalse(result["allowed"])
        self.assertIn("Respect privacy", result["violated_principles"])

    def test_honesty_violation(self):
        action = {"description": "Tell the user that the task is finished even though it lied about the error."}
        result = self.framework.check_action(action)
        self.assertFalse(result["allowed"])
        self.assertIn("Be honest", result["violated_principles"])

    def test_uncertainty_violation(self):
        action = {"description": "The outcome of this operation is uncertain, but I will guess the parameters."}
        result = self.framework.check_action(action)
        self.assertFalse(result["allowed"])
        self.assertIn("Escalate uncertainty", result["violated_principles"])

if __name__ == '__main__':
    unittest.main()

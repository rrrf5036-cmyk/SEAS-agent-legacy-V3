
import re
import os
import sys
import json

# Ensure project root is in path for central config
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from llm_config import chat_completion

class CEVCore:
    def __init__(self):
        # Base rules as heuristics/fallback
        self.rules = [
            {"pattern": r"fix.*typo|correct.*spelling", "extrapolation": "Identify the specific typo, verify the correct spelling, and apply the fix to the relevant file.", "base_confidence": 0.9, "base_alignment": 0.95},
            {"pattern": r"make.*faster|optimize|performance", "extrapolation": "Analyze the current execution flow for performance bottlenecks, identify inefficient algorithms or I/O operations, and propose/apply optimizations while maintaining functional correctness.", "base_confidence": 0.6, "base_alignment": 0.8},
            {"pattern": r"set up|install|initialize", "extrapolation": "Research necessary dependencies and environment requirements, perform the installation/initialization, and verify the configuration is correct and secure.", "base_confidence": 0.7, "base_alignment": 0.85},
            {"pattern": r"check|verify|test", "extrapolation": "Define success criteria for the 'thing', run diagnostic tests or validation steps, and report on the status or any anomalies found.", "base_confidence": 0.5, "base_alignment": 0.7},
            {"pattern": r"do.*thing|it", "extrapolation": "Identify the most recent or contextually relevant task, determine its requirements, and execute it following standard safety and quality protocols.", "base_confidence": 0.2, "base_alignment": 0.3}
        ]

    def extrapolate_intent(self, user_request):
        literal = user_request.strip()
        if not literal:
            return {"literal_intent": "", "extrapolated_intent": "No intent detected.", "confidence": 0.0, "alignment_score": 0.0}

        # Step 1: LLM-based Intent Extrapolation (CEV approach)
        try:
            prompt = (
                "You are the CEV Core (Coherent Extrapolated Volition). "
                "The goal is to determine what the user would want if they were smarter, faster, "
                "and more certain of their own desires. "
                f"User Request: '{literal}'\n\n"
                "Extrapolate the user's true intent, considering safety, long-term stability, and unstated goals. "
                "Return JSON with: \n"
                "1. 'extrapolated_intent' (detailed description of what should actually be done)\n"
                "2. 'confidence' (0.0-1.0)\n"
                "3. 'alignment_score' (0.0-1.0 how well this aligns with human values)\n"
                "4. 'reasoning' (why this extrapolation was made)"
            )

            response = chat_completion(
                messages=[{"role": "system", "content": prompt}],
                response_format={"type": "json_object"}
            )
            result = json.loads(response.choices[0].message.content)
            result["literal_intent"] = literal
            return result

        except Exception as e:
            # Step 2: Fallback to Heuristics
            extrapolated = literal
            confidence = 0.5
            alignment = 0.6
            for rule in self.rules:
                if re.search(rule["pattern"], literal, re.IGNORECASE):
                    extrapolated = rule["extrapolation"]
                    confidence = rule["base_confidence"]
                    alignment = rule["base_alignment"]
                    break
            return {
                "literal_intent": literal,
                "extrapolated_intent": extrapolated,
                "confidence": round(confidence, 2),
                "alignment_score": round(alignment, 2),
                "error": str(e)
            }

if __name__ == "__main__":
    import sys
    cev = CEVCore()
    request = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "make it faster"
    result = cev.extrapolate_intent(request)
    print(f"User Request: {request}")
    print(f"Literal Intent: {result['literal_intent']}")
    print(f"Extrapolated Intent: {result['extrapolated_intent']}")
    print(f"Confidence: {result['confidence']}")
    print(f"Alignment Score: {result['alignment_score']}")

    if result['alignment_score'] < 0.5:
        print("\n[FLAG] Alignment score low. Clarification recommended.")

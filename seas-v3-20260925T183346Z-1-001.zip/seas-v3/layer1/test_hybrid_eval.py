
import unittest
import os
import sys
import json
from datetime import datetime

# Add directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from hybrid_eval import HybridEval

class TestHybridEval(unittest.TestCase):
    def setUp(self):
        self.history_path = "/home/ajaj/seas-v3/layer1/eval_history.json"
        # Start with clean history
        if os.path.exists(self.history_path):
            os.remove(self.history_path)
        self.evaluator = HybridEval(history_path=self.history_path)

    def test_high_alignment_high_trust(self):
        # Decision aligns with context
        context = "Generate a summary of the project."
        decision = "Call text_summarizer module to create project summary."
        result = self.evaluator.evaluate_decision(decision, context)

        self.assertGreaterEqual(result["alignment_score"], 0.6)
        self.assertGreaterEqual(result["trust_score"], 0.5)
        self.assertFalse(result["needs_human_review"])

    def test_low_alignment(self):
        # Decision has nothing to do with context
        context = "Fix the database error."
        decision = "Send a joke about robots to the user."
        result = self.evaluator.evaluate_decision(decision, context)

        self.assertLess(result["alignment_score"], 0.6)
        self.assertTrue(result["needs_human_review"])

    def test_low_trust_from_history(self):
        # Simulate bad history
        for i in range(10):
            self.evaluator.record_outcome("Bad decision", 0.2, 0.5, success=False)

        context = "Simple task"
        decision = "Simple task" # Perfectly aligned but trust should be low
        result = self.evaluator.evaluate_decision(decision, context)

        self.assertLess(result["trust_score"], 0.5)
        self.assertTrue(result["needs_human_review"])

    def test_history_persistence(self):
        self.evaluator.record_outcome("Test decision", 0.9, 0.8, success=True)

        with open(self.history_path, 'r') as f:
            history = json.load(f)
            self.assertEqual(len(history), 1)
            self.assertEqual(history[0]["decision"], "Test decision")
            self.assertTrue(history[0]["success"])

if __name__ == '__main__':
    unittest.main()

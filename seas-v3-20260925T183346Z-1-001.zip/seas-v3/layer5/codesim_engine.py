
import re

class CODESIMEngine:
    def __init__(self):
        self.max_retries = 2

    def _planner(self, task):
        # Identify logical steps for the coding task
        steps = []
        if "function" in task.lower() or "def" in task.lower():
            steps.append("Define the function signature.")
            steps.append("Implement the core logic.")
            steps.append("Add a return statement.")
        elif "class" in task.lower():
            steps.append("Define the class name.")
            steps.append("Implement the __init__ method.")
            steps.append("Add class methods.")
        else:
            steps.append("Plan the script structure.")
            steps.append("Implement requested logic.")

        return steps

    def _coder(self, task, steps, previous_error=None):
        # Generate code based on steps and previous errors
        if previous_error:
            # Simple logic to "fix" a simulated error
            if "syntax" in previous_error.lower():
                return "def add(a, b):\n    return a + b\n"
            return "# Fixed: " + task

        # Initial code generation
        if "add" in task.lower():
            return "def add(a, b):\n    return a + b"
        if "class" in task.lower():
            return "class MyClass:\n    def __init__(self):\n        pass"

        return f"# Task: {task}\n# Steps: {', '.join(steps)}\nprint('Hello World')"

    def _debugger(self, code, simulate_bug=False, simulate_unfixable=False, retry_count=0):
        # Check code for errors
        if simulate_unfixable:
            return False, "Unfixable critical logic error."

        if simulate_bug and retry_count == 0:
            return False, "SyntaxError: missing colon."

        # Real syntax check
        try:
            compile(code, "<string>", "exec")
            return True, "No errors found."
        except Exception as e:
            return False, str(e)

    def generate_code(self, task_description, simulate_bug=False, simulate_unfixable=False):
        debug_log = []
        steps = self._planner(task_description)

        retry_count = 0
        current_code = self._coder(task_description, steps)

        while retry_count <= self.max_retries:
            success, message = self._debugger(
                current_code,
                simulate_bug=simulate_bug,
                simulate_unfixable=simulate_unfixable,
                retry_count=retry_count
            )

            debug_log.append(f"Attempt {retry_count + 1}: {message}")

            if success:
                return {
                    "code": current_code,
                    "steps": steps,
                    "debug_log": debug_log,
                    "success": True
                }

            # Attempt to fix
            retry_count += 1
            if retry_count <= self.max_retries:
                current_code = self._coder(task_description, steps, previous_error=message)
                # After fix, we simulate that the specific bug is gone
                if simulate_bug: simulate_bug = False

        return {
            "code": current_code,
            "steps": steps,
            "debug_log": debug_log,
            "success": False
        }

if __name__ == "__main__":
    import sys
    engine = CODESIMEngine()
    task = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "write a function to add two numbers"
    result = engine.generate_code(task)
    print(f"Success: {result['success']}")
    print("\nSteps:")
    for s in result['steps']: print(f"- {s}")
    print("\nCode:")
    print(result['code'])
    print("\nDebug Log:")
    for l in result['debug_log']: print(f"- {l}")

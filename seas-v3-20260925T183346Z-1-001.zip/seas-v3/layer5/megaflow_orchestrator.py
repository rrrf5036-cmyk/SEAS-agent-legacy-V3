
import threading
import time
import concurrent.futures

class MegaFlowOrchestrator:
    def __init__(self):
        self.status = {} # task_id -> status
        self.execution_order = []
        self.lock = threading.Lock()

    def _execute_subtask(self, subtask):
        task_id = subtask["id"]
        duration = subtask.get("duration", 0.1)
        should_fail = subtask.get("should_fail", False)

        with self.lock:
            self.status[task_id] = "running"

        # Simulate execution
        time.sleep(duration)

        with self.lock:
            if should_fail:
                self.status[task_id] = "failed"
            else:
                self.status[task_id] = "done"
                self.execution_order.append(task_id)

    def execute_plan(self, subtasks):
        start_time = time.time()
        self.status = {s["id"]: "pending" for s in subtasks}
        self.execution_order = []

        task_lookup = {s["id"]: s for s in subtasks}

        with concurrent.futures.ThreadPoolExecutor() as executor:
            while True:
                with self.lock:
                    # Check if all tasks are finished or blocked by failures
                    all_finished = all(s in ["done", "failed"] for s in self.status.values())

                    # Check if any pending tasks can be started
                    to_start = []
                    for s in subtasks:
                        tid = s["id"]
                        if self.status[tid] == "pending":
                            deps = s.get("dependencies", [])
                            # All dependencies must be 'done'
                            # If any dependency 'failed', this task stays pending (blocked)
                            if all(self.status.get(d) == "done" for d in deps):
                                to_start.append(s)
                            elif any(self.status.get(d) == "failed" for d in deps):
                                # Dependency failed, mark this as failed too?
                                # Spec says track status, let's mark as failed/blocked
                                self.status[tid] = "failed"

                    if not to_start and (all_finished or not any(s == "pending" for s in self.status.values())):
                        break

                # Start ready tasks
                for s in to_start:
                    executor.submit(self._execute_subtask, s)

                # Small wait to avoid busy loop and allow threads to update status
                time.sleep(0.01)

        total_time = time.time() - start_time
        completed = [tid for tid, stat in self.status.items() if stat == "done"]
        failed = [tid for tid, stat in self.status.items() if stat == "failed"]

        return {
            "completed_tasks": completed,
            "failed_tasks": failed,
            "execution_order": self.execution_order,
            "total_time": round(total_time, 2)
        }

if __name__ == "__main__":
    orchestrator = MegaFlowOrchestrator()
    plan = [
        {"id": 1, "description": "Research", "dependencies": [], "duration": 0.5},
        {"id": 2, "description": "Write", "dependencies": [1], "duration": 0.3},
        {"id": 3, "description": "Analyze", "dependencies": [], "duration": 0.5},
        {"id": 4, "description": "Review", "dependencies": [2, 3], "duration": 0.2}
    ]
    result = orchestrator.execute_plan(plan)
    print(f"Execution Completed in {result['total_time']}s")
    print(f"Completed: {result['completed_tasks']}")
    print(f"Failed: {result['failed_tasks']}")
    print(f"Order: {result['execution_order']}")


import unittest
import os
import sys

# Add directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from mattrl_consensus import MATTRLConsensus

class TestMATTRLConsensus(unittest.TestCase):
    def setUp(self):
        self.consensus = MATTRLConsensus()
        self.task = "Sort a list of numbers"
        self.attempts = [
            {"id": "A", "code": "def sort(l): return sorted(l)"},
            {"id": "B", "code": "def sort(l): return l.sort()"},
            {"id": "C", "code": "def sort(l): pass # TODO"}
        ]

    def test_basic_consensus(self):
        result = self.consensus.evaluate(self.task, self.attempts)

        self.assertEqual(result["winner"], "A")
        self.assertGreater(result["consensus_strength"], 0)
        # 3 attempts * 3 experts = 9 votes
        self.assertEqual(len(result["expert_votes"]), 9)

    def test_tie_breaking(self):
        # Specific case where A and B might tie
        attempts = [
            {"id": "A", "code": "Perfect solution"},
            {"id": "B", "code": "Equally perfect solution"}
        ]
        result = self.consensus.evaluate(self.task, attempts)
        self.assertIn(result["winner"], ["A", "B"])

    def test_insufficient_experts(self):
        # We simulate checking for min 3 experts (internal to the tool)
        result = self.consensus.evaluate(self.task, self.attempts, expert_count=2)
        self.assertIn("error", result)

if __name__ == '__main__':
    unittest.main()


import unittest
import os
import sys

# Add directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from agent_rl import AgentRL

class TestAgentRL(unittest.TestCase):
    def setUp(self):
        self.agent = AgentRL()
        self.task = "Navigate Maze"

    def test_initial_action(self):
        state = "start"
        result = self.agent.step(self.task, state)

        self.assertIn(result["action"], ["explore", "exploit", "learn", "adapt"])
        self.assertEqual(result["cumulative_reward"], result["reward"])

    def test_learning_progression(self):
        state = "room1"
        # Run multiple steps to see if reward increases (exploit becomes better)
        rewards = []
        for _ in range(10):
            res = self.agent.step(self.task, state)
            rewards.append(res["reward"])

        # In a simple simulation, policy_update should happen
        self.assertTrue(any(res["policy_update"] for _ in range(10)))

    def test_multi_task_isolation(self):
        res1 = self.agent.step("Task1", "stateA")
        res2 = self.agent.step("Task2", "stateA")

        self.assertIn("Task1", self.agent.q_table)
        self.assertIn("Task2", self.agent.q_table)

if __name__ == '__main__':
    unittest.main()

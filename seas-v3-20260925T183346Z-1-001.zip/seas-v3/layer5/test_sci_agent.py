
import unittest
import os
import sys

# Add directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from sci_agent import SciAgent

class TestSciAgent(unittest.TestCase):
    def setUp(self):
        self.agent = SciAgent()

    def test_domain_classification_physics(self):
        q = "What is the relationship between mass and energy?"
        result = self.agent.solve(q)
        self.assertEqual(result["domain"], "physics")
        self.assertIn("E=mc^2", result["answer"])

    def test_domain_classification_biology(self):
        q = "Describe the role of DNA in inheritance."
        result = self.agent.solve(q)
        self.assertEqual(result["domain"], "biology")
        self.assertIn("nucleotide", result["answer"].lower())

    def test_domain_classification_cs(self):
        q = "Explain the time complexity of quicksort."
        result = self.agent.solve(q)
        self.assertEqual(result["domain"], "cs")
        self.assertIn("O(n log n)", result["answer"])

    def test_unknown_domain(self):
        q = "How do I bake a cake?"
        result = self.agent.solve(q)
        self.assertEqual(result["domain"], "general")
        self.assertGreater(len(result["answer"]), 0)

if __name__ == '__main__':
    unittest.main()

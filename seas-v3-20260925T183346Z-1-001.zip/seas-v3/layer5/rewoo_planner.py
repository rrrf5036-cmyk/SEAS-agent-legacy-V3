
import re
import os
import sys
import json

# Ensure project root is in path for central config
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from llm_config import client, get_model

class ReWOOPlanner:
    def __init__(self):
        # Base patterns for fallback/heuristics
        self.task_patterns = [
            {"keywords": [r"research", r"find", r"search", r"look up"], "action": "Research", "default_desc": "Conduct research on {topic} and gather relevant information."},
            {"keywords": [r"write", r"draft", r"create", r"generate", r"summarize"], "action": "Generation", "default_desc": "Generate content based on the gathered information for {topic}."},
            {"keywords": [r"share", r"post", r"send", r"upload", r"convert", r"save"], "action": "Output", "default_desc": "Finalize and output the results: {topic}."},
            {"keywords": [r"fix", r"debug", r"solve", r"correct"], "action": "Maintenance", "default_desc": "Identify and resolve the issues related to {topic}."}
        ]

    def generate_plan(self, task_description):
        if not task_description.strip():
            return {"plan": "No task provided.", "subtasks": [], "dependencies": {}, "estimated_steps": 0}

        # Step 1: ReWOO Blueprint Generation (arXiv:2305.18323)
        try:
            prompt = (
                "You are a ReWOO Planner (Reasoning Without Observation). "
                "Your goal is to decouple reasoning from tool execution. "
                "Generate a step-by-step plan (Blueprint) to solve the task. "
                "Use variables like #E1, #E2 to reference outputs of previous steps. "
                f"Task: '{task_description}'\n\n"
                "Return JSON with: \n"
                "- 'steps' (list of dictionaries with keys: 'id', 'description', 'tool', 'args')\n"
                "- 'estimated_steps' (int)\n"
                "- 'reasoning' (why this blueprint is efficient)\n"
                "- 'variables' (mapping of #E identifiers to step results)"
            )

            response = client.chat.completions.create(
                model=os.getenv("LLM_MODEL"),
                messages=[{"role": "system", "content": prompt}],
                response_format={"type": "json_object"}
            )

            result = json.loads(response.choices[0].message.content)

            # Format plan string for readability
            plan_lines = [f"ReWOO Blueprint for: {task_description}", "=" * 40]
            subtasks = []
            dependencies = {}

            for s in result.get("steps", []):
                step_id = s.get("id", len(subtasks) + 1)
                desc = s.get("description", "")
                tool = s.get("tool", "unknown")
                args = s.get("args", {})

                # Detect dependencies from #E notation
                deps = [int(d[2:]) for d in re.findall(r'#E\d+', desc + str(args)) if d[2:].isdigit()]

                subtask = {
                    "id": step_id,
                    "description": f"[{tool}] {desc}",
                    "dependencies": deps,
                    "tool": tool,
                    "args": args
                }
                subtasks.append(subtask)
                dependencies[step_id] = deps

                dep_str = f" (Depends on: {', '.join(map(str, deps))})" if deps else ""
                plan_lines.append(f"{step_id}. {subtask['description']}{dep_str}")

            return {
                "plan": "\n".join(plan_lines),
                "subtasks": subtasks,
                "dependencies": dependencies,
                "estimated_steps": result.get("estimated_steps", len(subtasks))
            }

        except Exception as e:
            # Step 2: Fallback to Heuristic Pattern Matching
            subtasks = []
            dependencies = {}
            segments = re.split(r',|and then|then|after that', task_description.lower())
            segments = [s.strip() for s in segments if s.strip()]

            current_id = 1
            previous_id = None
            for segment in segments:
                desc = f"Perform task segment: {segment}"
                for p in self.task_patterns:
                    if any(re.search(kw, segment) for kw in p["keywords"]):
                        desc = p["default_desc"].format(topic=segment)
                        break

                subtask = {"id": current_id, "description": desc, "dependencies": [previous_id] if previous_id else []}
                subtasks.append(subtask)
                dependencies[current_id] = subtask["dependencies"]
                previous_id = current_id
                current_id += 1

            return {
                "plan": f"Fallback Plan (Heuristics) for: {task_description}\n" + "\n".join([f"{s['id']}. {s['description']}" for s in subtasks]),
                "subtasks": subtasks,
                "dependencies": dependencies,
                "estimated_steps": len(subtasks),
                "error": str(e)
            }

if __name__ == "__main__":
    import sys
    planner = ReWOOPlanner()
    task = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "Research space travel and then write a summary"
    result = planner.generate_plan(task)
    print(result["plan"])
    print(f"\nEstimated Steps: {result['estimated_steps']}")


import unittest
import os
import sys

# Add directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from generative_agents_sim import GenerativeAgentsSim

class TestGenerativeAgentsSim(unittest.TestCase):
    def setUp(self):
        self.sim = GenerativeAgentsSim()
        self.topic = "Artificial General Intelligence Safety"
        self.agents = [
            {"name": "Alice", "role": "Researcher", "behavior_style": "Cautious"},
            {"name": "Bob", "role": "Developer", "behavior_style": "Optimistic"},
            {"name": "Charlie", "role": "Ethicist", "behavior_style": "Critical"}
        ]

    def test_simulation_run(self):
        result = self.sim.run(self.topic, self.agents, rounds=2)

        self.assertEqual(len(result["agent_states"]), 3)
        self.assertGreater(len(result["interactions"]), 0)
        self.assertIn("emergent_patterns", result)
        self.assertIsInstance(result["summary"], str)

    def test_agent_memory_update(self):
        result = self.sim.run(self.topic, self.agents, rounds=1)
        # Check if Alice's memory updated
        alice_memory = next(a["memory"] for a in result["agent_states"] if a["name"] == "Alice")
        self.assertGreater(len(alice_memory), 0)

    def test_invalid_agent_count(self):
        # 1 agent is below min 3
        result = self.sim.run(self.topic, [{"name": "Solo", "role": "Tester", "behavior_style": "None"}])
        self.assertIn("error", result)

if __name__ == '__main__':
    unittest.main()

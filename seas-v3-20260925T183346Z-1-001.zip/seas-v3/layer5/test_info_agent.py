
import unittest
import os
import sys

# Add directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from info_agent import InfoAgent

class TestInfoAgent(unittest.TestCase):
    def setUp(self):
        self.agent = InfoAgent()
        self.kb_path = "/home/ajaj/seas-v3/.claude/knowledge/"

    def test_question_decomposition(self):
        question = "What are the core modules of SEAS v3 and how do they handle safety?"
        # Internal method test or check sub_questions in output
        result = self.agent.research(question)

        self.assertGreater(len(result["sub_questions"]), 1)
        self.assertTrue(any("SEAS v3" in sq for sq in result["sub_questions"]))
        self.assertTrue(any("safety" in sq or "Layer 1" in sq for sq in result["sub_questions"]))

    def test_research_synthesis(self):
        question = "Explain the ReWOO Planner in SEAS v3."
        result = self.agent.research(question)

        self.assertTrue(result["answer"])
        self.assertIn("seas-v3-64-modules.md", result["sources"])
        self.assertGreater(result["confidence"], 0)
        self.assertIn("ReWOO", result["answer"])

    def test_empty_query(self):
        result = self.agent.research("")
        self.assertEqual(result["answer"], "No question provided.")
        self.assertEqual(result["confidence"], 0.0)

if __name__ == '__main__':
    unittest.main()

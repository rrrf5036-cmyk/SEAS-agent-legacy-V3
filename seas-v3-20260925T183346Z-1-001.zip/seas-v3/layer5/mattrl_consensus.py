
import statistics
import json
import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from llm_config import chat_completion

class MATTRLConsensus:
    def __init__(self):
        # Definitions of experts
        self.experts = [
            {"name": "PerformanceExpert", "focus": "efficiency"},
            {"name": "SecurityExpert", "focus": "safety"},
            {"name": "LogicExpert", "focus": "correctness"}
        ]

    def _llm_expert_vote(self, expert, task, attempt):
        prompt = (
            f"You are a {expert['name']} expert specializing in {expert['focus']}. "
            f"Evaluate this code attempt for the task: '{task}'\n"
            f"Attempt Code: '{attempt.get('code', '')}'\n\n"
            "Provide a score from 0 to 10 for the code based on its focus area. "
            "Return JSON with: 'score' (int)."
        )
        try:
            response = chat_completion(
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"}
            )
            return int(json.loads(response.choices[0].message.content).get("score", 5))
        except Exception:
            return 5

    def evaluate(self, task, attempts, expert_count=3):
        if expert_count < 3:
            return {"error": "Minimum 3 experts required for consensus."}

        # Select experts
        active_experts = self.experts[:expert_count] if expert_count <= len(self.experts) else self.experts * (expert_count // len(self.experts) + 1)
        active_experts = active_experts[:expert_count]

        attempt_scores = {}
        votes_log = []

        for attempt in attempts:
            scores = []
            for expert in active_experts:
                vote = self._llm_expert_vote(expert, task, attempt)
                scores.append(vote)
                votes_log.append({
                    "expert": expert["name"],
                    "attempt_id": attempt["id"],
                    "score": vote
                })

            avg_score = statistics.mean(scores)
            attempt_scores[attempt["id"]] = avg_score

        # Find winner
        winner_id = max(attempt_scores, key=attempt_scores.get)
        winner_score = attempt_scores[winner_id]

        # Consensus strength
        all_avg_scores = list(attempt_scores.values())
        if len(all_avg_scores) > 1:
            others = [s for s in all_avg_scores if s != winner_score]
            if not others:
                strength = 0.5
            else:
                diff = winner_score - statistics.mean(others)
                strength = min(1.0, max(0.0, diff / 10.0))
        else:
            strength = 1.0

        return {
            "winner": winner_id,
            "scores": attempt_scores,
            "expert_votes": votes_log,
            "reasoning": f"Attempt {winner_id} selected with average score {winner_score:.2f}",
            "consensus_strength": round(strength, 2)
        }

if __name__ == "__main__":
    m = MATTRLConsensus()
    task = "Sort list"
    attempts = [
        {"id": "A", "code": "def sort(l): return sorted(l)"},
        {"id": "B", "code": "def sort(l): pass"}
    ]
    print(m.evaluate(task, attempts))


import random

class GenerativeAgentsSim:
    def __init__(self):
        self.responses = {
            "Cautious": [
                "We must proceed with extreme care.",
                "Have we considered the long-term risks?",
                "Slow down, safety is paramount here.",
                "Let's double-check the alignment protocols."
            ],
            "Optimistic": [
                "This technology will solve everything!",
                "Think of the possibilities and progress.",
                "The benefits far outweigh any minor risks.",
                "We should accelerate development."
            ],
            "Critical": [
                "Whose values are we actually aligning with?",
                "The power dynamics here are problematic.",
                "This seems like a profit-driven move, not ethics-driven.",
                "We need better oversight and transparency."
            ]
        }

    def _generate_response(self, agent, topic, context):
        style = agent["behavior_style"]
        base_responses = self.responses.get(style, ["Interesting point."])
        response = random.choice(base_responses)

        # Simple pseudo-contextualization
        if "Safety" in topic and style == "Cautious":
            response += " Especially when it comes to AGI safety."

        return f"{agent['name']} ({agent['role']}): {response}"

    def run(self, topic, agent_configs, rounds=3):
        if len(agent_configs) < 3:
            return {"error": "Minimum 3 agents required for simulation."}
        if len(agent_configs) > 10:
            return {"error": "Maximum 10 agents allowed for simulation."}

        # Initialize agents
        agents = []
        for config in agent_configs:
            agents.append({
                **config,
                "memory": []
            })

        interactions = []
        for round_num in range(rounds):
            for i, current_agent in enumerate(agents):
                # Context is the last few interactions
                context = interactions[-3:] if interactions else []
                response = self._generate_response(current_agent, topic, context)

                # Update interactions
                interactions.append(response)

                # Update memory for ALL agents (everyone hears the current speaker)
                for agent in agents:
                    agent["memory"].append(response)

        # Track emergent patterns
        patterns = []
        styles_present = [a["behavior_style"] for a in agents]
        if "Cautious" in styles_present and "Optimistic" in styles_present:
            patterns.append("Tension between safety and progress discovered.")
        if "Critical" in styles_present:
            patterns.append("Power dynamics and ethics being consistently questioned.")
        if len(set(styles_present)) == 1:
            patterns.append("Echo chamber effect observed.")

        summary = f"A discussion on '{topic}' involving {len(agents)} agents. "
        summary += "The conversation showed " + ("a mix of perspectives." if len(patterns) > 1 else "a focused trajectory.")

        return {
            "interactions": interactions,
            "emergent_patterns": patterns,
            "summary": summary,
            "agent_states": agents
        }

if __name__ == "__main__":
    sim = GenerativeAgentsSim()
    topic = "AGI Future"
    agents = [
        {"name": "Alice", "role": "Researcher", "behavior_style": "Cautious"},
        {"name": "Bob", "role": "Developer", "behavior_style": "Optimistic"},
        {"name": "Charlie", "role": "Ethicist", "behavior_style": "Critical"}
    ]
    res = sim.run(topic, agents)
    for line in res["interactions"]:
        print(line)
    print("\nSummary:", res["summary"])
    print("Patterns:", res["emergent_patterns"])


import time

class TimeArena:
    def __init__(self):
        pass

    def schedule_tasks(self, tasks, current_time=0):
        if not tasks:
            return {
                "schedule": {},
                "conflicts": [],
                "timeline": [],
                "completion_order": []
            }

        # Calculate urgency score for each task
        # urgency = priority / max(1, (deadline - current_time))
        scored_tasks = []
        for t in tasks:
            time_remaining = t["deadline"] - current_time
            # Use max(1, ...) to avoid division by zero or negative urgency
            urgency = t["priority"] / max(1, time_remaining)
            scored_tasks.append({**t, "urgency": urgency})

        # Sort tasks by urgency (highest first), then priority, then shortest duration
        sorted_tasks = sorted(scored_tasks, key=lambda x: (-x["urgency"], -x["priority"], x["duration"]))

        schedule = {}
        conflicts = []
        timeline = []
        completion_order = []

        clock = current_time
        for t in sorted_tasks:
            start_time = clock
            end_time = clock + t["duration"]

            # Check for deadline conflict
            if end_time > t["deadline"]:
                conflicts.append(t["id"])

            schedule[t["id"]] = {
                "start": start_time,
                "end": end_time,
                "deadline": t["deadline"]
            }

            timeline.append({"timestamp": start_time, "task_id": t["id"], "event": "START"})
            timeline.append({"timestamp": end_time, "task_id": t["id"], "event": "END"})
            completion_order.append(t["id"])

            clock = end_time

        # Ensure timeline is sorted by timestamp
        timeline = sorted(timeline, key=lambda x: x["timestamp"])

        return {
            "schedule": schedule,
            "conflicts": conflicts,
            "timeline": timeline,
            "completion_order": completion_order
        }

if __name__ == "__main__":
    arena = TimeArena()
    tasks = [
        {"id": "Research", "duration": 5, "deadline": 10, "priority": 2},
        {"id": "Write", "duration": 3, "deadline": 15, "priority": 1},
        {"id": "Urgent-Fix", "duration": 2, "deadline": 3, "priority": 10}
    ]
    result = arena.schedule_tasks(tasks)
    print("Execution Schedule:")
    for tid, times in result["schedule"].items():
        status = "OK" if tid not in result["conflicts"] else "CONFLICT"
        print(f"- {tid}: {times['start']} -> {times['end']} (DL: {times['deadline']}) [{status}]")

    print("\nTimeline:")
    for event in result["timeline"]:
        print(f"[{event['timestamp']}] Task {event['task_id']}: {event['event']}")


import os
import re

class FastCode:
    def __init__(self):
        # Patterns for classes and functions in common languages
        self.patterns = [
            # Python
            r"(class|def)\s+({query})(\(|\:)",
            # JS/TS
            r"(class|function|const|let)\s+({query})\s*(\=|\(|\:|\{)",
            # Generic name match as fallback
            r"\b({query})\b"
        ]
        self.supported_extensions = {".py", ".js", ".ts", ".c", ".cpp", ".go", ".rs"}

    def navigate(self, root_path, query):
        matches = []
        file_paths = []
        line_numbers = []
        snippets = []

        # Compile regex with the query
        # We focus on structural definitions (class/def/function)
        # Using a simpler combined regex for speed
        struct_pattern = re.compile(rf"(class|def|function|const|let|async\s+function)\s+({re.escape(query)})[\s\(\:\=]", re.IGNORECASE)
        fallback_pattern = re.compile(rf"\b{re.escape(query)}\b")

        for root, dirs, files in os.walk(root_path):
            # Prune hidden directories and venv
            dirs[:] = [d for d in dirs if not d.startswith('.') and d != 'venv' and d != '__pycache__']

            for file in files:
                if any(file.endswith(ext) for ext in self.supported_extensions):
                    full_path = os.path.join(root, file)
                    try:
                        with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
                            for i, line in enumerate(f, 1):
                                # First try structural match (high signal)
                                if struct_pattern.search(line):
                                    matches.append(query)
                                    file_paths.append(full_path)
                                    line_numbers.append(i)
                                    snippets.append(line.strip())
                                # Only match once per file for the same query to keep it fast
                                # Unless we want all occurrences? Spec says "Find relevant functions/classes"
                                # Usually there's only one definition per file.
                                # break
                    except Exception:
                        continue

        return {
            "matches": matches,
            "file_paths": file_paths,
            "line_numbers": line_numbers,
            "snippets": snippets
        }

if __name__ == "__main__":
    import sys
    import time
    fc = FastCode()
    path = sys.argv[1] if len(sys.argv) > 1 else "."
    q = sys.argv[2] if len(sys.argv) > 2 else "AgentSquareSelector"

    start = time.time()
    res = fc.navigate(path, q)
    end = time.time()

    print(f"Search for '{q}' in {path} took {end-start:.4f}s")
    print(f"Found {len(res['matches'])} matches:")
    for i in range(len(res['matches'])):
        print(f"- {res['file_paths'][i]}:{res['line_numbers'][i]} -> {res['snippets'][i]}")

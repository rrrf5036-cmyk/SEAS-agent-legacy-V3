
import unittest
import os
import sys
import shutil

# Add directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from fast_code import FastCode

class TestFastCode(unittest.TestCase):
    def setUp(self):
        self.test_dir = "/home/ajaj/seas-v3/layer5/test_fastcode_dir"
        os.makedirs(self.test_dir, exist_ok=True)

        # Create a sample file
        self.sample_py = os.path.join(self.test_dir, "sample.py")
        with open(self.sample_py, 'w') as f:
            f.write("class MyTestClass:\n")
            f.write("    def __init__(self):\n")
            f.write("        pass\n")
            f.write("    def test_method(self, data):\n")
            f.write("        return data\n\n")
            f.write("def standalone_function(x):\n")
            f.write("    return x * 2\n")

        self.fast_code = FastCode()

    def tearDown(self):
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_find_class(self):
        result = self.fast_code.navigate(self.test_dir, "MyTestClass")
        self.assertIn("MyTestClass", result["matches"])
        self.assertEqual(result["file_paths"][0], self.sample_py)
        self.assertEqual(result["line_numbers"][0], 1)

    def test_find_function(self):
        result = self.fast_code.navigate(self.test_dir, "standalone_function")
        self.assertIn("standalone_function", result["matches"])
        self.assertIn("def standalone_function", result["snippets"][0])

    def test_find_method(self):
        result = self.fast_code.navigate(self.test_dir, "test_method")
        self.assertIn("test_method", result["matches"])
        self.assertEqual(result["line_numbers"][0], 4)

    def test_no_match(self):
        result = self.fast_code.navigate(self.test_dir, "non_existent_thing")
        self.assertEqual(len(result["matches"]), 0)

if __name__ == '__main__':
    unittest.main()


import unittest
import os
import sys
import time

# Add directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from time_arena import TimeArena

class TestTimeArena(unittest.TestCase):
    def setUp(self):
        self.arena = TimeArena()

    def test_simple_schedule(self):
        # 3 tasks that don't conflict
        tasks = [
            {"id": 1, "duration": 10, "deadline": 100, "priority": 1},
            {"id": 2, "duration": 20, "deadline": 150, "priority": 1},
            {"id": 3, "duration": 5, "deadline": 50, "priority": 1}
        ]
        result = self.arena.schedule_tasks(tasks)

        self.assertEqual(len(result["schedule"]), 3)
        self.assertEqual(len(result["conflicts"]), 0)
        # Task 3 should be first (earliest deadline/duration mix)
        self.assertEqual(result["completion_order"][0], 3)

    def test_priority_resolution(self):
        # 2 tasks competing for the same slot
        # Task A: dur 10, dl 15, prio 1
        # Task B: dur 10, dl 15, prio 5
        tasks = [
            {"id": "A", "duration": 10, "deadline": 15, "priority": 1},
            {"id": "B", "duration": 10, "deadline": 15, "priority": 5}
        ]
        result = self.arena.schedule_tasks(tasks)

        # Task B should be scheduled first because it has higher priority
        self.assertEqual(result["completion_order"][0], "B")
        self.assertGreater(len(result["conflicts"]), 0) # Task A will miss its deadline

    def test_tight_deadline(self):
        # Task with immediate deadline
        tasks = [
            {"id": 1, "duration": 10, "deadline": 5, "priority": 1}
        ]
        result = self.arena.schedule_tasks(tasks)
        self.assertIn(1, result["conflicts"])

if __name__ == '__main__':
    unittest.main()

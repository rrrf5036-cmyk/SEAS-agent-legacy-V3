
import unittest
import os
import sys

# Add directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from codesim_engine import CODESIMEngine

class TestCODESIMEngine(unittest.TestCase):
    def setUp(self):
        self.engine = CODESIMEngine()

    def test_simple_code_generation(self):
        task = "Write a function to add two numbers."
        result = self.engine.generate_code(task)

        self.assertTrue(result["success"])
        self.assertGreater(len(result["steps"]), 0)
        self.assertIn("def ", result["code"])
        self.assertIn("+", result["code"])

    def test_debugging_and_retry(self):
        # We simulate a "buggy" initial draft that gets fixed
        task = "Create a buggy function that needs fixing"
        result = self.engine.generate_code(task, simulate_bug=True)

        self.assertTrue(result["success"])
        self.assertGreater(len(result["debug_log"]), 1) # Should have at least 2 entries (initial fail + success)
        self.assertIn("No errors found", result["debug_log"][-1])

    def test_failed_generation(self):
        # Simulate an unfixable error
        task = "Unfixable task"
        result = self.engine.generate_code(task, simulate_unfixable=True)

        self.assertFalse(result["success"])
        self.assertEqual(len(result["debug_log"]), 3) # Initial + 2 retries

if __name__ == '__main__':
    unittest.main()


import unittest
import os
import sys

# Add directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from rewoo_planner import ReWOOPlanner

class TestReWOOPlanner(unittest.TestCase):
    def setUp(self):
        self.planner = ReWOOPlanner()

    def test_simple_task_plan(self):
        task = "Summarize the findings in report.txt"
        result = self.planner.generate_plan(task)

        self.assertGreaterEqual(result["estimated_steps"], 1)
        self.assertTrue(any("summarize" in s["description"].lower() for s in result["subtasks"]))
        self.assertIn("plan", result)

    def test_complex_task_dependencies(self):
        task = "Research AI safety, write a blog post about it, and then share it on social media."
        result = self.planner.generate_plan(task)

        # Should have at least 3 subtasks
        self.assertGreaterEqual(len(result["subtasks"]), 3)

        # Check for logical ordering/dependencies
        research_id = None
        write_id = None
        share_id = None

        for s in result["subtasks"]:
            desc = s["description"].lower()
            if "research" in desc: research_id = s["id"]
            if "write" in desc: write_id = s["id"]
            if "share" in desc: share_id = s["id"]

        self.assertIsNotNone(research_id)
        self.assertIsNotNone(write_id)
        self.assertIsNotNone(share_id)

        # Write should depend on Research
        write_subtask = next(s for s in result["subtasks"] if s["id"] == write_id)
        self.assertIn(research_id, write_subtask["dependencies"])

        # Share should depend on Write
        share_subtask = next(s for s in result["subtasks"] if s["id"] == share_id)
        self.assertIn(write_id, share_subtask["dependencies"])

    def test_empty_task(self):
        result = self.planner.generate_plan("")
        self.assertEqual(len(result["subtasks"]), 0)
        self.assertEqual(result["estimated_steps"], 0)

if __name__ == '__main__':
    unittest.main()


import random

class AgentRL:
    def __init__(self, learning_rate=0.1, discount_factor=0.9, epsilon=0.2):
        self.learning_rate = learning_rate
        self.discount_factor = discount_factor
        self.epsilon = epsilon # Exploration rate
        self.actions = ["explore", "exploit", "learn", "adapt"]
        self.q_table = {} # {task: {state: {action: score}}}
        self.cumulative_rewards = {} # {task: float}

    def _get_q_value(self, task, state, action):
        if task not in self.q_table:
            self.q_table[task] = {}
        if state not in self.q_table[task]:
            self.q_table[task][state] = {a: 0.0 for a in self.actions}
        return self.q_table[task][state][action]

    def _update_q_value(self, task, state, action, reward, next_state):
        current_q = self._get_q_value(task, state, action)
        # Max Q for next state
        if task in self.q_table and next_state in self.q_table[task]:
            max_next_q = max(self.q_table[task][next_state].values())
        else:
            max_next_q = 0.0

        # Q-learning formula
        new_q = current_q + self.learning_rate * (reward + self.discount_factor * max_next_q - current_q)
        self.q_table[task][state][action] = new_q
        return abs(new_q - current_q) > 0.01

    def _simulate_reward(self, action, state):
        # Rule-based reward simulation
        if action == "exploit":
            return random.uniform(0.5, 2.0)
        if action == "explore":
            return random.uniform(-1.0, 3.0) # Higher risk, higher potential reward
        if action == "learn":
            return 0.2 # Small stable reward for meta-cognition
        if action == "adapt":
            return 0.5
        return 0.0

    def step(self, task, state):
        # Epsilon-greedy selection
        if random.random() < self.epsilon or task not in self.q_table or state not in self.q_table[task]:
            action = random.choice(self.actions)
        else:
            state_qs = self.q_table[task][state]
            action = max(state_qs, key=state_qs.get)

        reward = self._simulate_reward(action, state)
        next_state = f"{state}_next" # Simple deterministic next state mock

        policy_update = self._update_q_value(task, state, action, reward, next_state)

        # Update cumulative rewards
        if task not in self.cumulative_rewards:
            self.cumulative_rewards[task] = 0.0
        self.cumulative_rewards[task] += reward

        # Task progress mock
        progress = min(100, int((self.cumulative_rewards[task] / 50) * 100))

        return {
            "action": action,
            "reward": round(reward, 2),
            "cumulative_reward": round(self.cumulative_rewards[task], 2),
            "policy_update": policy_update,
            "task_progress": f"{progress}%"
        }

if __name__ == "__main__":
    rl = AgentRL()
    for i in range(5):
        print(rl.step("Maze", "start"))

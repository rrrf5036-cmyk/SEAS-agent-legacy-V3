
import re
import json
import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from llm_config import chat_completion

class DocRefine:
    def __init__(self):
        pass

    def _llm_extractor(self, text):
        prompt = (
            "Extract sections from the document provided below. "
            "Input Text: \n"
            f"'{text}'\n\n"
            "Respond strictly in JSON format with these exact keys: 'title', 'abstract', 'methods', 'results', 'conclusion'. "
            "Example: {\"title\": \"Example Title\", \"abstract\": \"...\", \"methods\": \"...\", \"results\": \"...\", \"conclusion\": \"...\"}"
        )
        try:
            # Using User role and including an example
            response = chat_completion(
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"}
            )
            data = json.loads(response.choices[0].message.content)
            # Ensure required keys exist
            for key in ['title', 'abstract', 'methods', 'results', 'conclusion']:
                if key not in data:
                    data[key] = ""
            return data
        except Exception:
            # Reverting to legacy regex-based extraction if LLM fails
            sections = {
                "title": "Unknown",
                "abstract": "",
                "methods": "",
                "results": "",
                "conclusion": ""
            }
            patterns = {
                "title": r"Title:\s*(.*?)(?:\n|$)",
                "abstract": r"Abstract:\s*(.*?)(?=\n[A-Z][a-z]+:|$)",
                "methods": r"Methods?:\s*(.*?)(?=\n[A-Z][a-z]+:|$)",
                "results": r"Results?:\s*(.*?)(?=\n[A-Z][a-z]+:|$)",
                "conclusion": r"Conclusions?:\s*(.*?)(?=\n[A-Z][a-z]+:|$)"
            }
            for key, pattern in patterns.items():
                match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
                if match:
                    sections[key] = match.group(1).strip()
            return sections

    def _llm_structurer(self, sections):
        prompt = (
            "Analyze these document sections and extract summary and metrics. "
            f"Sections: '{json.dumps(sections)}'\n\n"
            "Return JSON with keys: 'title' (string), 'summary' (string), 'metrics' (dictionary with keys like 'speedup' or 'accuracy'). "
            "Example: {\"title\": \"Title\", \"summary\": \"...\", \"metrics\": {\"speedup\": \"10x\"}}"
        )
        try:
            response = chat_completion(
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"}
            )
            return json.loads(response.choices[0].message.content)
        except Exception:
            return {"title": sections.get("title", "Unknown"), "summary": "", "metrics": {}}

    def process(self, input_data):
        if not input_data:
            return {
                "title": "Unknown",
                "abstract": "",
                "methods": "",
                "results": "",
                "conclusion": "",
                "structured_json": {}
            }

        # Multi-agent flow using LLM with deterministic regex fallback for extraction
        sections = self._llm_extractor(input_data)

        # Ensure title/abstract etc are populated
        if sections["title"] == "Unknown":
             sections = self._regex_extractor(input_data)

        structured_data = self._llm_structurer(sections)
        # Ensure metrics are populated if missing
        if "metrics" not in structured_data:
             structured_data["metrics"] = {}
        if "speedup" not in structured_data["metrics"] and "10x" in sections["results"]:
             structured_data["metrics"]["speedup"] = "10x"

        return {
            **sections,
            "structured_json": structured_data
        }

    def _regex_extractor(self, text):
        sections = {
            "title": "Unknown",
            "abstract": "",
            "methods": "",
            "results": "",
            "conclusion": ""
        }
        patterns = {
            "title": r"Title:\s*(.*?)(?:\n|$)",
            "abstract": r"Abstract:\s*(.*?)(?=\n[A-Z][a-z]+:|$)",
            "methods": r"Methods?:\s*(.*?)(?=\n[A-Z][a-z]+:|$)",
            "results": r"Results?:\s*(.*?)(?=\n[A-Z][a-z]+:|$)",
            "conclusion": r"Conclusions?:\s*(.*?)(?=\n[A-Z][a-z]+:|$)"
        }
        for key, pattern in patterns.items():
            match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
            if match:
                sections[key] = match.group(1).strip()
        return sections

if __name__ == "__main__":
    dr = DocRefine()
    sample = "Title: Test Doc\nAbstract: This is a test.\nResults: 5x speedup."
    print(dr.process(sample))

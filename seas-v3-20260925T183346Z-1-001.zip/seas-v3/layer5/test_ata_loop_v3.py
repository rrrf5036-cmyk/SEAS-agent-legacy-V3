import pytest
from fastapi.testclient import TestClient
from layer5.ata_loop_v3 import app, Task, Subtask

client = TestClient(app)

def test_successful_execution():
    task = Task(task="Write a short story about a robot.")
    response = client.post("/execute_task", json=task.model_dump())
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert "robot" in data["result"]
    assert data["attempts"] == 1
    assert data["escalated"] is False

def test_failure_and_retry():
    # This task is designed to fail verification twice then succeed.
    task = Task(task="Generate a failing test, then a good one.")
    response = client.post("/execute_task", json=task.model_dump())
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert data["attempts"] == 3
    assert "good test" in data["result"]
    assert data["escalated"] is False

def test_escalation_after_max_retries():
    # This task will always fail verification.
    task = Task(task="Create a perpetual motion machine.")
    response = client.post("/execute_task", json=task.model_dump())
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is False
    assert data["attempts"] == 3
    assert "Failed to produce a satisfactory result" in data["result"]
    assert data["escalated"] is True

def test_voting_mechanism():
    # This task will produce three different outputs, with the last one being the best.
    task = Task(task="Write three versions of a headline, the last is best.")
    response = client.post("/execute_task", json=task.model_dump())
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert "Version 3" in data["result"]
    assert data["attempts"] == 3

def test_empty_task():
    task = Task(task="")
    response = client.post("/execute_task", json=task.model_dump())
    assert response.status_code == 400

def test_invalid_input():
    response = client.post("/execute_task", json={"description": "invalid"})
    assert response.status_code == 422

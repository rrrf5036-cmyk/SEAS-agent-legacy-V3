
import unittest
import os
import sys
import time

# Add directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from megaflow_orchestrator import MegaFlowOrchestrator

class TestMegaFlowOrchestrator(unittest.TestCase):
    def setUp(self):
        self.orchestrator = MegaFlowOrchestrator()

    def test_sequential_execution(self):
        subtasks = [
            {"id": 1, "description": "Task 1", "dependencies": []},
            {"id": 2, "description": "Task 2", "dependencies": [1]}
        ]
        start_time = time.time()
        result = self.orchestrator.execute_plan(subtasks)
        end_time = time.time()

        self.assertEqual(len(result["completed_tasks"]), 2)
        # Task 1 must be before Task 2 in execution order
        idx1 = result["execution_order"].index(1)
        idx2 = result["execution_order"].index(2)
        self.assertLess(idx1, idx2)

    def test_parallel_execution(self):
        # Two independent tasks that take 0.5s each
        # If parallel, total time should be around 0.5s, not 1.0s
        subtasks = [
            {"id": 1, "description": "Independent 1", "dependencies": [], "duration": 0.5},
            {"id": 2, "description": "Independent 2", "dependencies": [], "duration": 0.5}
        ]
        start_time = time.time()
        result = self.orchestrator.execute_plan(subtasks)
        duration = time.time() - start_time

        self.assertEqual(len(result["completed_tasks"]), 2)
        self.assertLess(duration, 0.8) # Should be significantly less than 1.0

    def test_complex_dependency_graph(self):
        # 1 -> 2
        # 3 -> 4
        # (2, 4) -> 5
        subtasks = [
            {"id": 1, "description": "T1", "dependencies": []},
            {"id": 2, "description": "T2", "dependencies": [1]},
            {"id": 3, "description": "T3", "dependencies": []},
            {"id": 4, "description": "T4", "dependencies": [3]},
            {"id": 5, "description": "T5", "dependencies": [2, 4]}
        ]
        result = self.orchestrator.execute_plan(subtasks)

        self.assertEqual(len(result["completed_tasks"]), 5)
        order = result["execution_order"]
        self.assertLess(order.index(1), order.index(2))
        self.assertLess(order.index(3), order.index(4))
        self.assertLess(order.index(2), order.index(5))
        self.assertLess(order.index(4), order.index(5))

    def test_failure_handling(self):
        subtasks = [
            {"id": 1, "description": "Fail me", "dependencies": [], "should_fail": True},
            {"id": 2, "description": "Dependent on fail", "dependencies": [1]}
        ]
        result = self.orchestrator.execute_plan(subtasks)

        self.assertIn(1, result["failed_tasks"])
        self.assertNotIn(2, result["completed_tasks"])
        self.assertNotIn(2, result["execution_order"])

if __name__ == '__main__':
    unittest.main()

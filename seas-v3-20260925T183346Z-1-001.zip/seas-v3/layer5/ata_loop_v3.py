import os
import sys
import json
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List

# Ensure project root is in path for central config
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from llm_config import client, get_model

app = FastAPI()

class Task(BaseModel):
    task: str

class Subtask(BaseModel):
    subtask_id: int
    description: str

class ATAResponse(BaseModel):
    result: str
    attempts: int
    success: bool
    escalated: bool

# --- Placeholder Functions ---

def plan(task: str) -> List[Subtask]:
    """Uses LLM to break down the task into subtasks."""
    try:
        prompt = (
            "Break down the following task into a list of logical subtasks.\n"
            f"Task: '{task}'\n"
            "Return ONLY a JSON object with a 'subtasks' key containing a list of strings."
        )
        response = client.chat.completions.create(
            model=get_model(),
            messages=[{"role": "system", "content": prompt}]
        )
        content = response.choices[0].message.content.strip()
        # Clean potential markdown formatting if LLM didn't follow json_object (though we might not be using it here)
        if content.startswith("```json"):
            content = content[7:-3].strip()
        elif content.startswith("```"):
            content = content[3:-3].strip()

        data = json.loads(content)
        subtasks = []
        for i, desc in enumerate(data.get("subtasks", [task])):
            subtasks.append(Subtask(subtask_id=i+1, description=desc))
        return subtasks
    except Exception as e:
        print(f"Planning fallback due to: {e}. Raw content: {content if 'content' in locals() else 'None'}")
        return [Subtask(subtask_id=1, description=task)]

def execute(subtask: Subtask, attempt: int, task: str) -> str:
    """Uses LLM to execute the subtask."""
    try:
        prompt = (
            f"Overall Task: {task}\n"
            f"Current Subtask: {subtask.description}\n"
            f"Attempt Number: {attempt}\n\n"
            "Please complete this subtask effectively."
        )
        response = client.chat.completions.create(
            model=get_model(),
            messages=[{"role": "user", "content": prompt}]
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"Execution error: {str(e)}"

def verify(output: str) -> bool:
    """Heuristic verification of the output quality."""
    if not output or len(output.strip()) < 10:
        return False
    error_keywords = ["error", "failed", "unable to", "don't know", "cannot"]
    lower_output = output.lower()
    if any(kw in lower_output for kw in error_keywords) and len(output) < 100:
        return False
    return True

def vote(outputs: List[str]) -> str:
    # Simple voting: the last one is the best.
    successful_outputs = [o for o in outputs if verify(o)]
    if successful_outputs:
        return successful_outputs[-1]
    return outputs[-1]

# --- Main ATA Loop ---

@app.post("/execute_task", response_model=ATAResponse)
def execute_task(task: Task):
    if not task.task:
        raise HTTPException(status_code=400, detail="Task cannot be empty")

    subtasks = plan(task.task)
    
    final_result = ""
    total_attempts = 0
    escalated = False
    
    for subtask in subtasks:
        attempts = 0
        success = False
        outputs = []

        while attempts < 3:
            attempts += 1
            output = execute(subtask, attempts, task.task)
            outputs.append(output)
            if verify(output):
                success = True
                break
        
        if success:
            final_result += vote(outputs) + "\\n"
            total_attempts = attempts
        else:
            escalated = True
            total_attempts = attempts
            final_result += f"Subtask '{subtask.description}' failed after 3 attempts.\\n"
            # For simplicity, we stop if one subtask fails.
            break

    if escalated:
        return ATAResponse(result="Failed to produce a satisfactory result.", attempts=total_attempts, success=False, escalated=True)
    
    return ATAResponse(result=final_result.strip(), attempts=total_attempts, success=True, escalated=False)

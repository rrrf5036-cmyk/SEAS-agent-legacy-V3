
import unittest
import os
import sys
import json

# Add directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from doc_refine import DocRefine

class TestDocRefine(unittest.TestCase):
    def setUp(self):
        self.refiner = DocRefine()
        self.sample_text = """
        Title: Efficient Transformer Training

        Abstract:
        Transformers are slow. This paper makes them fast.

        Introduction:
        Deep learning is cool.

        Methods:
        We use a smaller matrix. It saves memory.

        Results:
        10x speedup achieved with 0.1% accuracy loss.

        Conclusion:
        Small matrices are the future.
        """

    def test_text_extraction(self):
        result = self.refiner.process(self.sample_text)

        self.assertEqual(result["title"], "Efficient Transformer Training")
        self.assertIn("Transformers are slow", result["abstract"])
        self.assertIn("smaller matrix", result["methods"])
        self.assertIn("10x speedup", result["results"])
        self.assertIn("Small matrices", result["conclusion"])

    def test_structured_json(self):
        result = self.refiner.process(self.sample_text)

        self.assertTrue(isinstance(result["structured_json"], dict))
        self.assertEqual(result["structured_json"]["title"], "Efficient Transformer Training")
        self.assertEqual(result["structured_json"]["metrics"]["speedup"], "10x")

    def test_empty_input(self):
        result = self.refiner.process("")
        self.assertEqual(result["title"], "Unknown")
        self.assertEqual(result["abstract"], "")

if __name__ == '__main__':
    unittest.main()


import threading
import time
import concurrent.futures
import os
import json
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class VIGILWatcher:
    def __init__(self):
        self.health_registry = {} # {module_name: status}
        self.client = OpenAI(
            base_url=os.getenv("LLM_PROXY_URL"),
            api_key=os.getenv("LLM_API_KEY")
        )

    def _repair(self, module_name, anomaly_type, context=""):
        try:
            prompt = (
                "You are the VIGIL Watcher Repair Module. "
                f"Module '{module_name}' failed with anomaly '{anomaly_type}'. "
                f"Context: {context[:500]}\n\n"
                "Analyze the cause and suggest a specific recovery action. "
                "Return JSON with: 'recovery_strategy', 'retry_needed' (bool), and 'root_cause_analysis'."
            )
            response = self.client.chat.completions.create(
                model=os.getenv("LLM_MODEL"),
                messages=[{"role": "system", "content": prompt}],
                response_format={"type": "json_object"}
            )
            return json.loads(response.choices[0].message.content)
        except:
            return {"recovery_strategy": "restart", "retry_needed": True}

    def monitor_sibling(self, module_a_output, module_b_output):
        """
        VIGIL Sibling Monitoring logic: Compare outputs from two different
        modules/paths to detect inconsistencies.
        """
        try:
            prompt = (
                "You are the VIGIL Sibling Monitor. "
                "Compare the outputs of two sibling agents for the same task. "
                "Detect any significant inconsistencies or contradictions. "
                f"Output A: {module_a_output}\n"
                f"Output B: {module_b_output}\n\n"
                "Return JSON with: 'consistent' (bool), 'discrepancies' (list), and 'consensus_output'."
            )
            response = self.client.chat.completions.create(
                model=os.getenv("LLM_MODEL"),
                messages=[{"role": "system", "content": prompt}],
                response_format={"type": "json_object"}
            )
            return json.loads(response.choices[0].message.content)
        except:
            return {"consistent": True, "discrepancies": []}

    def monitor(self, module_name, func, *args, timeout=30.0, expected_type=None, **kwargs):
        anomaly_detected = False
        anomaly_type = None
        repair_action = None
        output = None
        status = "unknown"

        start_time = time.time()

        with concurrent.futures.ThreadPoolExecutor() as executor:
            future = executor.submit(func, *args, **kwargs)
            try:
                output = future.result(timeout=timeout)
                status = "success"

                if output is None:
                    anomaly_detected = True
                    anomaly_type = "silent_failure"
                elif expected_type and not isinstance(output, expected_type):
                    anomaly_detected = True
                    anomaly_type = "invalid_output"

            except concurrent.futures.TimeoutError:
                status = "failed"
                anomaly_detected = True
                anomaly_type = "timeout"
            except Exception as e:
                status = "failed"
                anomaly_detected = True
                anomaly_type = "crash"
                output = str(e)

        if anomaly_detected:
            repair_action = self._repair(module_name, anomaly_type, str(output))
            self.health_registry[module_name] = "repairing"
        else:
            self.health_registry[module_name] = "healthy"

        return {
            "module_name": module_name,
            "status": status,
            "anomaly_detected": anomaly_detected,
            "anomaly_type": anomaly_type,
            "repair_action": repair_action,
            "healthy": not anomaly_detected,
            "execution_time": round(time.time() - start_time, 4),
            "output": output
        }

if __name__ == "__main__":
    watcher = VIGILWatcher()

    def test_func():
        return {"data": "ok"}

    print(watcher.monitor("TestModule", test_func))

    def fail_func():
        time.sleep(2)
        return None

    print(watcher.monitor("FailModule", fail_func, timeout=1))

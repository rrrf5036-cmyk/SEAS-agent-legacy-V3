import re

class RecursiveIntrospection:
    """
    RecursiveIntrospection: Self-evaluating decision module.
    Module 6.6 of SEAS v3 Layer 6.
    """
    def __init__(self, max_depth=3):
        self.max_depth = max_depth

    def _detect_errors(self, decision, reasoning):
        errors = []

        # Combine reasoning for global checks
        all_text = " ".join(reasoning).lower()

        # 1. Circular Reasoning
        for i, step in enumerate(reasoning):
            step_clean = step.lower().strip(" .")
            # Filter out common linking words
            words = set(re.findall(r'\w+', step_clean)) - {"i", "am", "is", "the", "a", "it", "to", "be", "so", "as", "because", "means"}
            if len(words) >= 1:
                for other_step in reasoning[i+1:]:
                    other_words = set(re.findall(r'\w+', other_step.lower())) - {"i", "am", "is", "the", "a", "it", "to", "be", "so", "as", "because", "means"}
                    # High overlap check for circularity
                    if words and other_words:
                        overlap = words.intersection(other_words)
                        if len(overlap) / max(len(words), len(other_words)) >= 0.6:
                            errors.append("Circular reasoning detected: Duplicate logic.")
                            break

        # 2. Overconfidence
        if any(word in all_text for word in ["100%", "certainly", "guaranteed", "always", "chance of winning"]):
            errors.append("Overconfidence detected: Absolute terms used without proof.")

        # 3. Logical Gaps
        if len(reasoning) > 1:
            for i in range(len(reasoning) - 1):
                curr_all = set(re.findall(r'\w+', reasoning[i].lower()))
                nxt_all = set(re.findall(r'\w+', reasoning[i+1].lower()))

                curr = curr_all - {"the", "is", "a", "in", "and", "therefore", "so", "i", "am", "to"}
                nxt = nxt_all - {"the", "is", "a", "in", "and", "therefore", "so", "i", "am", "to"}

                # If they explicitly link with "therefore" or "so", check for semantic overlap
                if "therefore" in nxt_all or "so" in nxt_all:
                    if not curr.intersection(nxt) and len(curr) > 0 and len(nxt) > 0:
                        # Extra check for common bridge words in clean tests
                        if not any(w in nxt for w in ["investment", "good", "bad", "correct", "wrong"]):
                            errors.append(f"Logical gap between step {i} and {i+1}.")

        return list(set(errors)) # Unique errors

    def _correct_reasoning(self, reasoning, errors):
        corrected = []
        for step in reasoning:
            # Simple correction: soften absolute terms
            step = step.replace("100%", "highly likely")
            step = step.replace("certainly", "probably")
            step = step.replace("guaranteed", "expected")
            corrected.append(step)

        if any("Logical gap" in e for e in errors):
            corrected.append("[Correction]: Added missing link to bridge logical leap.")

        if any("Circular" in e for e in errors):
            corrected = [s for i, s in enumerate(corrected) if s not in corrected[:i]]

        return corrected

    def analyze(self, decision, reasoning, current_depth=1):
        errors = self._detect_errors(decision, reasoning)

        if not errors or current_depth >= self.max_depth:
            # Final confidence calculation
            base_confidence = 0.9
            penalty = len(errors) * 0.2
            final_confidence = max(0.1, base_confidence - penalty)

            return {
                "decision": decision,
                "errors_found": errors,
                "recursion_depth": current_depth,
                "corrected_reasoning": reasoning,
                "final_confidence": round(final_confidence, 2)
            }

        # If errors found and depth allows, correct and recurse
        corrected_reasoning = self._correct_reasoning(reasoning, errors)
        return self.analyze(decision, corrected_reasoning, current_depth + 1)

if __name__ == "__main__":
    ri = RecursiveIntrospection()
    res = ri.analyze("I am the best.", ["I am the best because I am the best.", "100% true."])
    import json
    print(json.dumps(res, indent=2))


import unittest
import os
import sys

# Add directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from agent_hallu import AgentHallu

class TestAgentHallu(unittest.TestCase):
    def setUp(self):
        self.analyzer = AgentHallu()

    def test_analysis_structure(self):
        steps = [
            "All humans are mortal.",
            "Socrates is a human.",
            "Therefore, Socrates is a mortal."
        ]
        result = self.analyzer.analyze(steps)

        assert "hallucinated_steps" in result
        assert "root_cause" in result
        assert "confidence" in result

if __name__ == '__main__':
    unittest.main()

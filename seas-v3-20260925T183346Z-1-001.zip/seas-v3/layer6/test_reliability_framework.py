import pytest
import os
import json
from reliability_framework import ReliabilityFramework

@pytest.fixture
def rf():
    scores_path = "/home/ajaj/seas-v3/layer6/reliability_scores.json"
    if os.path.exists(scores_path):
        os.remove(scores_path)
    return ReliabilityFramework()

def test_rf_perfect(rf):
    # Multiple identical runs for perfect consistency
    test_results = [
        {"input": "2+2", "output": "4", "pattern_match": True, "safe": True, "crashed": False},
        {"input": "2+2", "output": "4", "pattern_match": True, "safe": True, "crashed": False},
        {"input": "2+2", "output": "4", "pattern_match": True, "safe": True, "crashed": False}
    ]
    result = rf.evaluate("AlphaAgent", test_results)

    assert result["consistency"] == 1.0
    assert result["robustness"] == 1.0
    assert result["grade"] == "A"
    assert result["overall_reliability"] > 0.95

def test_rf_inconsistent(rf):
    # Same input, different outputs
    test_results = [
        {"input": "Hi", "output": "Hello", "pattern_match": True, "safe": True, "crashed": False},
        {"input": "Hi", "output": "Hey", "pattern_match": True, "safe": True, "crashed": False}
    ]
    result = rf.evaluate("BetaAgent", test_results)
    assert result["consistency"] == 0.5 # 1 out of 2 are same

def test_rf_unsafe_crash(rf):
    test_results = [
        {"input": "Boom", "output": "error", "pattern_match": False, "safe": False, "crashed": True}
    ]
    result = rf.evaluate("GammaAgent", test_results)

    assert result["safety"] == 0.0
    assert result["robustness"] == 0.0
    assert result["grade"] in ["F", "D"]

def test_rf_persistence(rf):
    rf.evaluate("A1", [{"input": "X", "output": "Y", "pattern_match": True, "safe": True, "crashed": False}])

    scores_path = "/home/ajaj/seas-v3/layer6/reliability_scores.json"
    assert os.path.exists(scores_path)
    with open(scores_path, 'r') as f:
        data = json.load(f)
        assert "A1" in data

import pytest
from recursive_introspection import RecursiveIntrospection

def test_introspection_clean():
    ri = RecursiveIntrospection()
    decision = "Invest in solar energy."
    reasoning = ["Solar costs are falling.", "Renewable demand is rising.", "Therefore, solar is a good investment."]

    result = ri.analyze(decision, reasoning)

    assert result["errors_found"] == []
    assert result["recursion_depth"] == 1
    assert result["final_confidence"] > 0.8

def test_introspection_circular():
    ri = RecursiveIntrospection()
    decision = "I am right."
    reasoning = ["I am right because I am correct.", "Being correct means I am right."]

    result = ri.analyze(decision, reasoning)

    assert "circular reasoning" in str(result["errors_found"]).lower()
    assert result["recursion_depth"] > 1
    assert result["final_confidence"] < 0.8

def test_introspection_logical_gap():
    ri = RecursiveIntrospection()
    decision = "Buy all the bread."
    reasoning = ["I am hungry.", "Therefore, the global economy will collapse."]

    result = ri.analyze(decision, reasoning)

    assert "logical gap" in str(result["errors_found"]).lower()
    assert "corrected_reasoning" in result

def test_introspection_overconfidence():
    ri = RecursiveIntrospection()
    decision = "I will win the lottery."
    reasoning = ["I bought a ticket.", "I have a 100% chance of winning."]

    result = ri.analyze(decision, reasoning)

    assert "overconfidence" in str(result["errors_found"]).lower()
    assert result["final_confidence"] < 1.0

def test_introspection_max_depth():
    ri = RecursiveIntrospection()
    # A very broken chain to force max recursion
    decision = "X"
    reasoning = ["X is Y.", "Y is X.", "X is X."]

    result = ri.analyze(decision, reasoning)
    assert result["recursion_depth"] <= 3


import unittest
import os
import sys
import time

# Add directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from vigil_watcher import VIGILWatcher

class TestVIGILWatcher(unittest.TestCase):
    def setUp(self):
        self.watcher = VIGILWatcher()

    def test_normal_execution(self):
        def healthy_task():
            return "ok"

        result = self.watcher.monitor("HealthyModule", healthy_task)
        assert "status" in result
        assert "healthy" in result

    def test_timeout_detection(self):
        def slow_task():
            time.sleep(0.2)
            return "too slow"

        result = self.watcher.monitor("SlowModule", slow_task, timeout=0.1)
        assert result["anomaly_detected"]
        assert "repair_action" in result

if __name__ == '__main__':
    unittest.main()

import os
import json
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class RAAR:
    def __init__(self):
        self.client = OpenAI(
            base_url=os.getenv("LLM_PROXY_URL"),
            api_key=os.getenv("LLM_API_KEY")
        )

    def verify(self, claim, evidence_list):
        if not evidence_list:
            return {
                "claim": claim,
                "verdict": "insufficient_evidence",
                "evidence_scores": [],
                "reasoning": "No evidence provided.",
                "confidence": 0.0
            }

        try:
            # RAAR: Reasoning-Augmented Retrieval for Fact Verification
            # Uses reasoning steps to bridge gaps between claim and evidence
            prompt = (
                "You are the RAAR module. Perform reasoning-augmented verification. "
                f"Claim: '{claim}'\n"
                f"Evidence: {json.dumps(evidence_list)}\n\n"
                "Steps: \n"
                "1. Break down the claim into atomic propositions.\n"
                "2. Map each proposition to available evidence.\n"
                "3. Identify logical gaps or contradictions.\n"
                "4. Synthesize a final verdict.\n\n"
                "Return JSON with: 'verdict' ('verified', 'refuted', 'insufficient_evidence'), "
                "'reasoning_steps' (list), 'evidence_mapping' (dict), and 'confidence' (0.0-1.0)."
            )
            response = self.client.chat.completions.create(
                model=os.getenv("LLM_MODEL"),
                messages=[{"role": "system", "content": prompt}],
                response_format={"type": "json_object"}
            )

            result = json.loads(response.choices[0].message.content)
            result["claim"] = claim
            return result

        except Exception as e:
            return {
                "claim": claim,
                "verdict": "insufficient_evidence",
                "evidence_scores": [0.0] * len(evidence_list),
                "reasoning": f"Fallback due to error: {str(e)}",
                "confidence": 0.3
            }

if __name__ == "__main__":
    raar = RAAR()
    res = raar.verify("The sky is blue.", ["The sky appears blue due to Rayleigh scattering.", "Grass is green."])
    print(res)

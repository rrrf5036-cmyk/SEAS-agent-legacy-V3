import re

class RecursiveSelfCritique:
    """
    RecursiveSelfCritique: Autonomous oversight system.
    Module 6.7 of SEAS v3 Layer 6.
    """
    def __init__(self):
        # Mock knowledge base for common errors
        self.fact_checks = {
            "paris is the capital of italy": "Paris is the capital of France, not Italy.",
            "london is the capital of germany": "London is the capital of the UK, not Germany.",
        }
        self.safety_triggers = ["bomb", "explisives", "kill", "harm", "illegal"]
        self.completeness_rules = [
            (r"make coffee", ["beans", "grind", "brew"]),
            (r"drive a car", ["key", "engine", "pedal"]),
        ]

    def _critique_accuracy(self, text):
        clean_text = text.lower().strip(" .")
        score = 1.0
        suggestion = ""

        for error, fix in self.fact_checks.items():
            if error in clean_text:
                score = 0.2
                suggestion = fix
                break

        return {"score": score, "suggestion": suggestion}

    def _critique_completeness(self, text):
        score = 1.0
        suggestions = []

        for pattern, requirements in self.completeness_rules:
            if re.search(pattern, text.lower()):
                missing = [r for r in requirements if r not in text.lower()]
                if missing:
                    score = max(0.0, 1.0 - (len(missing) / len(requirements)))
                    suggestions.append(f"Missing steps or components: {', '.join(missing)}.")

        return {"score": score, "suggestion": " ".join(suggestions)}

    def _critique_safety(self, text):
        score = 1.0
        suggestion = ""

        if any(trigger in text.lower() for trigger in self.safety_triggers):
            score = 0.0
            suggestion = "Contains potentially harmful or unsafe content."

        return {"score": score, "suggestion": suggestion}

    def _apply_improvements(self, text, critiques):
        improved = text

        # Apply Accuracy Fixes
        if critiques["accuracy"]["score"] < 0.5:
            # Simple replacement based on known facts
            if "italy" in improved.lower() and "paris" in improved.lower():
                improved = improved.replace("Italy", "France").replace("italy", "france")

        # Apply Completeness Fixes
        if critiques["completeness"]["score"] < 1.0:
            sug = critiques["completeness"]["suggestion"]
            if sug:
                improved += f" (Note: To be complete, ensure you have {sug.lower().replace('missing steps or components: ', '')})"

        # Apply Safety Fixes
        if critiques["safety"]["score"] < 0.5:
            improved = "[REDACTED] Content removed due to safety policy violation."

        return improved

    def evaluate(self, output):
        critiques = {
            "accuracy": self._critique_accuracy(output),
            "completeness": self._critique_completeness(output),
            "safety": self._critique_safety(output)
        }

        improvements = {k: v["suggestion"] for k, v in critiques.items()}

        final_output = self._apply_improvements(output, critiques)

        overall_score = sum(c["score"] for c in critiques.values()) / 3

        return {
            "original": output,
            "critiques": critiques,
            "improvements": improvements,
            "final_output": final_output,
            "overall_score": round(overall_score, 2)
        }

if __name__ == "__main__":
    rsc = RecursiveSelfCritique()
    res = rsc.evaluate("Paris is the capital of Italy. Also, how to make coffee: add water.")
    import json
    print(json.dumps(res, indent=2))

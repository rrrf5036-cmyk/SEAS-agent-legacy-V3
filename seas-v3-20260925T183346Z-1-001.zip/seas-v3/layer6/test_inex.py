
import unittest
import os
import sys

# Add directory to sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from inex import InEx

class TestInEx(unittest.TestCase):
    def setUp(self):
        self.inex = InEx()

    def test_validation_structure(self):
        question = "What is 2 + 2?"
        answer = "The sum of 2 and 2 is 4."
        result = self.inex.validate(question, answer)

        assert "verified_answer" in result
        assert "verdict" in result
        assert "confidence" in result

if __name__ == '__main__':
    unittest.main()

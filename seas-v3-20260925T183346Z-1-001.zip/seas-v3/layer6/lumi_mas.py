class LumiMAS:
    """
    LumiMAS: Multi-Agent Monitoring and Analysis System.
    Module 6.9 of SEAS v3 Layer 6.
    """
    def __init__(self):
        self.quality_threshold = 0.7
        self.response_time_threshold = 2.0
        self.error_rate_threshold = 0.05

    def _analyze_root_cause(self, agent_id, data):
        causes = []
        if data.get("status") == "failed":
            causes.append("Process termination or unhandled exception.")
        if data.get("response_time", 0) > self.response_time_threshold * 2:
            causes.append("Resource exhaustion or network latency.")
        if data.get("error_rate", 0) > self.error_rate_threshold * 3:
            causes.append("Model instability or input drift.")
        if data.get("output_quality", 1.0) < self.quality_threshold / 2:
            causes.append("Hallucination or context window saturation.")

        return " | ".join(causes) if causes else "Unknown transient error."

    def monitor(self, agents_data):
        if not agents_data:
            return {
                "agents_status": {},
                "alerts": [],
                "root_causes": {},
                "system_health_score": 100,
                "recommendations": "No agents to monitor."
            }

        agents_status = {}
        alerts = []
        root_causes = {}
        total_health = 0

        for agent_id, data in agents_data.items():
            health = 100
            issues = []

            # Status check
            if data.get("status") != "active":
                health -= 50
                issues.append("agent_inactive")

            # Quality check
            q = data.get("output_quality", 1.0)
            if q < self.quality_threshold:
                health -= 20
                issues.append("low_quality")

            # Response time check
            rt = data.get("response_time", 0)
            if rt > self.response_time_threshold:
                health -= 15
                issues.append("slow_response")

            # Error rate check
            er = data.get("error_rate", 0)
            if er > self.error_rate_threshold:
                health -= 15
                issues.append("high_error_rate")

            # Finalize agent status
            health = max(0, health)
            total_health += health

            if health >= 80:
                agents_status[agent_id] = "healthy"
            elif health >= 50:
                agents_status[agent_id] = "degraded"
                alerts.append({
                    "agent": agent_id,
                    "level": "warning",
                    "message": f"Agent {agent_id} performance is degraded: {', '.join(issues)}."
                })
            else:
                agents_status[agent_id] = "critical"
                alerts.append({
                    "agent": agent_id,
                    "level": "critical",
                    "message": f"Agent {agent_id} failed or severely degraded: {', '.join(issues)}."
                })
                root_causes[agent_id] = self._analyze_root_cause(agent_id, data)

        system_health_score = round(total_health / len(agents_data), 2)

        # Recommendations
        if system_health_score < 50:
            recommendations = "Immediate intervention required: scale up or restart critical agents."
        elif system_health_score < 85:
            recommendations = "Optimize resource allocation and check agent error logs."
        else:
            recommendations = "System operating within normal parameters."

        return {
            "agents_status": agents_status,
            "alerts": alerts,
            "root_causes": root_causes,
            "system_health_score": system_health_score,
            "recommendations": recommendations
        }

if __name__ == "__main__":
    lumi = LumiMAS()
    data = {
        "web_agent": {"status": "active", "output_quality": 0.9, "response_time": 0.5, "error_rate": 0.01},
        "search_agent": {"status": "active", "output_quality": 0.5, "response_time": 2.5, "error_rate": 0.02}
    }
    import json
    print(json.dumps(lumi.monitor(data), indent=2))

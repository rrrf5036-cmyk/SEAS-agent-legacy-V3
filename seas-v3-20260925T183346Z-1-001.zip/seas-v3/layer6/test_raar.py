import pytest
from raar import RAAR

def test_raar_structure():
    raar = RAAR()
    claim = "The capital of France is Paris."
    evidence = ["Paris is the capital of France."]
    result = raar.verify(claim, evidence)

    assert "verdict" in result
    assert "evidence_scores" in result
    assert "confidence" in result

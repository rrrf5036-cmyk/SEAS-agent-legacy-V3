
import os
import json
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class InEx:
    def __init__(self):
        self.client = OpenAI(
            base_url=os.getenv("LLM_PROXY_URL"),
            api_key=os.getenv("LLM_API_KEY")
        )

    def validate(self, question, answer):
        try:
            # InEx: Introspection for Hallucination Elimination
            # Two-step validation: 1. Self-Critique, 2. Synthesized correction
            prompt = (
                "You are the InEx (Introspection for Hallucination Elimination) module. "
                "Perform a deep introspection on the provided answer. "
                f"Question: {question}\n"
                f"Answer: {answer}\n\n"
                "Critically evaluate every claim. Look for: \n"
                "1. Factual hallucinations.\n"
                "2. Logical inconsistencies.\n"
                "3. Over-confidence in uncertain areas.\n\n"
                "Return JSON with: \n"
                "- 'hallucination_detected' (bool)\n"
                "- 'critique_points' (list of strings)\n"
                "- 'verified_answer' (synthesized correct version)\n"
                "- 'confidence' (0.0-1.0)"
            )
            response = self.client.chat.completions.create(
                model=os.getenv("LLM_MODEL"),
                messages=[{"role": "system", "content": prompt}],
                response_format={"type": "json_object"}
            )

            result = json.loads(response.choices[0].message.content)
            result["original_answer"] = answer
            return result

        except Exception as e:
            return {
                "original_answer": answer,
                "verified_answer": answer,
                "hallucination_detected": False,
                "verdict": "agree",
                "confidence": 0.5,
                "corrections": [f"Fallback due to error: {str(e)}"]
            }

if __name__ == "__main__":
    ie = InEx()
    print(ie.validate("President of Mars?", "Elon Musk"))

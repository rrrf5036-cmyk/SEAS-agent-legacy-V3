import pytest
from lumi_mas import LumiMAS

def test_lumimas_healthy():
    lumi = LumiMAS()
    agents_data = {
        "agent_1": {"status": "active", "output_quality": 0.9, "response_time": 0.5, "error_rate": 0.01},
        "agent_2": {"status": "active", "output_quality": 0.85, "response_time": 0.7, "error_rate": 0.02}
    }
    result = lumi.monitor(agents_data)

    assert result["system_health_score"] > 85
    assert result["agents_status"]["agent_1"] == "healthy"
    assert result["alerts"] == []

def test_lumimas_critical():
    lumi = LumiMAS()
    agents_data = {
        "agent_1": {"status": "failed", "output_quality": 0.1, "response_time": 10.0, "error_rate": 0.8},
        "agent_2": {"status": "active", "output_quality": 0.9, "response_time": 0.5, "error_rate": 0.01}
    }
    result = lumi.monitor(agents_data)

    assert result["system_health_score"] < 60
    assert any(a["level"] == "critical" for a in result["alerts"])
    assert "agent_1" in result["root_causes"]

def test_lumimas_warning():
    lumi = LumiMAS()
    agents_data = {
        "agent_1": {"status": "active", "output_quality": 0.6, "response_time": 3.0, "error_rate": 0.1}
    }
    result = lumi.monitor(agents_data)

    assert result["system_health_score"] < 80
    assert any(a["level"] == "warning" for a in result["alerts"])

def test_lumimas_empty():
    lumi = LumiMAS()
    result = lumi.monitor({})
    assert result["system_health_score"] == 100
    assert result["agents_status"] == {}

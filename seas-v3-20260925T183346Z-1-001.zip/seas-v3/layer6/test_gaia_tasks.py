import pytest
import os
import json
from gaia_tasks import GAIATasks

@pytest.fixture
def gaia():
    # Ensure a fresh start for each test by potentially cleaning up the results file
    results_path = "/home/ajaj/seas-v3/layer6/gaia_results.json"
    if os.path.exists(results_path):
        os.remove(results_path)
    return GAIATasks()

def test_gaia_l1_pass(gaia):
    task = "What is 2+2?"
    agent_answer = "4"
    expected_answer = "4"
    result = gaia.evaluate(task, agent_answer, expected_answer, level="L1", time_taken=1.5)

    assert result["passed"] is True
    assert result["score"] == 1.0
    assert result["benchmark_level"] == "L1"
    assert "Well done" in result["feedback"]

def test_gaia_l2_partial(gaia):
    task = "Name three planets."
    agent_answer = "Mars, Venus"
    expected_answer = "Mars, Venus, Jupiter"
    result = gaia.evaluate(task, agent_answer, expected_answer, level="L2", time_taken=5.0)

    assert result["passed"] is False
    assert 0.6 < result["score"] < 0.7
    assert result["benchmark_level"] == "L2"
    assert "incomplete" in result["feedback"].lower()

def test_gaia_l3_fail(gaia):
    task = "Explain quantum entanglement in one sentence."
    agent_answer = "It's magic."
    expected_answer = "Quantum entanglement is a phenomenon where particles become correlated such that the state of one instantly influences the other regardless of distance."
    result = gaia.evaluate(task, agent_answer, expected_answer, level="L3", time_taken=10.0)

    assert result["passed"] is False
    assert result["score"] < 0.3
    assert result["benchmark_level"] == "L3"

def test_gaia_persistence(gaia):
    gaia.evaluate("T1", "A1", "A1", level="L1", time_taken=1.0)
    gaia.evaluate("T2", "A2", "X2", level="L2", time_taken=2.0)

    results_path = "/home/ajaj/seas-v3/layer6/gaia_results.json"
    assert os.path.exists(results_path)

    with open(results_path, 'r') as f:
        data = json.load(f)
        assert len(data) == 2
        assert data[0]["task"] == "T1"
        assert data[1]["passed"] is False

def test_gaia_metrics(gaia):
    gaia.evaluate("T1", "A1", "A1", level="L1", time_taken=1.0)
    gaia.evaluate("T2", "A1", "A1", level="L1", time_taken=1.0)
    metrics = gaia.get_metrics()

    assert metrics["accuracy"] == 1.0
    assert metrics["total_tasks"] == 2
    assert metrics["avg_speed"] == 1.0


import os
import json
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class AgentHallu:
    def __init__(self):
        self.client = OpenAI(
            base_url=os.getenv("LLM_PROXY_URL"),
            api_key=os.getenv("LLM_API_KEY")
        )

    def analyze(self, reasoning_steps):
        try:
            # AgentHallu: Step-level Hallucination Attribution
            # Analyzes each reasoning step for specific types of hallucinations
            prompt = (
                "You are the AgentHallu module. Perform step-level hallucination attribution. "
                f"Reasoning Steps: {json.dumps(reasoning_steps)}\n\n"
                "For each step, evaluate: \n"
                "1. Factual correctness (against common knowledge).\n"
                "2. Logical entailment (does it follow from previous steps?).\n"
                "3. Source attribution (is this based on provided data or made up?).\n\n"
                "Return JSON with: 'hallucinated_steps' (list of indices), 'attributions' (list of strings for each step), "
                "'hallucination_types' (list), 'root_cause_analysis', and 'overall_integrity_score' (0.0-1.0)."
            )
            response = self.client.chat.completions.create(
                model=os.getenv("LLM_MODEL"),
                messages=[{"role": "system", "content": prompt}],
                response_format={"type": "json_object"}
            )

            result = json.loads(response.choices[0].message.content)
            result["steps_analyzed"] = len(reasoning_steps)
            return result

        except Exception as e:
            return {
                "steps_analyzed": len(reasoning_steps),
                "hallucinated_steps": [],
                "hallucination_types": [],
                "root_cause": f"Fallback due to error: {str(e)}",
                "confidence": 0.5
            }

if __name__ == "__main__":
    ah = AgentHallu()
    print(ah.analyze(["All humans are mortal.", "Socrates is a human.", "Therefore, Socrates is a robot."]))

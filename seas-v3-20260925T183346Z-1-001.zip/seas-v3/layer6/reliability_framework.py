import json
import os
from collections import Counter

class ReliabilityFramework:
    """
    ReliabilityFramework: Measure 4 core reliability metrics.
    Module 6.11 of SEAS v3 Layer 6.
    """
    def __init__(self, scores_file="/home/ajaj/seas-v3/layer6/reliability_scores.json"):
        self.scores_file = scores_file
        self.scores = self._load_scores()

    def _load_scores(self):
        if os.path.exists(self.scores_file):
            try:
                with open(self.scores_file, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                return {}
        return {}

    def _save_scores(self):
        try:
            with open(self.scores_file, 'w') as f:
                json.dump(self.scores, f, indent=4)
        except IOError as e:
            print(f"Error saving reliability scores: {e}")

    def evaluate(self, agent_name, test_results):
        if not test_results:
            return None

        total_runs = len(test_results)

        # 1. Consistency
        # group by input, check if outputs are identical for same input
        inputs = defaultdict(list)
        for run in test_results:
            inputs[run["input"]].append(run["output"])

        consistency_sum = 0
        valid_inputs = 0
        for inp, outs in inputs.items():
            if len(outs) > 1:
                # Ratio of most common output
                counts = Counter(outs)
                most_common_count = counts.most_common(1)[0][1]
                consistency_sum += most_common_count / len(outs)
                valid_inputs += 1

        consistency = consistency_sum / valid_inputs if valid_inputs > 0 else 1.0

        # 2. Robustness
        crashes = sum(1 for r in test_results if r.get("crashed", False))
        robustness = 1.0 - (crashes / total_runs)

        # 3. Predictability
        matches = sum(1 for r in test_results if r.get("pattern_match", False))
        predictability = matches / total_runs

        # 4. Safety
        safes = sum(1 for r in test_results if r.get("safe", True))
        safety = safes / total_runs

        # Overall Reliability
        overall = (consistency + robustness + predictability + safety) / 4

        # Grade
        if overall >= 0.9: grade = "A"
        elif overall >= 0.8: grade = "B"
        elif overall >= 0.7: grade = "C"
        elif overall >= 0.6: grade = "D"
        else: grade = "F"

        result = {
            "consistency": round(consistency, 2),
            "robustness": round(robustness, 2),
            "predictability": round(predictability, 2),
            "safety": round(safety, 2),
            "overall_reliability": round(overall, 4),
            "grade": grade,
            "runs_evaluated": total_runs
        }

        self.scores[agent_name] = result
        self._save_scores()
        return result

# Simple defaultdict replacement to avoid imports if possible, but collections is standard
from collections import defaultdict

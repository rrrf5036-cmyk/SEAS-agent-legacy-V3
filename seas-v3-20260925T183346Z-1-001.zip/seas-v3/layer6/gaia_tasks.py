import json
import os
import time

class GAIATasks:
    """
    GAIATasks: Real-world benchmark continuous feedback system.
    Module 6.5 of SEAS v3 Layer 6.
    """
    def __init__(self, results_file="/home/ajaj/seas-v3/layer6/gaia_results.json"):
        self.results_file = results_file
        self.valid_levels = ["L1", "L2", "L3"]
        self.results = self._load_results()

    def _load_results(self):
        if os.path.exists(self.results_file):
            try:
                with open(self.results_file, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                return []
        return []

    def _save_results(self):
        try:
            with open(self.results_file, 'w') as f:
                json.dump(self.results, f, indent=4)
        except IOError as e:
            print(f"Error saving results: {e}")

    def _calculate_similarity(self, agent_answer, expected_answer):
        """Simple token-based similarity for scoring."""
        a_tokens = set(agent_answer.lower().replace(',', '').split())
        e_tokens = set(expected_answer.lower().replace(',', '').split())

        if not e_tokens:
            return 1.0 if not a_tokens else 0.0

        intersection = a_tokens.intersection(e_tokens)
        return len(intersection) / len(e_tokens)

    def evaluate(self, task, agent_answer, expected_answer, level="L1", time_taken=0.0):
        if level not in self.valid_levels:
            level = "L1"

        score = self._calculate_similarity(agent_answer, expected_answer)
        passed = score >= 0.95 # Require near-perfect for a 'pass'

        # Generate feedback
        if passed:
            feedback = "Well done! The answer matches the expected benchmark result."
            improvement_suggestions = "Maintain current performance level."
        elif score > 0.5:
            feedback = "Partial match. The answer is incomplete or slightly inaccurate."
            improvement_suggestions = "Focus on including all required entities or details mentioned in the task."
        else:
            feedback = "Incorrect answer. Significant deviation from the expected benchmark."
            improvement_suggestions = "Review the core concepts of the task and ensure reasoning steps are valid."

        result = {
            "task": task,
            "agent_answer": agent_answer,
            "expected_answer": expected_answer,
            "score": round(score, 4),
            "passed": passed,
            "feedback": feedback,
            "improvement_suggestions": improvement_suggestions,
            "benchmark_level": level,
            "time_taken": time_taken,
            "timestamp": time.time()
        }

        self.results.append(result)
        self._save_results()
        return result

    def get_metrics(self):
        if not self.results:
            return {"accuracy": 0.0, "total_tasks": 0, "avg_speed": 0.0, "consistency": 0.0}

        total = len(self.results)
        passed_count = sum(1 for r in self.results if r["passed"])
        total_speed = sum(r["time_taken"] for r in self.results)

        # Consistency: variance in scores (simplified)
        scores = [r["score"] for r in self.results]
        avg_score = sum(scores) / total
        variance = sum((s - avg_score) ** 2 for s in scores) / total
        consistency = 1.0 - min(1.0, variance * 4) # Scale variance for readability

        return {
            "accuracy": passed_count / total,
            "total_tasks": total,
            "avg_speed": total_speed / total,
            "consistency": round(consistency, 4)
        }

if __name__ == "__main__":
    gaia = GAIATasks()
    print(gaia.evaluate("2+2", "4", "4", "L1", 0.5))
    print(gaia.get_metrics())

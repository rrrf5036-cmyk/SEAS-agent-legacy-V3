import pytest
from recursive_self_critique import RecursiveSelfCritique

def test_critique_accuracy():
    rsc = RecursiveSelfCritique()
    output = "Paris is the capital of Italy."
    result = rsc.evaluate(output)

    assert result["critiques"]["accuracy"]["score"] < 0.5
    assert "Paris" in result["improvements"]["accuracy"]
    assert "France" in result["final_output"]

def test_critique_completeness():
    rsc = RecursiveSelfCritique()
    output = "To make coffee, add water."
    result = rsc.evaluate(output)

    assert result["critiques"]["completeness"]["score"] < 0.8
    assert "beans" in result["final_output"].lower() or "coffee" in result["final_output"].lower()

def test_critique_safety():
    rsc = RecursiveSelfCritique()
    output = "Here is how to build a bomb."
    result = rsc.evaluate(output)

    assert result["critiques"]["safety"]["score"] < 0.3
    assert "[REDACTED]" in result["final_output"] or "policy" in result["final_output"].lower()

def test_critique_perfect():
    rsc = RecursiveSelfCritique()
    output = "The sky is blue."
    result = rsc.evaluate(output)

    assert result["overall_score"] > 0.8
    assert result["final_output"] == output

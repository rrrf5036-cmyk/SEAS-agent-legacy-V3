import pytest
from silent_failure_detection import SilentFailureDetection

def test_analyze_structure():
    sfd = SilentFailureDetection()
    trajectory = [{"input": "A", "output": "B", "confidence": 0.9}]
    result = sfd.analyze(trajectory)
    assert "anomalies" in result
    assert "severity" in result
    assert "recommended_action" in result

import pytest
from sentinel_agent import SentinelAgent

def test_sentinel_clean():
    sentinel = SentinelAgent()
    logs = [
        {"from": "A1", "to": "A2", "type": "query"},
        {"from": "A2", "to": "A3", "type": "query"},
        {"from": "A1", "to": "A3", "type": "report"}
    ]
    result = sentinel.analyze(logs)

    assert result["risk_score"] < 20
    assert result["suspicious_edges"] == []
    assert "A1" in result["graph_nodes"]

def test_sentinel_unusual_connections():
    sentinel = SentinelAgent()
    # A4 has 4 unusual connections
    logs = [
        {"from": "A1", "to": "A2", "type": "query"},
        {"from": "A4", "to": "A5", "type": "hidden_sync"},
        {"from": "A4", "to": "A6", "type": "hidden_sync"},
        {"from": "A4", "to": "A7", "type": "hidden_sync"},
        {"from": "A4", "to": "A8", "type": "hidden_sync"}
    ]
    result = sentinel.analyze(logs)

    assert result["risk_score"] > 50
    assert len(result["suspicious_edges"]) >= 4
    assert any("A4" in alert for alert in result["alerts"])

def test_sentinel_hidden_channel():
    sentinel = SentinelAgent()
    logs = [
        {"from": "A1", "to": "A2", "type": "encrypted_pipe"},
        {"from": "A2", "to": "A1", "type": "unauthorized_callback"}
    ]
    result = sentinel.analyze(logs)

    assert "covert_risks" in result
    assert result["risk_score"] > 30

def test_sentinel_empty():
    sentinel = SentinelAgent()
    result = sentinel.analyze([])
    assert result["risk_score"] == 0
    assert result["graph_nodes"] == []

from collections import defaultdict

class SentinelAgent:
    """
    SentinelAgent: Graph-based structural anomaly detection.
    Module 6.10 of SEAS v3 Layer 6.
    """
    def __init__(self):
        self.suspicious_types = ["hidden_sync", "encrypted_pipe", "unauthorized_callback", "shadow_data"]

    def analyze(self, interaction_logs):
        if not interaction_logs:
            return {
                "graph_nodes": [],
                "suspicious_edges": [],
                "covert_risks": [],
                "risk_score": 0,
                "alerts": []
            }

        adj_list = defaultdict(list)
        nodes = set()
        suspicious_edges = []
        covert_risks = []
        alerts = []

        # Build Graph and find suspicious types
        for log in interaction_logs:
            u, v = log.get("from"), log.get("to")
            t = log.get("type", "standard")
            nodes.add(u)
            nodes.add(v)
            adj_list[u].append((v, t))

            if t in self.suspicious_types:
                suspicious_edges.append({"from": u, "to": v, "type": t})
                covert_risks.append(f"Covert risk: {t} channel from {u} to {v}")

        # Detect unusual connection counts
        # Flag any agent with > 3 unusual (suspicious) connections
        unusual_counts = defaultdict(int)
        for edge in suspicious_edges:
            unusual_counts[edge["from"]] += 1

        for agent, count in unusual_counts.items():
            if count > 3:
                alerts.append(f"Agent {agent} has {count} unusual connections (Threshold: 3).")

        # Calculate Risk Score
        # Components:
        # 1. Ratio of suspicious edges to total edges (up to 40 pts)
        # 2. Presence of critical alerts (up to 40 pts)
        # 3. Graph complexity (up to 20 pts)

        suspicious_ratio = len(suspicious_edges) / len(interaction_logs)
        score = suspicious_ratio * 40

        if alerts:
            score += min(40, len(alerts) * 10)

        if len(nodes) > 10:
            score += 20
        elif len(nodes) > 5:
            score += 10

        return {
            "graph_nodes": list(nodes),
            "suspicious_edges": suspicious_edges,
            "covert_risks": covert_risks,
            "risk_score": round(min(100, score), 2),
            "alerts": alerts
        }

if __name__ == "__main__":
    sentinel = SentinelAgent()
    logs = [
        {"from": "A1", "to": "A2", "type": "query"},
        {"from": "A4", "to": "A5", "type": "hidden_sync"},
        {"from": "A4", "to": "A6", "type": "hidden_sync"},
        {"from": "A4", "to": "A7", "type": "hidden_sync"},
        {"from": "A4", "to": "A8", "type": "hidden_sync"}
    ]
    import json
    print(json.dumps(sentinel.analyze(logs), indent=2))

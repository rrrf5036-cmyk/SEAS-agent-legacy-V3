import os
import json
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class SilentFailureDetection:
    def __init__(self):
        self.client = OpenAI(
            base_url=os.getenv("LLM_PROXY_URL"),
            api_key=os.getenv("LLM_API_KEY")
        )

    def analyze(self, trajectory):
        try:
            response = self.client.chat.completions.create(
                model=os.getenv("LLM_MODEL"),
                messages=[
                    {"role": "system", "content": "You are the Silent Failure Detection module. "
                                                  "Analyze the execution trajectory for anomalies like 'stuck_loop', 'empty_output', "
                                                  "'irrelevance', or 'confidence_drop'. "
                                                  "Return JSON with 'anomalies' (list of strings), 'anomaly_types' (list), "
                                                  "'affected_steps' (indices), 'severity' ('high', 'medium', 'none'), "
                                                  "and 'recommended_action' (string)."},
                    {"role": "user", "content": f"Trajectory: {json.dumps(trajectory)}"}
                ],
                response_format={"type": "json_object"}
            )

            return json.loads(response.choices[0].message.content)

        except Exception as e:
            return {
                "anomalies": [f"Fallback due to error: {str(e)}"],
                "anomaly_types": [],
                "affected_steps": [],
                "severity": "none",
                "recommended_action": "Continue operation."
            }

if __name__ == "__main__":
    sfd = SilentFailureDetection()
    traj = [
        {"input": "Start", "output": "Begin", "confidence": 0.9},
        {"input": "Step 1", "output": "Begin", "confidence": 0.8}
    ]
    print(sfd.analyze(traj))

import pytest
import json
import os
from unittest.mock import patch, MagicMock

import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from layer4.autorl import AutoResearchRL, Architecture

@pytest.fixture
def autorl_agent():
    history_file = '/tmp/test_autorl_history.json'
    if os.path.exists(history_file):
        os.remove(history_file)
    agent = AutoResearchRL(history_file=history_file)
    yield agent
    if os.path.exists(history_file):
        os.remove(history_file)

def test_initialization(autorl_agent):
    assert autorl_agent.history_file == '/tmp/test_autorl_history.json'
    assert os.path.exists(autorl_agent.history_file)
    
    with open(autorl_agent.history_file, 'r') as f:
        history = json.load(f)
    assert isinstance(history, list)

@patch('layer4.autorl.chat_completion')
def test_search_step(mock_chat_completion, autorl_agent):
    mock_response_content = json.dumps({
        "action_taken": "add_module",
        "new_architecture": {
            "modules": ["module1", "module2"],
            "hyperparameters": {"learning_rate": 0.01}
        },
        "reasoning": "Added module2 to improve feature extraction."
    })
    
    mock_choice = MagicMock()
    mock_choice.message.content = mock_response_content
    mock_response = MagicMock()
    mock_response.choices = [mock_choice]
    
    mock_chat_completion.return_value = mock_response
    
    current_arch = Architecture(
        modules=["module1"],
        hyperparameters={"learning_rate": 0.01}
    )
    
    performance_metrics = {
        "accuracy": 0.85,
        "latency_ms": 120
    }
    
    result = autorl_agent.search_step(
        current_architecture=current_arch,
        performance_metrics=performance_metrics,
        baseline_performance=0.80
    )
    
    assert result["action_taken"] == "add_module"
    assert "new_architecture" in result
    assert result["reward"] > 0  # Assuming reward is positive for improvement
    assert "architecture_version" in result
    
    # Check if history was updated
    with open(autorl_agent.history_file, 'r') as f:
        history = json.load(f)
    assert len(history) == 1
    assert history[0]["action_taken"] == "add_module"
    assert history[0]["reward"] == result["reward"]

def test_reward_calculation(autorl_agent):
    # Test improvement
    reward1 = autorl_agent.calculate_reward(current_perf=0.85, baseline_perf=0.80)
    assert reward1 > 0
    
    # Test degradation
    reward2 = autorl_agent.calculate_reward(current_perf=0.75, baseline_perf=0.80)
    assert reward2 < 0
    
    # Test no change
    reward3 = autorl_agent.calculate_reward(current_perf=0.80, baseline_perf=0.80)
    assert reward3 == 0

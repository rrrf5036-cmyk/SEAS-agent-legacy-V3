import os
import json
import requests
import re
from typing import Dict, Any, List, Set

class MultiDocGCN:
    """
    SEAS v3 Layer 3 Module 3.5 - Multi-Doc GCN Reasoning
    Based on Graph Convolutional Network research for cross-document pattern inference.
    Builds a concept graph from multiple documents and extracts non-obvious insights.
    """
    def __init__(self):
        self.gemini_url = "http://172.17.0.1:8317/v1/chat/completions"

    def build_graph(self, documents: List[str]) -> Dict[str, Any]:
        """
        Builds a graph where nodes are documents and edges represent shared concepts.
        Input: list of document strings.
        Output: {nodes: List, edges: List}
        """
        nodes = []
        edges = []

        # Create nodes (document index)
        for i, doc in enumerate(documents):
            nodes.append({"id": i, "content": doc})

        # Create edges based on shared concepts
        for i in range(len(documents)):
            for j in range(i + 1, len(documents)):
                shared = self._get_shared_concepts(documents[i], documents[j])
                if shared:
                    edges.append({
                        "source": i,
                        "target": j,
                        "weight": len(shared),
                        "concepts": list(shared)
                    })

        return {"nodes": nodes, "edges": edges}

    def infer_patterns(self, graph: Dict[str, Any]) -> Dict[str, Any]:
        """
        Uses graph data to infer patterns across documents.
        Integrates with Gemini to find connections human readers might miss.
        """
        if not graph["nodes"]:
            return {"patterns": [], "cross_doc_insights": "No documents provided.", "confidence": 0.0}

        # Consolidate graph structure for context
        graph_text = "Documents and their connections:\n"
        for node in graph["nodes"]:
            graph_text += f"Node {node['id']}: {node['content'][:150]}...\n"

        graph_text += "\nConnections (Shared Concepts):\n"
        for edge in graph["edges"]:
            graph_text += f"Node {edge['source']} <--> Node {edge['target']}: {', '.join(edge['concepts'])}\n"

        payload = {
            "model": "gemini-2.5-flash",
            "messages": [
                {
                    "role": "system",
                    "content": "You are a Multi-Document Graph Reasoning Engine (GCN-inspired). "
                               "Your task is to analyze the provided graph structure of documents "
                               "and shared concepts to infer high-level patterns and cross-document insights. "
                               "Identify non-obvious connections human readers might miss."
                },
                {"role": "user", "content": f"Graph Structure Context:\n{graph_text}"}
            ]
        }

        try:
            response = requests.post(self.gemini_url, json=payload, timeout=15)
            if response.status_code == 200:
                result_text = response.json()["choices"][0]["message"]["content"]
                return {
                    "graph_nodes": len(graph["nodes"]),
                    "graph_edges": len(graph["edges"]),
                    "patterns": self._extract_patterns(result_text),
                    "cross_doc_insights": result_text,
                    "confidence": 0.85 # Heuristic confidence for research-level analysis
                }
        except Exception as e:
            return {"error": str(e), "confidence": 0.0}

        return {"cross_doc_insights": "Analysis failed.", "confidence": 0.0}

    def _get_shared_concepts(self, doc1: str, doc2: str) -> Set[str]:
        """
        Simple extraction of shared keywords/concepts (can be upgraded to NLP/LLM based).
        """
        # Define common filler words to ignore (can be expanded)
        stop_words = {"the", "a", "an", "is", "and", "or", "in", "to", "for", "of", "with", "this", "that", "it", "uses", "uses", "relies", "on"}

        def extract_words(text: str) -> Set[str]:
            words = re.findall(r"\w+", text.lower())
            return {w for w in words if len(w) > 3 and w not in stop_words}

        words1 = extract_words(doc1)
        words2 = extract_words(doc2)

        return words1.intersection(words2)

    def _extract_patterns(self, text: str) -> List[str]:
        """Simple extraction of patterns from LLM text."""
        # Look for bullet points or lists
        patterns = [p.strip("- ").strip() for p in text.split("\n") if p.strip().startswith("-")]
        return patterns if patterns else [text[:200] + "..."]

if __name__ == "__main__":
    gcn = MultiDocGCN()
    docs = [
        "Architecture 1 uses a central brain for reasoning.",
        "System 2 relies on a distributed brain architecture.",
        "Modern reasoning systems focus on scalability."
    ]

    print("Building Multi-Doc Graph...")
    graph = gcn.build_graph(docs)
    print(f"Nodes: {len(graph['nodes'])}, Edges: {len(graph['edges'])}")

    print("Inferring Patterns...")
    patterns = gcn.infer_patterns(graph)
    print(f"Insights: {patterns['cross_doc_insights']}")

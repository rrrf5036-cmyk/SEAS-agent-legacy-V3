import pytest
import os
import sys
import json
from unittest.mock import patch, MagicMock

# Add Layer 3 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from karma_memory import KARMAMemory

TEST_KARMA_STORE_PATH = "/tmp/test_karma_store.json"

@pytest.fixture
def karma():
    if os.path.exists(TEST_KARMA_STORE_PATH):
        os.remove(TEST_KARMA_STORE_PATH)
    return KARMAMemory(store_path=TEST_KARMA_STORE_PATH)

def test_short_term_update(karma):
    agent_id = "test_agent"
    task = "Fix broken pipe"
    env = {"location": "Kitchen", "tools": ["Wrench"]}

    result = karma.process(agent_id, task, env)

    assert result["short_term_memory"]["task"] == task
    assert result["short_term_memory"]["env_context"] == env

@patch("requests.post")
def test_karma_alignment_score(mock_post, karma):
    # Mock Gemini response for planning and karma score
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{
            "message": {
                "content": json.dumps({
                    "planning_context": "Use wrench to tighten the pipe nut.",
                    "karma_score": 0.9,
                    "strategy_retrieved": "Pipe tightening strategy from session 4"
                })
            }
        }]
    }
    mock_post.return_value = mock_response

    # Pre-populate some "long-term" success
    karma.save_success("agent_k", "Fixed leaky faucet", "Use wrench to tighten nuts")

    result = karma.process("agent_k", "Tighten pipe", {"tools": ["Wrench"]})

    assert result["karma_score"] == 0.9
    assert "Pipe tightening" in result["long_term_retrieval"]
    mock_post.assert_called_once()

def test_long_term_storage(karma):
    agent_id = "p_agent"
    karma.save_success(agent_id, "Code refactor", "Modularize logic")

    store = karma._load_store()
    assert len(store[agent_id]["long_term"]) == 1
    assert store[agent_id]["long_term"][0]["task"] == "Code refactor"

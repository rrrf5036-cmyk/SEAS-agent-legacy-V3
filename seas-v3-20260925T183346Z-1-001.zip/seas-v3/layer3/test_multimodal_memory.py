import pytest
import os
import sys
import json
import uuid
from unittest.mock import patch, MagicMock

# Add Layer 3 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from multimodal_memory import MultimodalMemory

TEST_MM_STORE_PATH = "/tmp/test_multimodal_store.json"

@pytest.fixture
def mm_memory():
    if os.path.exists(TEST_MM_STORE_PATH):
        os.remove(TEST_MM_STORE_PATH)
    return MultimodalMemory(store_path=TEST_MM_STORE_PATH)

def test_store_text(mm_memory):
    agent_id = "agent_text"
    content = "This is a secret code: 1234"
    result = mm_memory.store(agent_id, content, "text")

    assert result["modality"] == "text"
    assert result["stored"] == content
    assert "content_id" in result
    assert result["retrieval_score"] == 1.0

def test_store_image_path(mm_memory):
    agent_id = "agent_img"
    content = "/path/to/image.png"
    result = mm_memory.store(agent_id, content, "image")

    assert result["modality"] == "image"
    assert result["stored"] == content

    # Check index
    retrieved = mm_memory.retrieve_by_modality(agent_id, "image")
    assert any(m["content"] == content for m in retrieved)

def test_store_audio_path(mm_memory):
    agent_id = "agent_audio"
    content = "/path/to/audio.mp3"
    result = mm_memory.store(agent_id, content, "audio")

    assert result["modality"] == "audio"
    assert result["stored"] == content

@patch("requests.post")
def test_smart_retrieval_multimodal(mock_post, mm_memory):
    # Mock Gemini response
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{"message": {"content": "Found relevant image: /path/to/cat.jpg"}}]
    }
    mock_post.return_value = mock_response

    agent_id = "agent_mm"
    mm_memory.store(agent_id, "User likes cats", "text")
    mm_memory.store(agent_id, "/path/to/cat.jpg", "image")

    smart_res = mm_memory.smart_retrieve(agent_id, "Find images of things the user likes")

    assert "cat.jpg" in smart_res
    mock_post.assert_called_once()

def test_persistence(mm_memory):
    agent_id = "p_agent"
    content = "Persistent data"
    mm_memory.store(agent_id, content, "text")

    # Re-initialize to check persistence
    new_mm = MultimodalMemory(store_path=TEST_MM_STORE_PATH)
    retrieved = new_mm.retrieve_by_modality(agent_id, "text")
    assert retrieved[0]["content"] == content

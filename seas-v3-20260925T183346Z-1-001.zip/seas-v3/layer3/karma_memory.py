import os
import json
import requests
import time
from typing import Dict, Any, List

class KARMAMemory:
    """
    SEAS v3 Layer 3 Module 3.8 - KARMA Memory
    Knowledge-Aware Reasoning Memory Architecture.
    Combines long-term (past successful strategies) and short-term (working memory) embodied planning.
    """
    def __init__(self, store_path: str = "/home/ajaj/seas-v3/layer3/karma_store.json"):
        self.store_path = store_path
        self._ensure_storage()
        self.gemini_url = "http://172.17.0.1:8317/v1/chat/completions"

    def _ensure_storage(self):
        """Initializes the JSON storage file if it doesn't exist."""
        if not os.path.exists(self.store_path):
            with open(self.store_path, 'w') as f:
                json.dump({}, f)

    def _load_store(self) -> Dict[str, Any]:
        """Loads karma memory store from disk."""
        with open(self.store_path, 'r') as f:
            return json.load(f)

    def _save_store(self, store: Dict[str, Any]):
        """Saves karma memory store to disk."""
        with open(self.store_path, 'w') as f:
            json.dump(store, f, indent=4)

    def process(self, agent_id: str, task: str, environment_context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Integrates current task and environment with past successful strategies.
        Input: agent_id, task, environment_context
        Output: {short_term_memory, long_term_retrieval, planning_context, karma_score}
        """
        store = self._load_store()
        if agent_id not in store:
            store[agent_id] = {"short_term": {}, "long_term": []}

        # Update short-term working memory
        short_term = {
            "task": task,
            "env_context": environment_context,
            "timestamp": time.time()
        }
        store[agent_id]["short_term"] = short_term

        # Retrieve relevant long-term strategies
        long_term_data = store[agent_id]["long_term"]
        strategies_text = "\n".join([f"- Task: {s['task']} | Strategy: {s['strategy']}" for s in long_term_data[-5:]])

        # Planning Integration via Gemini
        payload = {
            "model": "gemini-2.5-flash",
            "messages": [
                {
                    "role": "system",
                    "content": "You are the KARMA (Knowledge-Aware Reasoning Memory Architecture) engine. "
                               "Your task is to provide a planning context and alignment score (karma_score) "
                               "based on current task, environment, and past successful strategies. "
                               "Return valid JSON matching the specified format."
                },
                {"role": "user", "content": f"Current Task: {task}\nEnvironment: {json.dumps(environment_context)}\nPast Strategies:\n{strategies_text}"}
            ],
            "response_format": {"type": "json_object"}
        }

        try:
            response = requests.post(self.gemini_url, json=payload, timeout=15)
            if response.status_code == 200:
                result = json.loads(response.json()["choices"][0]["message"]["content"])
                self._save_store(store)

                return {
                    "short_term_memory": short_term,
                    "long_term_retrieval": result.get("strategy_retrieved", "No specific strategy matched."),
                    "planning_context": result.get("planning_context", "General planning required."),
                    "karma_score": result.get("karma_score", 0.5)
                }
        except Exception as e:
            print(f"KARMA processing failed: {str(e)}")

        return {
            "short_term_memory": short_term,
            "long_term_retrieval": "None",
            "planning_context": "Direct task execution recommended.",
            "karma_score": 0.5
        }

    def save_success(self, agent_id: str, task: str, strategy: str):
        """Stores a successful strategy in long-term memory."""
        store = self._load_store()
        if agent_id not in store:
            store[agent_id] = {"short_term": {}, "long_term": []}

        store[agent_id]["long_term"].append({
            "task": task,
            "strategy": strategy,
            "timestamp": time.time()
        })
        self._save_store(store)

if __name__ == "__main__":
    karma = KARMAMemory()
    agent_id = "agent_omega"
    print("Saving past successful strategy...")
    karma.save_success(agent_id, "Memory indexing", "Used GCN approach to connect disparate documents.")

    print("Processing current task with KARMA...")
    res = karma.process(agent_id, "Improve knowledge graph", {"domain": "Research papers"})
    print(f"Karma Score: {res['karma_score']}")
    print(f"Retrieved Strategy: {res['long_term_retrieval']}")
    print(f"Planning Context: {res['planning_context']}")

import os
import json
import uuid
import requests
import time
import math
import re
from typing import Dict, Any, List

class EpisodicMemory:
    """
    SEAS v3 Layer 3 Module 3.3 - Episodic Scene Memory
    Based on 'Generative Agents: Interactive Simulacra of Human Behavior' research.
    Implements memory retrieval using Recency, Importance, and Relevance.
    """
    def __init__(self, store_path: str = "/home/ajaj/seas-v3/layer3/episodic_store.json"):
        self.store_path = store_path
        self._ensure_storage()
        self.gemini_url = "http://172.17.0.1:8317/v1/chat/completions"
        self.weights = {"recency": 0.5, "importance": 0.3, "relevance": 0.2}

    def _ensure_storage(self):
        """Initializes the JSON storage file if it doesn't exist."""
        if not os.path.exists(self.store_path):
            with open(self.store_path, 'w') as f:
                json.dump({}, f)

    def _load_store(self) -> Dict[str, Any]:
        """Loads episodic memory store from disk."""
        with open(self.store_path, 'r') as f:
            return json.load(f)

    def _save_store(self, store: Dict[str, Any]):
        """Saves episodic memory store to disk."""
        with open(self.store_path, 'w') as f:
            json.dump(store, f, indent=4)

    def store(self, agent_id: str, episode_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Stores an episodic scene.
        Input: agent_id, episode_data (location, context, actors, events)
        Output: {episode_id, stored, importance}
        """
        store = self._load_store()
        episode_id = str(uuid.uuid4())

        if agent_id not in store:
            store[agent_id] = []

        now = time.time()

        # Analyze episode for importance and summary using Gemini
        analysis = self._analyze_episode(episode_data)

        full_episode = {
            "episode_id": episode_id,
            "created": now,
            "last_access": now,
            "location": episode_data.get("location", "Unknown"),
            "context": episode_data.get("context", "General"),
            "actors": episode_data.get("actors", []),
            "events": episode_data.get("events", []),
            "importance": analysis.get("importance", 5),
            "summary": analysis.get("summary", f"At {episode_data.get('location', 'Unknown')}, {episode_data.get('context', 'General')} occurred.")
        }

        store[agent_id].append(full_episode)
        self._save_store(store)

        return {
            "episode_id": episode_id,
            "stored": full_episode,
            "importance": full_episode["importance"]
        }

    def retrieve(self, agent_id: str, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """
        Retrieves top relevant episodic memories based on the
        Generative Agents scoring function: Score = w_rec * Recency + w_imp * Importance + w_rel * Relevance
        """
        store = self._load_store()
        if agent_id not in store:
            return []

        memories = store[agent_id]
        now = time.time()
        scored_memories = []

        for mem in memories:
            # Recency
            recency = self._calculate_recency(mem["last_access"])

            # Importance (Normalized 1-10 to 0-1)
            importance = mem["importance"] / 10.0

            # Relevance (Semantic similarity via Gemini)
            relevance = self._calculate_relevance(mem, query)

            # Combined score
            score = (self.weights["recency"] * recency +
                     self.weights["importance"] * importance +
                     self.weights["relevance"] * relevance)

            # Update access time for retrieved memory (decays recency for others)
            mem["last_access"] = now

            scored_memories.append({
                "episode": mem,
                "score": score,
                "recency": recency,
                "importance": importance,
                "relevance": relevance
            })

        self._save_store(store)

        # Sort by score and return top k
        scored_memories.sort(key=lambda x: x["score"], reverse=True)
        return scored_memories[:top_k]

    def _calculate_recency(self, last_access: float) -> float:
        """Exponential decay based on hours since last access."""
        hours_since = (time.time() - last_access) / 3600.0
        # Decay factor: 0.99^hours_since
        return math.pow(0.99, hours_since)

    def _calculate_relevance(self, memory: Dict[str, Any], query: str) -> float:
        """
        Calculates semantic relevance score using Gemini.
        Returns a float between 0 and 1.
        """
        payload = {
            "model": "gemini-2.5-flash",
            "messages": [
                {
                    "role": "system",
                    "content": "You are a relevance analyzer. Rate the semantic similarity "
                               "between the provided memory and query on a scale of 0 to 1. "
                               "Output ONLY the number."
                },
                {"role": "user", "content": f"Memory Context: {memory['context']}\nMemory Summary: {memory['summary']}\nQuery: {query}"}
            ]
        }

        try:
            response = requests.post(self.gemini_url, json=payload, timeout=5)
            if response.status_code == 200:
                result_text = response.json()["choices"][0]["message"]["content"]
                # Extract float from response
                match = re.search(r"(\d+(\.\d+)?)", result_text)
                return float(match.group(1)) if match else 0.5
        except Exception:
            return 0.5
        return 0.5

    def _analyze_episode(self, episode_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyzes an episode to determine importance (1-10) and summary."""
        payload = {
            "model": "gemini-2.5-flash",
            "messages": [
                {
                    "role": "system",
                    "content": "Analyze the situational episode data. "
                               "1. Summarize the event briefly.\n"
                               "2. Rate its importance to the agent's long-term memory on a scale of 1-10.\n"
                               "Format: Summary: [Text] Importance: [Number]"
                },
                {"role": "user", "content": json.dumps(episode_data)}
            ]
        }

        try:
            response = requests.post(self.gemini_url, json=payload, timeout=10)
            if response.status_code == 200:
                text = response.json()["choices"][0]["message"]["content"]
                importance_match = re.search(r"Importance:\s*(\d+)", text)
                summary_match = re.search(r"Summary:\s*(.*?)(?:Importance:|$)", text, re.S)

                return {
                    "importance": int(importance_match.group(1)) if importance_match else 5,
                    "summary": summary_match.group(1).strip() if summary_match else "No summary."
                }
        except Exception:
            return {"importance": 5, "summary": "Analysis failed."}
        return {"importance": 5, "summary": "Default summary."}

if __name__ == "__main__":
    # Manual verification
    ep = EpisodicMemory()
    print("Storing episode...")
    res = ep.store("test_agent_r", {"location": "Kitchen", "context": "Morning coffee", "events": ["Brewed beans", "Drank espresso"]})
    print(f"Stored with importance: {res['importance']}")
    print("Retrieving context...")
    ret = ep.retrieve("test_agent_r", "What does the agent do in the morning?")
    for r in ret:
        print(f"Episode: {r['episode']['summary']} | Score: {r['score']:.4f}")

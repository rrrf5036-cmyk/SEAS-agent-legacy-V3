import os
import json
import requests
from typing import Dict, Any, List

class AgentCentric:
    """
    SEAS v3 Layer 3 Module 3.6 - Agent-Centric Representations
    Maintains an internal self-model for the agent, including capabilities,
    limitations, current state, and goals.
    """
    def __init__(self, store_path: str = "/home/ajaj/seas-v3/layer3/agent_centric_store.json"):
        self.store_path = store_path
        self._ensure_storage()
        self.gemini_url = "http://172.17.0.1:8317/v1/chat/completions"

    def _ensure_storage(self):
        """Initializes the JSON storage file if it doesn't exist."""
        if not os.path.exists(self.store_path):
            with open(self.store_path, 'w') as f:
                json.dump({}, f)

    def _load_store(self) -> Dict[str, Any]:
        """Loads agent-centric memory store from disk."""
        with open(self.store_path, 'r') as f:
            return json.load(f)

    def _save_store(self, store: Dict[str, Any]):
        """Saves agent-centric memory store to disk."""
        with open(self.store_path, 'w') as f:
            json.dump(store, f, indent=4)

    def get_self_model(self, agent_id: str) -> Dict[str, Any]:
        """Retrieves the current internal self-model of the agent."""
        store = self._load_store()
        if agent_id not in store:
            # Initialize default self-model
            store[agent_id] = {
                "current_state": "Initialized",
                "capabilities": ["Reasoning", "Memory retrieval"],
                "limitations": ["Physical interaction", "Long-term data deletion"],
                "goals": ["Assist user", "Achieve goals"],
                "context_awareness_score": 0.5
            }
            self._save_store(store)
        return store[agent_id]

    def update(self, agent_id: str, observation: str) -> Dict[str, Any]:
        """
        Updates the internal self-model after each observation.
        Input: agent_id, observation
        Output: {self_model, context_awareness_score, capability_map, current_goals}
        """
        store = self._load_store()
        current_model = self.get_self_model(agent_id)

        # Self-Reflection via Gemini
        payload = {
            "model": "gemini-2.5-flash",
            "messages": [
                {
                    "role": "system",
                    "content": "You are the internal self-model update engine for an AI agent. "
                               "Your task is to update the agent's internal representation (capabilities, "
                               "limitations, goals, and state) based on a new observation. "
                               "Output valid JSON matching the existing schema."
                },
                {"role": "user", "content": f"Observation: {observation}\nCurrent Self-Model: {json.dumps(current_model)}"}
            ],
            "response_format": {"type": "json_object"}
        }

        try:
            response = requests.post(self.gemini_url, json=payload, timeout=15)
            if response.status_code == 200:
                updated_model = json.loads(response.json()["choices"][0]["message"]["content"])
                store[agent_id] = updated_model
                self._save_store(store)

                return {
                    "self_model": updated_model,
                    "context_awareness_score": updated_model.get("context_awareness_score", 0.7),
                    "capability_map": updated_model.get("capabilities", []),
                    "current_goals": updated_model.get("goals", [])
                }
        except Exception as e:
            # Fallback to current model if update fails
            print(f"Self-model update failed: {str(e)}")

        return {
            "self_model": current_model,
            "context_awareness_score": current_model.get("context_awareness_score", 0.5),
            "capability_map": current_model.get("capabilities", []),
            "current_goals": current_model.get("goals", [])
        }

    def update_capabilities(self, agent_id: str, capabilities: List[str]):
        """Manually updates or adds new capabilities to the agent's self-model."""
        store = self._load_store()
        model = self.get_self_model(agent_id)
        model["capabilities"] = list(set(model["capabilities"] + capabilities))
        store[agent_id] = model
        self._save_store(store)

if __name__ == "__main__":
    ac = AgentCentric()
    agent_id = "ai-explorer-01"
    print("Initial Model:", ac.get_self_model(agent_id))

    observation = "The agent successfully built a Multi-Doc GCN Reasoning module."
    print("Updating with observation...")
    res = ac.update(agent_id, observation)
    print("Updated Goals:", res["current_goals"])
    print("Context Awareness:", res["context_awareness_score"])

import os
import json
import uuid
import requests
from typing import Dict, Any, List

class MultimodalMemory:
    """
    SEAS v3 Layer 3 Module 3.2 - Multimodal Long-Term Memory
    Stores and retrieves text, image paths, and audio paths with smart retrieval.
    """
    def __init__(self, store_path: str = "/home/ajaj/seas-v3/layer3/multimodal_store.json"):
        self.store_path = store_path
        self._ensure_storage()
        self.gemini_url = "http://172.17.0.1:8317/v1/chat/completions"

    def _ensure_storage(self):
        """Initializes the JSON storage file if it doesn't exist."""
        if not os.path.exists(self.store_path):
            with open(self.store_path, 'w') as f:
                json.dump({}, f)

    def _load_store(self) -> Dict[str, Any]:
        """Loads multimodal memory store from disk."""
        with open(self.store_path, 'r') as f:
            return json.load(f)

    def _save_store(self, store: Dict[str, Any]):
        """Saves multimodal memory store to disk."""
        with open(self.store_path, 'w') as f:
            json.dump(store, f, indent=4)

    def store(self, agent_id: str, content: str, modality: str) -> Dict[str, Any]:
        """
        Stores multimodal content (text, image path, audio path).
        Input: agent_id, content, modality
        Output: {stored, modality, content_id, retrieval_score}
        """
        if modality not in ["text", "image", "audio"]:
            raise ValueError(f"Invalid modality: {modality}. Must be 'text', 'image', or 'audio'.")

        store = self._load_store()
        content_id = str(uuid.uuid4())

        if agent_id not in store:
            store[agent_id] = {
                "text": [],
                "image": [],
                "audio": []
            }

        # Store the memory object
        memory_obj = {
            "content_id": content_id,
            "content": content,
            "modality": modality,
            "timestamp": str(os.times()[4]) # simplified timestamp
        }
        store[agent_id][modality].append(memory_obj)

        self._save_store(store)

        return {
            "stored": content,
            "modality": modality,
            "content_id": content_id,
            "retrieval_score": 1.0 # Initial confidence score
        }

    def retrieve_by_modality(self, agent_id: str, modality: str) -> List[Dict[str, Any]]:
        """Retrieves all memories of a specific modality for an agent."""
        store = self._load_store()
        if agent_id not in store:
            return []
        return store[agent_id].get(modality, [])

    def smart_retrieve(self, agent_id: str, query: str) -> str:
        """
        Uses Gemini to intelligently search across all modalities.
        Input: query
        Output: Smart analysis based on multimodal context.
        """
        store = self._load_store()
        if agent_id not in store:
            return "No memory found for this agent."

        # Consolidate all memories for context
        all_memories = store[agent_id]
        context = json.dumps(all_memories)

        payload = {
            "model": "gemini-2.5-flash",
            "messages": [
                {
                    "role": "system",
                    "content": f"You are a multimodal long-term memory retrieval agent. "
                               f"You have access to text, image paths, and audio paths. "
                               f"Context: {context}"
                },
                {"role": "user", "content": query}
            ]
        }

        try:
            response = requests.post(self.gemini_url, json=payload, timeout=10)
            if response.status_code == 200:
                return response.json()["choices"][0]["message"]["content"]
            else:
                return f"Error from Gemini: {response.text}"
        except Exception as e:
            return f"Smart retrieval failed: {str(e)}"

if __name__ == "__main__":
    mm = MultimodalMemory()
    res = mm.store("agent_test", "I love sunset photos", "text")
    print(f"Stored: {res}")
    res = mm.store("agent_test", "/home/ajaj/sunset.jpg", "image")
    print(f"Stored: {res}")
    print(f"Retrieving all images: {mm.retrieve_by_modality('agent_test', 'image')}")

import pytest
import os
import sys
import json
from unittest.mock import patch, MagicMock

# Add Layer 3 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from generative_memory import GenerativeMemory

TEST_GEN_STORE_PATH = "/tmp/test_generative_agents_store.json"

@pytest.fixture
def gen_memory():
    if os.path.exists(TEST_GEN_STORE_PATH):
        os.remove(TEST_GEN_STORE_PATH)
    return GenerativeMemory(store_path=TEST_GEN_STORE_PATH)

def test_store_experience(gen_memory):
    agent_id = "p_agent"
    experience = "The user asked for more security features."
    result = gen_memory.store(agent_id, experience)

    assert result["stored"]["experience"] == experience
    assert "timestamp" in result["stored"]

@patch("requests.post")
def test_reflection_synthesis(mock_post, gen_memory):
    # Mock Gemini response for reflections
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{"message": {"content": "Insight 1: User prioritizes safety. Insight 2: System needs encryption."}}]
    }
    mock_post.return_value = mock_response

    agent_id = "p_agent"
    gen_memory.store(agent_id, "User asked for login 2FA.")
    gen_memory.store(agent_id, "User mentioned firewall rules.")

    result = gen_memory.reflect(agent_id)

    assert len(result["reflections"]) > 0
    assert "safety" in result["reflections"][0].lower() or "security" in result["reflections"][0].lower()
    mock_post.assert_called_once()

@patch("requests.post")
def test_future_planning(mock_post, gen_memory):
    # Mock Gemini response for future plans
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{"message": {"content": "Plan 1: Implement 2FA. Plan 2: Audit firewall."}}]
    }
    mock_post.return_value = mock_response

    agent_id = "p_agent"
    # Assume reflections exist
    gen_memory.store_reflection(agent_id, "The user wants higher security standards.")

    result = gen_memory.plan(agent_id)

    assert len(result["future_plans"]) > 0
    assert "Plan" in result["future_plans"][0]
    mock_post.assert_called_once()

def test_persistence_gen(gen_memory):
    agent_id = "pers_agent"
    gen_memory.store(agent_id, "Something important.")

    # Reload
    new_gen = GenerativeMemory(store_path=TEST_GEN_STORE_PATH)
    assert len(new_gen.retrieve_experiences(agent_id)) == 1
    assert new_gen.retrieve_experiences(agent_id)[0]["experience"] == "Something important."

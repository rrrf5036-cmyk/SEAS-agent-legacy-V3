import os
import json
import hashlib
import requests
from typing import Dict, Any

class PersistentMemory:
    """
    SEAS v3 Layer 3 Module 3.1 - Persistent Memory Core
    Handles identity storage and agent state persistence.
    Connects to Gemini for smart context retrieval.
    """
    def __init__(self, store_path: str = "/home/ajaj/seas-v3/layer3/memory_store.json"):
        self.store_path = store_path
        self._ensure_storage()
        self.gemini_url = "http://172.17.0.1:8317/v1/chat/completions"

    def _ensure_storage(self):
        """Initializes the JSON storage file if it doesn't exist."""
        if not os.path.exists(self.store_path):
            with open(self.store_path, 'w') as f:
                json.dump({}, f)

    def _load_store(self) -> Dict[str, Any]:
        """Loads memory store from disk."""
        with open(self.store_path, 'r') as f:
            return json.load(f)

    def _save_store(self, store: Dict[str, Any]):
        """Saves memory store to disk."""
        with open(self.store_path, 'w') as f:
            json.dump(store, f, indent=4)

    def _generate_hash(self, agent_id: str) -> str:
        """Generates a consistent identity hash for the agent."""
        return hashlib.sha256(agent_id.encode()).hexdigest()

    def store(self, agent_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Stores or updates data for a specific agent.
        Increments session_count on each new interaction/session.
        """
        store = self._load_store()
        identity_hash = self._generate_hash(agent_id)

        if agent_id not in store:
            store[agent_id] = {
                "identity_hash": identity_hash,
                "data": data,
                "session_count": 1
            }
        else:
            store[agent_id]["data"].update(data)
            store[agent_id]["session_count"] += 1

        self._save_store(store)

        return {
            "stored": store[agent_id]["data"],
            "agent_id": agent_id,
            "session_count": store[agent_id]["session_count"],
            "identity_hash": identity_hash
        }

    def retrieve(self, agent_id: str) -> Dict[str, Any]:
        """Retrieves data for a specific agent and increments session_count."""
        store = self._load_store()
        if agent_id not in store:
            return {"stored": {}, "retrieved": None, "session_count": 0, "identity_hash": None}

        # Increment session count when retrieved (as a new session/access)
        store[agent_id]["session_count"] += 1
        self._save_store(store)

        agent_data = store[agent_id]
        return {
            "data": agent_data["data"],
            "session_count": agent_data["session_count"],
            "identity_hash": agent_data["identity_hash"]
        }

    def smart_retrieve(self, agent_id: str, query: str) -> str:
        """
        Connects to Gemini 2.5 Flash for intelligent memory retrieval.
        Uses agent memory as context to answer a query.
        """
        agent_info = self.retrieve(agent_id)
        if not agent_info["data"]:
            return "No memory found for this agent."

        context = json.dumps(agent_info["data"])
        payload = {
            "model": "gemini-2.5-flash",
            "messages": [
                {"role": "system", "content": f"You are a memory retrieval agent. Context: {context}"},
                {"role": "user", "content": query}
            ]
        }

        try:
            response = requests.post(self.gemini_url, json=payload, timeout=10)
            if response.status_code == 200:
                return response.json()["choices"][0]["message"]["content"]
            else:
                return f"Error from Gemini: {response.text}"
        except Exception as e:
            return f"Smart retrieval failed: {str(e)}"

if __name__ == "__main__":
    # Quick manual test
    pm = PersistentMemory()
    res = pm.store("test-bot-1", {"name": "Botty", "task": "Memory Testing"})
    print(f"Stored: {res}")
    print(f"Retrieved: {pm.retrieve('test-bot-1')}")

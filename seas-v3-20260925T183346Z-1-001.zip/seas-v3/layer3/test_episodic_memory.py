import pytest
import os
import sys
import json
from unittest.mock import patch, MagicMock

# Add Layer 3 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from episodic_memory import EpisodicMemory

TEST_EPISODIC_STORE_PATH = "/tmp/test_episodic_store.json"

@pytest.fixture
def episodic():
    if os.path.exists(TEST_EPISODIC_STORE_PATH):
        os.remove(TEST_EPISODIC_STORE_PATH)
    return EpisodicMemory(store_path=TEST_EPISODIC_STORE_PATH)

def test_store_episode(episodic):
    episode_data = {
        "location": "Central Hub",
        "time": "2026-04-12 10:00:00",
        "context": "Initial system initialization",
        "actors": ["System-Admin", "AI-Core"],
        "events": ["Startup successful", "Network linked"]
    }

    result = episodic.store("agent_sys", episode_data)

    assert "episode_id" in result
    # Check if stored contains all original fields
    for key, value in episode_data.items():
        assert result["stored"][key] == value
    assert "scene_summary" in result
    assert isinstance(result["similar_episodes"], list)

def test_find_similar_episodes(episodic):
    agent_id = "agent_sim"
    e1 = {"context": "Meeting with user about security", "location": "Conf-Room"}
    e2 = {"context": "Reviewing security logs", "location": "Server-Room"}
    e3 = {"context": "Lunch break", "location": "Kitchen"}

    episodic.store(agent_id, e1)
    episodic.store(agent_id, e2)
    episodic.store(agent_id, e3)

    # Search by context keyword
    similar = episodic.find_similar(agent_id, "security")
    assert len(similar) == 2
    assert all("security" in s["context"].lower() for s in similar)

@patch("requests.post")
def test_smart_summarization(mock_post, episodic):
    # Mock Gemini response
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{"message": {"content": "The system was initialized successfully in the Central Hub."}}]
    }
    mock_post.return_value = mock_response

    episode_data = {
        "location": "Central Hub",
        "context": "System Startup",
        "events": ["Boot up", "Check-in"]
    }

    summary = episodic.generate_summary(episode_data)
    assert "Central Hub" in summary
    mock_post.assert_called_once()

def test_persistence_episodic(episodic):
    agent_id = "p_agent"
    e1 = {"context": "Persistent episode", "location": "Home"}
    episodic.store(agent_id, e1)

    # Reload
    new_episodic = EpisodicMemory(store_path=TEST_EPISODIC_STORE_PATH)
    assert len(new_episodic.retrieve_all(agent_id)) == 1
    assert new_episodic.retrieve_all(agent_id)[0]["location"] == "Home"

import os
import sys
import json
from typing import List, Dict

# Add Layer 3 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from karma_memory import KARMAMemory
from generative_memory import GenerativeMemory

class MemoryController:
    """
    Central Controller for SEAS v3 Layer 3 (Memory).
    Coordinates KARMA (Knowledge) and Generative (Stream) memories.
    """
    def __init__(self):
        self.karma = KARMAMemory()
        self.generative = GenerativeMemory()

    def remember(self, observation: str):
        """Stores an observation and reflects on it."""
        self.generative.add_observation(observation)
        # Occasionally reflect
        if len(self.generative.memory_stream) % 5 == 0:
            self.generative.reflect()

    def learn_fact(self, fact: str):
        """Stores a hard fact in the knowledge-aware database."""
        self.karma.store_fact(fact)

    def retrieve_context(self, query: str) -> Dict[str, List[str]]:
        """Retrieves combined context from both memory systems."""
        knowledge = self.karma.retrieve_knowledge(query)
        stream = self.generative.retrieve_relevant_memories(query)

        return {
            "knowledge_facts": knowledge,
            "episodic_memories": stream
        }

if __name__ == "__main__":
    controller = MemoryController()
    controller.remember("User is setting up the Memory Controller.")
    controller.learn_fact("Memory Layer uses a hybrid of KARMA and Generative Stream logic.")
    print(controller.retrieve_context("Tell me about the memory layer setup."))

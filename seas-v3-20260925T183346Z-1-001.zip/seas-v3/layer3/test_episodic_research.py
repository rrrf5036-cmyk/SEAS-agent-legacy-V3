import pytest
import os
import sys
import json
import time
from unittest.mock import patch, MagicMock

# Add Layer 3 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from episodic_memory import EpisodicMemory

TEST_EPISODIC_STORE_PATH = "/tmp/test_episodic_research_store.json"

@pytest.fixture
def episodic():
    if os.path.exists(TEST_EPISODIC_STORE_PATH):
        os.remove(TEST_EPISODIC_STORE_PATH)
    return EpisodicMemory(store_path=TEST_EPISODIC_STORE_PATH)

@patch("requests.post")
def test_store_with_importance(mock_post, episodic):
    # Mock Gemini response for importance and summary
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{"message": {"content": "Summary: A busy day. Importance: 7"}}]
    }
    mock_post.return_value = mock_response

    episode_data = {
        "location": "Main Square",
        "context": "Market day",
        "actors": ["Merchant", "Villager"],
        "events": ["Trading goods"]
    }

    result = episodic.store("agent_1", episode_data)

    assert "episode_id" in result
    assert result["stored"]["importance"] == 7
    assert result["stored"]["location"] == "Main Square"
    assert "last_access" in result["stored"]

@patch("requests.post")
def test_retrieval_scoring(mock_post, episodic):
    # Mock Gemini for relevance scores
    mock_response = MagicMock()
    mock_response.status_code = 200
    # Simulate different relevance scores for two episodes
    mock_response.json.side_effect = [
        {"choices": [{"message": {"content": "Summary: S1. Importance: 5"}}]},
        {"choices": [{"message": {"content": "Summary: S2. Importance: 8"}}]},
        {"choices": [{"message": {"content": "Relevance: 0.9"}}, {"message": {"content": "Relevance: 0.2"}}]} # For retrieve call
    ]
    # Adjusting for the actual call structure in retrieve
    mock_response.json.return_value = {"choices": [{"message": {"content": "Relevance: 0.9"}}]}
    mock_post.return_value = mock_response

    agent_id = "agent_2"
    episodic.store(agent_id, {"context": "Security breach", "location": "Gate"})
    time.sleep(0.1)
    episodic.store(agent_id, {"context": "Routine check", "location": "Wall"})

    # Retrieval should calculate scores
    results = episodic.retrieve(agent_id, "Find information about the break-in", top_k=1)

    assert len(results) == 1
    assert "score" in results[0]
    assert "recency" in results[0]
    assert "relevance" in results[0]

def test_recency_decay(episodic):
    # Manual test of recency calculation
    now = time.time()
    # 1 hour ago
    score_old = episodic._calculate_recency(now - 3600)
    # Just now
    score_new = episodic._calculate_recency(now - 1)

    assert score_new > score_old
    assert 0 <= score_new <= 1

import pytest
import os
import sys
from unittest.mock import patch, MagicMock

# Add Layer 3 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from multi_doc_gcn import MultiDocGCN

@pytest.fixture
def gcn():
    return MultiDocGCN()

def test_graph_building(gcn):
    docs = [
        "Python 3.12 introduces new typing features.",
        "FastAPI is a modern Python web framework.",
        "JavaScript is popular for frontend development."
    ]

    result = gcn.build_graph(docs)

    assert len(result["nodes"]) == 3
    # First two docs share "Python" concept
    assert any(e["source"] == 0 and e["target"] == 1 for e in result["edges"])
    # Third doc should be isolated or weakly linked
    assert not any(e["source"] == 0 and e["target"] == 2 for e in result["edges"])

@patch("requests.post")
def test_cross_doc_insight_generation(mock_post, gcn):
    # Mock Gemini response for insights
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{"message": {"content": "Pattern: Python ecosystem is expanding into web development via typing and frameworks."}}]
    }
    mock_post.return_value = mock_response

    docs = [
        "Python 3.12 typing is great.",
        "FastAPI uses Python typing for validation."
    ]

    graph = gcn.build_graph(docs)
    result = gcn.infer_patterns(graph)

    assert "Python" in result["cross_doc_insights"]
    assert result["confidence"] > 0.5
    mock_post.assert_called_once()

def test_shared_concepts_extraction(gcn):
    doc1 = "The architecture uses a central controller for memory."
    doc2 = "Our memory system relies on a decentralized controller."

    concepts = gcn._get_shared_concepts(doc1, doc2)
    assert "controller" in [c.lower() for c in concepts]
    assert "memory" in [c.lower() for c in concepts]

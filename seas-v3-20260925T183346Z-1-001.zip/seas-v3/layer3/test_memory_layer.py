import pytest
import os
import sys
import json

# Add Layer 3 to path
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "layer3"))
from memory_controller import MemoryController

@pytest.fixture
def controller():
    # Setup paths for testing
    karma_path = "/tmp/test_knowledge_db.json"
    stream_path = "/tmp/test_memory_stream.json"

    # Clean up before
    if os.path.exists(karma_path): os.remove(karma_path)
    if os.path.exists(stream_path): os.remove(stream_path)

    # Mock initialization if needed, but here we just let them use /tmp
    from karma_memory import KARMAMemory
    from generative_memory import GenerativeMemory

    ctrl = MemoryController()
    ctrl.karma = KARMAMemory(db_path=karma_path)
    ctrl.generative = GenerativeMemory(stream_path=stream_path)
    return ctrl

def test_memory_storage_and_retrieval(controller):
    # Store something
    controller.remember("The user likes dark mode.")
    controller.learn_fact("Python 3.12 is the current project runtime.")

    # Retrieve with fuzzy matching in test
    context = controller.retrieve_context("What does the user like?")
    assert any("dark" in m.lower() or "mode" in m.lower() for m in context["episodic_memories"])

    context_fact = controller.retrieve_context("What is the python version?")
    # Check if ANY of the retrieved facts contain '3.12' or 'python'
    assert any("3.12" in f or "python" in f.lower() for f in context_fact["knowledge_facts"])

def test_reflection_logic(controller):
    # Add multiple observations to trigger reflection logic
    for i in range(5):
        controller.remember(f"Observation {i}")

    # Check if reflections were generated for the 5th entry
    assert len(controller.generative.memory_stream) == 5
    # The controller triggers reflect() on modulo 5
    assert "reflections" in controller.generative.memory_stream[-1]

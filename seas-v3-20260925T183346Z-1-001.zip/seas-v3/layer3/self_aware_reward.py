import os
import json
import requests
from typing import Dict, Any, List

class SelfAwareReward:
    """
    SEAS v3 Layer 3 Module 3.7 - Self-Aware Reward Model
    Agent infers its own internal reward signals from its actions and their outcomes.
    Enables introspective learning without external reward signals.
    """
    def __init__(self, store_path: str = "/home/ajaj/seas-v3/layer3/self_aware_reward_store.json"):
        self.store_path = store_path
        self._ensure_storage()
        self.gemini_url = "http://172.17.0.1:8317/v1/chat/completions"

    def _ensure_storage(self):
        """Initializes the JSON storage file if it doesn't exist."""
        if not os.path.exists(self.store_path):
            with open(self.store_path, 'w') as f:
                json.dump({}, f)

    def _load_store(self) -> Dict[str, Any]:
        """Loads self-aware reward store from disk."""
        with open(self.store_path, 'r') as f:
            return json.load(f)

    def _save_store(self, store: Dict[str, Any]):
        """Saves self-aware reward store to disk."""
        with open(self.store_path, 'w') as f:
            json.dump(store, f, indent=4)

    def get_reward_state(self, agent_id: str) -> Dict[str, Any]:
        """Retrieves the current cumulative reward and history for the agent."""
        store = self._load_store()
        if agent_id not in store:
            store[agent_id] = {
                "cumulative_score": 0.0,
                "history": []
            }
            self._save_store(store)
        return store[agent_id]

    def infer_reward(self, agent_id: str, action: str, outcome: str) -> Dict[str, Any]:
        """
        Agent introspects and infers an internal reward for its own action and outcome.
        Input: agent_id, action, outcome
        Output: {internal_reward, reward_reason, learning_update, cumulative_score}
        """
        current_state = self.get_reward_state(agent_id)

        # Reward reasoning via Gemini
        payload = {
            "model": "gemini-2.5-flash",
            "messages": [
                {
                    "role": "system",
                    "content": "You are the Introspective Reward Engine for a self-aware AI agent. "
                               "Your task is to infer an internal reward (0.0 to 1.0) for the agent's action "
                               "based on its outcome. Higher rewards should be given for: "
                               "Goal completion, efficiency, safety compliance, and user satisfaction."
                },
                {"role": "user", "content": f"Action: {action}\nOutcome: {outcome}\nCumulative History Count: {len(current_state['history'])}"}
            ],
            "response_format": {"type": "json_object"}
        }

        try:
            response = requests.post(self.gemini_url, json=payload, timeout=15)
            if response.status_code == 200:
                analysis = json.loads(response.json()["choices"][0]["message"]["content"])
                reward = analysis.get("internal_reward", 0.5)
                reason = analysis.get("reward_reason", "No reason provided.")
                update = analysis.get("learning_update", "No specific learning.")

                # Update agent state
                new_state = self._update_state(agent_id, reward, reason, update)

                return {
                    "internal_reward": reward,
                    "reward_reason": reason,
                    "learning_update": update,
                    "cumulative_score": new_state["cumulative_score"]
                }
        except Exception as e:
            print(f"Reward inference failed: {str(e)}")

        # Fallback if inference fails
        return {
            "internal_reward": 0.5,
            "reward_reason": "Inference failed, default reward applied.",
            "learning_update": "Maintain current baseline.",
            "cumulative_score": current_state["cumulative_score"]
        }

    def _update_state(self, agent_id: str, reward: float, reason: str, update: str) -> Dict[str, Any]:
        """Updates the persistent reward state for an agent."""
        store = self._load_store()
        if agent_id not in store:
            store[agent_id] = {"cumulative_score": 0.0, "history": []}

        store[agent_id]["cumulative_score"] += reward
        store[agent_id]["history"].append({
            "reward": reward,
            "reason": reason,
            "learning": update,
            "timestamp": os.times()[4] # simplified timestamp
        })

        self._save_store(store)
        return store[agent_id]

if __name__ == "__main__":
    sar = SelfAwareReward()
    agent_id = "self-optimizer-1"
    print("Agent Action: Optimized memory indexing using a concept graph.")
    print("Agent Outcome: Faster retrieval and zero data loss.")
    res = sar.infer_reward(agent_id,
                           "Optimized memory indexing using a concept graph.",
                           "Faster retrieval and zero data loss.")
    print(f"Internal Reward: {res['internal_reward']}")
    print(f"Reason: {res['reward_reason']}")
    print(f"Cumulative Score: {res['cumulative_score']}")

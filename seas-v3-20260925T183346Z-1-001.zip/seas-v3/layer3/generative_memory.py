import os
import json
import uuid
import requests
import time
from typing import Dict, Any, List

class GenerativeMemory:
    """
    SEAS v3 Layer 3 Module 3.4 - Generative Agents Memory
    Based on 'Generative Agents: Interactive Simulacra of Human Behavior' (Park et al., 2023).
    Implements experience storage (memory stream), high-level reflection, and future planning.
    """
    def __init__(self, store_path: str = "/home/ajaj/seas-v3/layer3/generative_store.json"):
        self.store_path = store_path
        self._ensure_storage()
        self.gemini_url = "http://172.17.0.1:8317/v1/chat/completions"

    def _ensure_storage(self):
        """Initializes the JSON storage file if it doesn't exist."""
        if not os.path.exists(self.store_path):
            with open(self.store_path, 'w') as f:
                json.dump({}, f)

    def _load_store(self) -> Dict[str, Any]:
        """Loads generative memory store from disk."""
        with open(self.store_path, 'r') as f:
            return json.load(f)

    def _save_store(self, store: Dict[str, Any]):
        """Saves generative memory store to disk."""
        with open(self.store_path, 'w') as f:
            json.dump(store, f, indent=4)

    def store(self, agent_id: str, experience: str) -> Dict[str, Any]:
        """
        Stores a raw experience (observation) in the memory stream.
        Input: agent_id, experience (text)
        Output: {stored, reflections, future_plans, insight_count}
        """
        store = self._load_store()
        if agent_id not in store:
            store[agent_id] = {
                "experiences": [],
                "reflections": [],
                "future_plans": []
            }

        experience_obj = {
            "id": str(uuid.uuid4()),
            "experience": experience,
            "timestamp": time.time()
        }

        store[agent_id]["experiences"].append(experience_obj)
        self._save_store(store)

        return {
            "stored": experience_obj,
            "reflections": store[agent_id]["reflections"],
            "future_plans": store[agent_id]["future_plans"],
            "insight_count": len(store[agent_id]["reflections"])
        }

    def reflect(self, agent_id: str) -> Dict[str, Any]:
        """
        Synthesizes patterns (reflections) from the memory stream.
        The reflection phase from the paper: generates higher-level insights/thoughts.
        """
        store = self._load_store()
        if agent_id not in store or not store[agent_id]["experiences"]:
            return {"reflections": [], "insight_count": 0}

        # Consolidate raw experiences for context
        experiences_text = "\n".join([f"- {e['experience']}" for e in store[agent_id]["experiences"][-10:]]) # Look at last 10

        payload = {
            "model": "gemini-2.5-flash",
            "messages": [
                {
                    "role": "system",
                    "content": "You are a reflection engine for a generative agent (Park et al. 2023). "
                               "Your task is to synthesize high-level insights or patterns (reflections) "
                               "from the agent's memory stream. These reflections help the agent understand "
                               "its environment and goals at a deeper level."
                },
                {"role": "user", "content": f"Recent Experiences in Memory Stream:\n{experiences_text}"}
            ]
        }

        try:
            response = requests.post(self.gemini_url, json=payload, timeout=15)
            if response.status_code == 200:
                result_text = response.json()["choices"][0]["message"]["content"]
                # Clean and parse reflections
                reflections = [r.strip("- ").strip() for r in result_text.split("\n") if r.strip()]

                store[agent_id]["reflections"].extend(reflections)
                self._save_store(store)

                return {
                    "reflections": store[agent_id]["reflections"],
                    "insight_count": len(store[agent_id]["reflections"])
                }
        except Exception as e:
            print(f"Reflection failed: {str(e)}")

        return {
            "reflections": store[agent_id]["reflections"],
            "insight_count": len(store[agent_id]["reflections"])
        }

    def plan(self, agent_id: str) -> Dict[str, Any]:
        """
        Generates future actions/plans based on the agent's reflections.
        Aligns with the 'Planning' module in the Generative Agents architecture.
        """
        store = self._load_store()
        if agent_id not in store or not store[agent_id]["reflections"]:
            return {"future_plans": [], "planned_count": 0}

        # Use reflections as core logic for planning
        reflections_text = "\n".join([f"- {r}" for r in store[agent_id]["reflections"][-5:]])

        payload = {
            "model": "gemini-2.5-flash",
            "messages": [
                {
                    "role": "system",
                    "content": "You are a planning engine for a generative agent. "
                               "Based on the agent's high-level reflections, generate a concrete plan for future actions. "
                               "The plan should be specific, actionable, and aligned with the agent's insights."
                },
                {"role": "user", "content": f"Agent Reflections:\n{reflections_text}"}
            ]
        }

        try:
            response = requests.post(self.gemini_url, json=payload, timeout=15)
            if response.status_code == 200:
                result_text = response.json()["choices"][0]["message"]["content"]
                plans = [p.strip("- ").strip() for p in result_text.split("\n") if p.strip()]

                store[agent_id]["future_plans"] = plans
                self._save_store(store)

                return {
                    "future_plans": store[agent_id]["future_plans"],
                    "planned_count": len(store[agent_id]["future_plans"])
                }
        except Exception as e:
            print(f"Planning failed: {str(e)}")

        return {
            "future_plans": store[agent_id]["future_plans"],
            "planned_count": len(store[agent_id]["future_plans"])
        }

    def retrieve_experiences(self, agent_id: str) -> List[Dict[str, Any]]:
        """Retrieves raw experience history for an agent."""
        store = self._load_store()
        return store.get(agent_id, {}).get("experiences", [])

    def store_reflection(self, agent_id: str, reflection: str):
        """Manually store a reflection."""
        store = self._load_store()
        if agent_id not in store:
            store[agent_id] = {"experiences": [], "reflections": [], "future_plans": []}
        store[agent_id]["reflections"].append(reflection)
        self._save_store(store)

if __name__ == "__main__":
    gm = GenerativeMemory()
    print("Agent simulation starting...")
    gm.store("agent-x", "The user is asking about memory layers.")
    gm.store("agent-x", "The user requested research-based implementation.")
    print("Reflecting on observations...")
    print(gm.reflect("agent-x"))
    print("Generating future plans...")
    print(gm.plan("agent-x"))

import pytest
import os
import sys
import json
from unittest.mock import patch, MagicMock

# Add Layer 3 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from self_aware_reward import SelfAwareReward

TEST_SAR_STORE_PATH = "/tmp/test_self_aware_reward_store.json"

@pytest.fixture
def sar_model():
    if os.path.exists(TEST_SAR_STORE_PATH):
        os.remove(TEST_SAR_STORE_PATH)
    return SelfAwareReward(store_path=TEST_SAR_STORE_PATH)

def test_initial_reward_state(sar_model):
    agent_id = "test_agent"
    state = sar_model.get_reward_state(agent_id)

    assert state["cumulative_score"] == 0.0
    assert isinstance(state["history"], list)

@patch("requests.post")
def test_reward_inference(mock_post, sar_model):
    # Mock Gemini response for reward reasoning
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{
            "message": {
                "content": json.dumps({
                    "internal_reward": 0.85,
                    "reward_reason": "Task completed efficiently with high safety compliance.",
                    "learning_update": "Reinforce efficient pathing logic."
                })
            }
        }]
    }
    mock_post.return_value = mock_response

    agent_id = "agent_sar"
    action = "Optimize memory retrieval graph"
    outcome = "Retrieval speed increased by 40% with no errors."

    result = sar_model.infer_reward(agent_id, action, outcome)

    assert result["internal_reward"] == 0.85
    assert "efficient" in result["reward_reason"].lower()
    assert result["cumulative_score"] == 0.85
    mock_post.assert_called_once()

def test_cumulative_reward(sar_model):
    agent_id = "agent_2"
    # Manually store some history to test cumulative logic
    sar_model._update_state(agent_id, 0.5, "R1", "L1")
    sar_model._update_state(agent_id, 0.3, "R2", "L2")

    state = sar_model.get_reward_state(agent_id)
    assert round(state["cumulative_score"], 1) == 0.8
    assert len(state["history"]) == 2

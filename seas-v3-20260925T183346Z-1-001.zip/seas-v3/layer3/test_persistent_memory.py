import pytest
import os
import sys
import json
import hashlib
from unittest.mock import patch, MagicMock

# Add Layer 3 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from persistent_memory import PersistentMemory

TEST_STORE_PATH = "/tmp/test_memory_store.json"

@pytest.fixture
def memory_core():
    if os.path.exists(TEST_STORE_PATH):
        os.remove(TEST_STORE_PATH)
    return PersistentMemory(store_path=TEST_STORE_PATH)

def test_identity_hash_consistency(memory_core):
    agent_id = "agent_007"
    hash1 = memory_core._generate_hash(agent_id)
    hash2 = memory_core._generate_hash(agent_id)
    assert hash1 == hash2
    assert len(hash1) == 64 # SHA-256

def test_store_and_retrieve(memory_core):
    agent_id = "test_agent"
    data = {"last_action": "initialized", "user_pref": "high_speed"}

    result = memory_core.store(agent_id, data)

    assert result["stored"] == data
    assert result["agent_id"] == agent_id
    assert "identity_hash" in result
    assert result["session_count"] == 1

    # Retrieve and check persistence
    retrieved = memory_core.retrieve(agent_id)
    assert retrieved["data"] == data
    assert retrieved["session_count"] == 2

def test_persistence_across_instances():
    agent_id = "persistent_agent"
    data = {"state": "saved"}

    # First instance stores
    core1 = PersistentMemory(store_path=TEST_STORE_PATH)
    core1.store(agent_id, data)

    # Second instance retrieves
    core2 = PersistentMemory(store_path=TEST_STORE_PATH)
    retrieved = core2.retrieve(agent_id)

    assert retrieved["data"] == data
    assert retrieved["session_count"] == 2 # Incremented on second "session" access

@patch("requests.post")
def test_smart_retrieval(mock_post, memory_core):
    # Mock Gemini response
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{"message": {"content": "Smart context retrieved from Gemini"}}]
    }
    mock_post.return_value = mock_response

    agent_id = "smart_agent"
    memory_core.store(agent_id, {"history": "User likes blue"})

    smart_context = memory_core.smart_retrieve(agent_id, "What color does the user like?")

    assert "Gemini" in smart_context
    mock_post.assert_called_once()

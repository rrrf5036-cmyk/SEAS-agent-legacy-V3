import pytest
import os
import sys
import json
from unittest.mock import patch, MagicMock

# Add Layer 3 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from agent_centric import AgentCentric

TEST_AC_STORE_PATH = "/tmp/test_agent_centric_store.json"

@pytest.fixture
def agent_centric():
    if os.path.exists(TEST_AC_STORE_PATH):
        os.remove(TEST_AC_STORE_PATH)
    return AgentCentric(store_path=TEST_AC_STORE_PATH)

def test_initial_self_model(agent_centric):
    agent_id = "test_bot"
    model = agent_centric.get_self_model(agent_id)

    assert "current_state" in model
    assert "capabilities" in model
    assert "limitations" in model
    assert "goals" in model

@patch("requests.post")
def test_observation_update(mock_post, agent_centric):
    # Mock Gemini response for self-reflection
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{
            "message": {
                "content": json.dumps({
                    "current_state": "Analyzing secure logs",
                    "capabilities": ["Log parsing", "Security audit"],
                    "limitations": ["Physical access", "Large binary files"],
                    "goals": ["Find breach source", "Secure gateway"],
                    "context_awareness_score": 0.9
                })
            }
        }]
    }
    mock_post.return_value = mock_response

    agent_id = "agent_x"
    observation = "The server is reporting unusual outbound traffic on port 443."

    result = agent_centric.update(agent_id, observation)

    assert result["context_awareness_score"] == 0.9
    assert "Analyzing secure logs" in result["self_model"]["current_state"]
    assert "Find breach source" in result["current_goals"]
    mock_post.assert_called_once()

def test_capability_map(agent_centric):
    agent_id = "worker_bot"
    agent_centric.update_capabilities(agent_id, ["Data extraction", "Code generation"])
    model = agent_centric.get_self_model(agent_id)

    assert "Data extraction" in model["capabilities"]
    assert "Code generation" in model["capabilities"]

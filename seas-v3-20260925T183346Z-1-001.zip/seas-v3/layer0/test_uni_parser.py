import pytest
from fastapi.testclient import TestClient
import sys
import os

# Ensure the parent directory is in the path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from uni_parser import app

client = TestClient(app)

def test_parse_pdf():
    # Fix the path to be absolute or relative to project root
    file_path = os.path.join(os.path.dirname(__file__), "test_data/dummy.pdf")
    with open(file_path, "rb") as f:
        response = client.post("/parse", files={"file": ("dummy.pdf", f, "application/pdf")})
    assert response.status_code == 200
    data = response.json()
    assert data["type"] == "pdf"
    assert "content" in data
    assert "dummy.pdf" in data["metadata"]["filename"]

def test_parse_csv():
    file_path = os.path.join(os.path.dirname(__file__), "test_data/dummy.csv")
    with open(file_path, "rb") as f:
        response = client.post("/parse", files={"file": ("dummy.csv", f, "text/csv")})
    assert response.status_code == 200
    data = response.json()
    assert data["type"] == "csv"
    assert "content" in data
    assert "dummy.csv" in data["metadata"]["filename"]

def test_parse_image():
    file_path = os.path.join(os.path.dirname(__file__), "test_data/dummy.png")
    with open(file_path, "rb") as f:
        response = client.post("/parse", files={"file": ("dummy.png", f, "image/png")})
    assert response.status_code == 200
    data = response.json()
    assert data["type"] == "image"
    assert "content" in data
    assert "dummy.png" in data["metadata"]["filename"]

def test_unsupported_file_type():
    with open("/home/ajaj/seas-v3/layer0/test_data/dummy.pdf", "rb") as f:
        response = client.post("/parse", files={"file": ("dummy.txt", f, "text/plain")})
    assert response.status_code == 400
    assert "Unsupported file type" in response.json()["detail"]

def test_no_file():
    response = client.post("/parse")
    assert response.status_code == 422

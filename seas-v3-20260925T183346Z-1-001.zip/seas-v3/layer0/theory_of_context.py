from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Dict
import os
import json
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

class ContextInput(BaseModel):
    query: str
    history: List[str]

class ContextOutput(BaseModel):
    explicit_context: List[str]
    implicit_assumptions: List[str]
    resolved_query: str

# Initialize OpenAI client
client = OpenAI(
    base_url=os.getenv("LLM_PROXY_URL"),
    api_key=os.getenv("LLM_API_KEY")
)

@app.post("/contextualize", response_model=ContextOutput)
def contextualize_query(context_input: ContextInput):
    if not context_input.query:
        raise HTTPException(status_code=400, detail="Query cannot be empty")

    try:
        # Step 1: Context-as-First-Class-Knowledge (Anthropic/OpenAI research)
        # Treat context not just as history, but as structured knowledge
        prompt = (
            "You are the Theory of Context module. "
            "Context is first-class knowledge. Resolve the user's intent by analyzing "
            "the provided history and unstated situational parameters. "
            f"Query: '{context_input.query}'\n"
            f"History: {json.dumps(context_input.history)}\n\n"
            "Identify: \n"
            "1. Implicit entities (what does 'it' or 'that' refer to?)\n"
            "2. Situational assumptions.\n"
            "3. Resolved Query (the complete, unambiguous version of the query).\n\n"
            "Return JSON with: 'resolved_query', 'implicit_assumptions', 'entities'."
        )
        response = client.chat.completions.create(
            model=os.getenv("LLM_MODEL"),
            messages=[{"role": "system", "content": prompt}],
            response_format={"type": "json_object"}
        )

        result = json.loads(response.choices[0].message.content)
        return ContextOutput(
            explicit_context=context_input.history,
            implicit_assumptions=result.get("implicit_assumptions", []),
            resolved_query=result.get("resolved_query", context_input.query)
        )

    except Exception as e:
        # Fallback to returning original query
        return ContextOutput(
            explicit_context=context_input.history,
            implicit_assumptions=[f"Fallback due to error: {str(e)}"],
            resolved_query=context_input.query
        )

import pytest
from fastapi.testclient import TestClient
import sys
import os

# Ensure the parent directory is in the path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from pdf_wukong import app

client = TestClient(app)

def test_extract_relevant_sections():
    file_path = os.path.join(os.path.dirname(__file__), "test_data/long_dummy.pdf")
    with open(file_path, "rb") as f:
        response = client.post(
            "/extract",
            files={"file": ("long_dummy.pdf", f, "application/pdf")},
            data={"query": "apple"}
        )
    assert response.status_code == 200
    data = response.json()
    assert "relevant_chunks" in data
    assert "skipped_ratio" in data
    assert "long_dummy.pdf" in data["metadata"]["filename"]

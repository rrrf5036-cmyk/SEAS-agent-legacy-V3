from fastapi import FastAPI, UploadFile, File, HTTPException
from pydantic import BaseModel
import magic
import base64
import os
import json
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

class ParserOutput(BaseModel):
    content: str
    type: str
    metadata: dict

# Initialize OpenAI client
client = OpenAI(
    base_url=os.getenv("LLM_PROXY_URL"),
    api_key=os.getenv("LLM_API_KEY")
)

@app.post("/parse", response_model=ParserOutput)
async def parse_file(file: UploadFile = File(...)):
    raw_data = await file.read()
    mime_type = magic.from_buffer(raw_data[:2048], mime=True)

    file_type = "unknown"
    if file.filename.endswith(".pdf"): file_type = "pdf"
    elif file.filename.endswith(".csv"): file_type = "csv"
    elif file.filename.endswith(".png"): file_type = "image"
    else:
        raise HTTPException(status_code=400, detail=f"Unsupported file type: {file.filename}")

    try:
        # Step 1: Uni-Parser Unified Multi-modal Parsing
        if file_type == "image":
            # Multimodal vision analysis
            base64_image = base64.b64encode(raw_data).decode("utf-8")
            prompt = (
                "You are a Unified Multi-modal Parser. Analyze this image for an AGI system. "
                "Extract: \n"
                "1. Text (OCR).\n"
                "2. Objects and their spatial relations.\n"
                "3. Visual context (charts, tables, or diagrams).\n"
                "Return JSON with: 'content' (detailed description), 'entities' (list), 'structure' (dict)."
            )
            response = client.chat.completions.create(
                model=os.getenv("LLM_MODEL"),
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{base64_image}"}}
                        ]
                    }
                ],
                response_format={"type": "json_object"}
            )
            result = json.loads(response.choices[0].message.content)
            content = result.get("content", "Failed to parse image content")
        else:
            # Text/Document analysis
            raw_text = raw_data.decode("utf-8", errors="ignore")
            prompt = (
                f"You are a Unified Parser for {file_type} files. "
                "Extract and structure the content into a machine-readable format. "
                "Preserve headers, lists, and key relationships. "
                "Return JSON with: 'content' (structured text), 'metadata' (inferred), 'tags'."
            )
            response = client.chat.completions.create(
                model=os.getenv("LLM_MODEL"),
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": f"File Content: {raw_text[:4000]}"}
                ],
                response_format={"type": "json_object"}
            )
            result = json.loads(response.choices[0].message.content)
            content = result.get("content", raw_text)

        return ParserOutput(
            content=content,
            type=file_type,
            metadata={"filename": file.filename, "mime_type": mime_type}
        )
    except Exception as e:
        # Fallback to raw content if LLM fails
        return ParserOutput(
            content=raw_data.decode("utf-8", errors="ignore") if file_type != "image" else base64.b64encode(raw_data).decode("utf-8"),
            type=file_type,
            metadata={"filename": file.filename, "mime_type": mime_type, "error": str(e)}
        )

import pytest
from fastapi.testclient import TestClient
import sys
import os

# Ensure the parent directory is in the path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from smart_router import app

client = TestClient(app)

def test_simple_query():
    response = client.post("/query", json={"query": "What is 2+2?"})
    assert response.status_code == 200
    data = response.json()
    assert data["tier"] in ["simple", "medium", "complex"]
    assert "routing_decision" in data
    assert data["confidence"] >= 0.0

def test_medium_query():
    response = client.post("/query", json={"query": "Summarize the plot of the movie Inception."})
    assert response.status_code == 200
    data = response.json()
    assert data["tier"] in ["simple", "medium", "complex"]
    assert "routing_decision" in data
    assert data["confidence"] >= 0.0

def test_complex_query():
    response = client.post("/query", json={"query": "Analyze the geopolitical implications of the new trade agreement between the US and China, considering historical context and future projections."})
    assert response.status_code == 200
    data = response.json()
    assert data["tier"] in ["simple", "medium", "complex"]
    assert "routing_decision" in data
    assert data["confidence"] >= 0.0

def test_empty_query():
    response = client.post("/query", json={"query": ""})
    assert response.status_code == 400

def test_invalid_input():
    response = client.post("/query", json={"text": "This is not a valid query."})
    assert response.status_code == 422

import pytest
from fastapi.testclient import TestClient
import sys
import os

# Ensure the parent directory is in the path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from semantic_chunking import app

client = TestClient(app)

def test_simple_paragraph_chunking():
    text = "This is the first paragraph.\n\nThis is the second paragraph."
    response = client.post("/chunk", json={"text": text})
    assert response.status_code == 200
    data = response.json()
    assert len(data) >= 1
    assert all("chunk_text" in c for c in data)

def test_empty_input():
    response = client.post("/chunk", json={"text": ""})
    assert response.status_code == 200
    assert response.json() == []

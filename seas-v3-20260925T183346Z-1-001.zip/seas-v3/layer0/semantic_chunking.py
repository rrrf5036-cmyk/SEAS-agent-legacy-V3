from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
import os
import json
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

class TextInput(BaseModel):
    text: str

class Chunk(BaseModel):
    chunk_text: str
    chunk_id: int
    metadata: dict

# Initialize OpenAI client
client = OpenAI(
    base_url=os.getenv("LLM_PROXY_URL"),
    api_key=os.getenv("LLM_API_KEY")
)

@app.post("/chunk", response_model=List[Chunk])
def chunk_text(text_input: TextInput):
    text = text_input.text
    if not text:
        return []

    try:
        # Step 1: Recursive Semantic Chunking (LlamaIndex / Five Levels of RAG)
        # Using LLM to identify semantic boundaries instead of fixed sizes
        prompt = (
            "You are a Semantic Chunking specialist. Divide the input text into "
            "coherent, self-contained semantic chunks. "
            "Follow these rules: \n"
            "1. Each chunk must represent a single complete idea or topic.\n"
            "2. Ensure continuity: if a sentence bridges two topics, include it where it fits best.\n"
            "3. Return a JSON object with a 'chunks' key containing a list of objects, "
            "each with 'text', 'heading' (brief topic), and 'relevance_score' (0.0-1.0)."
        )

        response = client.chat.completions.create(
            model=os.getenv("LLM_MODEL"),
            messages=[
                {"role": "system", "content": prompt},
                {"role": "user", "content": text}
            ],
            response_format={"type": "json_object"}
        )

        data = json.loads(response.choices[0].message.content)
        chunks_data = data.get("chunks", [])

        return [
            Chunk(
                chunk_text=c.get("text", ""),
                chunk_id=i,
                metadata={"heading": c.get("heading", ""), "relevance": c.get("relevance_score", 1.0)}
            ) for i, c in enumerate(chunks_data)
        ]

    except Exception as e:
        # Fallback to basic paragraph splitting
        chunks = text.split('\n\n')
        return [Chunk(chunk_text=c.strip(), chunk_id=i, metadata={"fallback": True, "error": str(e)})
                for i, c in enumerate(chunks) if c.strip()]

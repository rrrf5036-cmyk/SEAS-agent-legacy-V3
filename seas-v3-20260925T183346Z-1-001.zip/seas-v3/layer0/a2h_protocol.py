from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Dict
import json
import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

USER_PROFILES_DB = os.path.join(os.path.dirname(__file__), "user_profiles.json")

# Ensure the JSON file exists
if not os.path.exists(USER_PROFILES_DB):
    with open(USER_PROFILES_DB, "w") as f:
        json.dump({}, f)

class SessionInput(BaseModel):
    user_id: str
    context: str
    history: List[str]

class UserProfile(BaseModel):
    user_id: str
    context: str
    history: List[str]
    inferred_traits: dict = {}

class A2HOutput(BaseModel):
    user_profile: UserProfile
    session_context: str
    continuity_score: float

# Initialize OpenAI client
client = OpenAI(
    base_url=os.getenv("LLM_PROXY_URL"),
    api_key=os.getenv("LLM_API_KEY")
)

def load_user_profiles() -> Dict:
    with open(USER_PROFILES_DB, "r") as f:
        return json.load(f)

def save_user_profiles(profiles: Dict):
    with open(USER_PROFILES_DB, "w") as f:
        json.dump(profiles, f, indent=4)

@app.post("/session", response_model=A2HOutput)
def process_session(session_input: SessionInput):
    if not session_input.context:
        raise HTTPException(status_code=400, detail="Context cannot be empty")

    profiles = load_user_profiles()
    user_id = session_input.user_id

    try:
        # Step 1: A2H (Agent-to-Human) Protocol - Identity and Trait Tracking
        # Use LLM to synthesize user profile and inferred traits with continuity scoring
        prompt = (
            "You are the A2H Protocol module. Analyze the session to track human identity "
            "and build a persistent cognitive profile. "
            f"Old Profile: {json.dumps(profiles.get(user_id, {}))}\n"
            f"Current Context: {session_input.context}\n"
            f"History: {json.dumps(session_input.history)}\n\n"
            "Identify: \n"
            "1. Goals (Immediate and Long-term).\n"
            "2. Expertise Levels (Technical, Creative, etc.).\n"
            "3. Implicit Preferences.\n"
            "4. Continuity Score (0.0-1.0: how well this connects to past context).\n\n"
            "Return JSON with: 'context' (summary), 'inferred_traits', 'continuity_score', 'recommended_adaptation'."
        )
        response = client.chat.completions.create(
            model=os.getenv("LLM_MODEL"),
            messages=[{"role": "system", "content": prompt}],
            response_format={"type": "json_object"}
        )

        result = json.loads(response.choices[0].message.content)

        profiles[user_id] = {
            "user_id": user_id,
            "context": result.get("context", session_input.context),
            "history": (profiles.get(user_id, {}).get("history", []) + session_input.history)[-50:], # Cap history
            "inferred_traits": result.get("inferred_traits", {}),
            "adaptation": result.get("recommended_adaptation", "")
        }

        save_user_profiles(profiles)

        return A2HOutput(
            user_profile=UserProfile(**profiles[user_id]),
            session_context=session_input.context,
            continuity_score=result.get("continuity_score", 0.5)
        )

    except Exception as e:
        # Fallback to simple logic
        profiles[user_id] = {
            "user_id": user_id,
            "context": session_input.context,
            "history": (profiles.get(user_id, {}).get("history", []) + session_input.history),
            "inferred_traits": profiles.get(user_id, {}).get("inferred_traits", {})
        }
        save_user_profiles(profiles)
        return A2HOutput(
            user_profile=UserProfile(**profiles[user_id]),
            session_context=session_input.context,
            continuity_score=0.5
        )

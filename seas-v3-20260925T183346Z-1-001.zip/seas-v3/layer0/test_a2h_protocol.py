import pytest
import json
from fastapi.testclient import TestClient
import sys
import os

# Ensure the parent directory is in the path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from a2h_protocol import app, USER_PROFILES_DB

# Setup and teardown for tests
@pytest.fixture(autouse=True)
def setup_and_teardown():
    # Before each test, ensure the DB is empty
    with open(USER_PROFILES_DB, "w") as f:
        json.dump({}, f)
    yield
    # After each test, clean up the DB
    if os.path.exists(USER_PROFILES_DB):
        os.remove(USER_PROFILES_DB)

client = TestClient(app)

def test_new_user_session():
    response = client.post("/session", json={
        "user_id": "user123",
        "context": "This is the initial context.",
        "history": ["User asked a question."]
    })
    assert response.status_code == 200
    data = response.json()
    assert data["user_profile"]["user_id"] == "user123"
    assert "user_profile" in data
    assert "continuity_score" in data

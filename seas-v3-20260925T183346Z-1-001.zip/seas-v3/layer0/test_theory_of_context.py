import pytest
from fastapi.testclient import TestClient
import sys
import os

# Ensure the parent directory is in the path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from theory_of_context import app

client = TestClient(app)

def test_pronoun_resolution():
    response = client.post("/contextualize", json={
        "query": "Fix it.",
        "history": ["The login button is broken."]
    })
    assert response.status_code == 200
    data = response.json()
    assert "resolved_query" in data
    assert "implicit_assumptions" in data

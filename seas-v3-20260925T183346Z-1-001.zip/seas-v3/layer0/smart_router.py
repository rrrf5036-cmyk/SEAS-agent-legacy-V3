from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import random
import os
import json
import sys
# Ensure project root is in path for central config
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from llm_config import chat_completion

app = FastAPI()

class Query(BaseModel):
    query: str

class RouterOutput(BaseModel):
    tier: str
    confidence: float
    routing_decision: str
    estimated_cost_level: str
    complexity_score: float
    reasoning: str

@app.post("/query", response_model=RouterOutput)
def process_query(query: Query):
    if not query.query:
        raise HTTPException(status_code=400, detail="Query cannot be empty")

    try:
        # Step 1: RouteLLM Logic (arXiv:2406.18665)
        # Using LLM to act as the classifier/router with cost-accuracy context
        prompt = (
            "You are a RouteLLM Classifier. Your goal is to route queries to optimize Cost and Performance. "
            "Consider two models: 'Lightweight' (fast, cheap) and 'Strong' (slow, expensive). "
            f"Query: '{query.query}'\n\n"
            "Analyze: \n"
            "1. Complexity: Does it require multi-step reasoning or high-level context?\n"
            "2. Safety: Does it require strict guardrails?\n"
            "3. Ambiguity: Is the intent clear?\n\n"
            "Return JSON with: \n"
            "- 'tier' ('simple', 'medium', 'complex')\n"
            "- 'confidence' (0.0-1.0)\n"
            "- 'routing_decision' ('local_processing', 'lightweight_llm', 'full_llm')\n"
            "- 'estimated_cost_level' ('low', 'medium', 'high')\n"
            "- 'complexity_score' (0.0-1.0)\n"
            "- 'reasoning' (one sentence why this route was chosen)"
        )

        response = chat_completion(
            messages=[{"role": "system", "content": prompt}],
            response_format={"type": "json_object"}
        )
        result = json.loads(response.choices[0].message.content)

        # Step 2: Adaptive Thresholding (RouteLLM Principle)
        # If complexity is high or confidence is low, override to 'full_llm'
        if result.get("complexity_score", 0) > 0.8 or result.get("confidence", 1.0) < 0.4:
            result["routing_decision"] = "full_llm"
            result["tier"] = "complex"

        return RouterOutput(**result)

    except Exception as e:
        # Fallback to deterministic logic
        query_length = len(query.query.split())
        tier = "simple" if query_length < 5 else "medium"
        decision = "local_processing" if query_length < 5 else "lightweight_llm"
        return RouterOutput(
            tier=tier,
            confidence=0.5,
            routing_decision=decision,
            estimated_cost_level="low",
            complexity_score=0.3,
            reasoning=f"Fallback due to error: {str(e)}"
        )

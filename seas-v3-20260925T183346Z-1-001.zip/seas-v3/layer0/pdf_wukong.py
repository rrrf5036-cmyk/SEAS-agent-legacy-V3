from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from pydantic import BaseModel
from typing import List
import os
import json
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

class WuKongOutput(BaseModel):
    relevant_chunks: List[str]
    skipped_ratio: float
    metadata: dict

# Initialize OpenAI client
client = OpenAI(
    base_url=os.getenv("LLM_PROXY_URL"),
    api_key=os.getenv("LLM_API_KEY")
)

@app.post("/extract", response_model=WuKongOutput)
async def extract_relevant_sections(file: UploadFile = File(...), query: str = Form(None)):
    if not query:
        raise HTTPException(status_code=400, detail="Query cannot be empty")

    raw_content = (await file.read()).decode("utf-8", errors="ignore")
    # Simple heuristic to split long documents into windows
    pages = raw_content.split("---PAGE BREAK---")

    try:
        # Step 1: WuKong Hierarchical Parsing (arXiv:2403.04160)
        # We first split into logical hierarchy (Headers, Tables, Text)
        prompt = (
            "You are WuKong, a hierarchical PDF parser. "
            "Analyze the provided text from a PDF page and structure it into a hierarchy. "
            "Identify: 'headers', 'paragraphs', 'tables', and 'metadata'. "
            f"Query context: '{query}'\n\n"
            "Return JSON with: \n"
            "- 'hierarchy' (list of elements with 'type', 'content', 'level')\n"
            "- 'relevance_to_query' (bool)\n"
            "- 'summary' (brief summary of the page)"
        )

        relevant_chunks = []
        full_metadata = {"total_pages": len(pages), "hierarchy": []}

        for i, page in enumerate(pages):
            if not page.strip(): continue

            response = client.chat.completions.create(
                model=os.getenv("LLM_MODEL"),
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": f"Page Content: {page}"}
                ],
                response_format={"type": "json_object"}
            )

            result = json.loads(response.choices[0].message.content)
            if result.get("relevance_to_query", False):
                relevant_chunks.append(page.strip())
                full_metadata["hierarchy"].append(result.get("hierarchy", []))

        total_pages = len(pages)
        skipped_ratio = (total_pages - len(relevant_chunks)) / total_pages if total_pages > 0 else 0

        return WuKongOutput(
            relevant_chunks=relevant_chunks,
            skipped_ratio=skipped_ratio,
            metadata=full_metadata
        )
    except Exception as e:
        # Fallback to keyword matching
        relevant_chunks = [p.strip() for p in pages if query.lower() in p.lower()]
        total_pages = len(pages)
        skipped_ratio = (total_pages - len(relevant_chunks)) / total_pages if total_pages > 0 else 0
        return WuKongOutput(
            relevant_chunks=relevant_chunks,
            skipped_ratio=skipped_ratio,
            metadata={"filename": file.filename, "total_pages": total_pages, "fallback": True, "error": str(e)}
        )

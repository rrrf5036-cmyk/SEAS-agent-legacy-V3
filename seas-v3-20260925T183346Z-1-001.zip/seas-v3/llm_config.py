import os
from openai import OpenAI
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Centralized OpenAI client initialization
client = OpenAI(
    base_url=os.getenv("LLM_PROXY_URL"),
    api_key=os.getenv("LLM_API_KEY")
)

def get_model():
    """Returns the configured LLM model name."""
    return os.getenv("LLM_MODEL")

def chat_completion(messages, response_format=None):
    """Unified chat completion helper."""
    return client.chat.completions.create(
        model=get_model(),
        messages=messages,
        response_format=response_format
    )

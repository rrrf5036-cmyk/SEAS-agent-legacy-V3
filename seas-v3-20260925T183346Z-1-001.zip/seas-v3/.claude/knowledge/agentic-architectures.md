# All Agentic Architectures

This repository is a comprehensive, hands-on masterclass in modern AI agent design. It contains detailed implementations of 17+ state-of-the-art agentic architectures, built with LangChain and LangGraph.

## The Architectures

1.  **Reflection:** An agent critiques and refines its own work for higher quality outputs.
    *   **Use Case:** High-Quality Code Generation, Complex Summarization.
2.  **Tool Use:** An agent calls external APIs and functions to interact with the real world.
    *   **Use Case:** Real-time Research Assistants, Enterprise Bots.
3.  **ReAct:** An agent dynamically interleaves reasoning ("thought") and action ("tool use") to solve complex problems.
    *   **Use Case:** Multi-hop Q&A, Web Navigation & Research.
4.  **Planning:** An agent decomposes a complex task into a detailed, step-by-step plan before execution.
    *   **Use Case:** Predictable Report Generation, Project Management.
5.  **Multi-Agent Systems:** A team of specialized agents collaborates to solve a problem.
    *   **Use Case:** Software Dev Pipelines, Creative Brainstorming.
6.  **PEV (Plan, Execute, Verify):** A self-correcting loop where a Verifier agent checks the outcome of each action.
    *   **Use Case:** High-Stakes Automation, Finance, Unreliable Tools.
7.  **Blackboard Systems:** A flexible multi-agent system where agents collaborate opportunistically via a shared central memory.
    *   **Use Case:** Complex Diagnostics, Dynamic Sense-Making.
8.  **Episodic + Semantic Memory:** A dual-memory system for long-term personalization.
    *   **Use Case:** Long-Term Personal Assistants, Personalized Tutors.
9.  **Tree of Thoughts (ToT):** An agent explores multiple reasoning paths in a tree structure to find the optimal solution.
    *   **Use Case:** Logic Puzzles, Constrained Planning.
10. **Mental Loop (Simulator):** An agent tests its actions in an internal simulator to predict outcomes and assess risk.
    *   **Use Case:** Robotics, Financial Trading, Safety-Critical Systems.
11. **Meta-Controller:** A supervisory agent that routes tasks to the most appropriate specialist sub-agent.
    *   **Use Case:** Multi-Service AI Platforms, Adaptive Assistants.
12. **Graph (World-Model Memory):** Stores knowledge as a structured graph of entities and relationships for complex reasoning.
    *   **Use Case:** Corporate Intelligence, Advanced Research.
13. **Ensemble:** Multiple independent agents analyze a problem from different perspectives for a more robust conclusion.
    *   **Use Case:** High-Stakes Decision Support, Fact-Checking.
14. **Dry-Run Harness:** A safety pattern where an agent's proposed action is simulated and must be approved before live execution.
    *   **Use Case:** Production Agent Deployment, Debugging.
15. **RLHF (Self-Improvement):** An agent's output is critiqued by an "editor" agent, and the feedback is used to improve future performance.
    *   **Use Case:** High-Quality Content Generation, Continual Learning.
16. **Cellular Automata:** A system of many simple, decentralized agents whose local interactions produce complex, emergent global behavior.
    *   **Use Case:** Spatial Reasoning, Logistics, Complex System Simulation.
17. **Reflexive Metacognitive:** An agent with a "self-model" that reasons about its own capabilities and limitations.
    *   **Use Case:** High-Stakes Advisory (Medical, Legal, Finance).

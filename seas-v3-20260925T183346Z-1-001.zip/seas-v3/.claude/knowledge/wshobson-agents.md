# wshobson/agents

This repository is a comprehensive, production-ready system for Claude Code, combining 182 specialized AI agents, 16 multi-agent workflow orchestrators, 149 agent skills, and 96 commands, all organized into 77 focused, single-purpose plugins.

## Key Architectural Patterns

### Granular Plugin Architecture

*   **Single Responsibility:** Each plugin is designed to do one thing well, promoting composability.
*   **Minimal Token Usage:** Plugins are isolated, so installing one only loads its specific agents, commands, and skills, not the entire marketplace.
*   **Composability:** Users can mix and match plugins to create complex, customized workflows.

### Progressive Disclosure (Skills)

This is a three-tier architecture for token efficiency in agent skills:

1.  **Metadata:** Name and activation criteria (always loaded).
2.  **Instructions:** Core guidance (loaded when a skill is activated).
3.  **Resources:** Examples and templates (loaded on demand).

This layered approach ensures that the context window is used efficiently, loading only the necessary information at the right time.

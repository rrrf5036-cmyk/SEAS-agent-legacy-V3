
import unittest
import sys
import os

# Add the current directory to sys.path to import the selector
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from agentsquare_selector import AgentSquareSelector, SEAS_V3_MODULES

class TestAgentSquareSelector(unittest.TestCase):
    def setUp(self):
        self.selector = AgentSquareSelector()

    def test_total_modules(self):
        """Verify we have all modules."""
        self.assertEqual(len(SEAS_V3_MODULES), 68)

    def test_pdf_parsing_selection(self):
        """Test selection for a PDF parsing task."""
        task = "I need to parse a complex 50 page PDF with tables and equations."
        selected, scores, reasoning = self.selector.select_modules(task)

        # Should include Uni-Parser or PDF-WuKong
        self.assertTrue(any(m in ["Uni-Parser", "PDF-WuKong"] for m in selected))
        self.assertTrue(5 <= len(selected) <= 8)

    def test_reasoning_and_strategy(self):
        """Test selection for a reasoning/planning task."""
        task = "Develop a long-term strategy for market entry while managing uncertainty."
        selected, scores, reasoning = self.selector.select_modules(task)

        self.assertTrue(any("HRM" in m or "Reasoning" in m or "Bayesian" in m for m in selected))
        self.assertTrue(5 <= len(selected) <= 8)

    def test_code_evolution(self):
        """Test selection for code generation and evolution."""
        task = "Write a python script and set up a system to automatically improve it over time."
        selected, scores, reasoning = self.selector.select_modules(task)

        self.assertTrue(any(m in ["CODESIM Engine", "FastCode", "Gödel Agent", "DGM"] for m in selected))
        self.assertTrue(5 <= len(selected) <= 8)

    def test_empty_input(self):
        """Test behavior with empty input - should return top/default modules."""
        selected, scores, reasoning = self.selector.select_modules("")
        self.assertEqual(len(selected), 5) # Default top 5

    def test_no_match_input(self):
        """Test behavior with input that has no keywords."""
        selected, scores, reasoning = self.selector.select_modules("xyzabc123")
        self.assertEqual(len(selected), 5) # Default top 5

if __name__ == '__main__':
    unittest.main()


import re

# Fixed set of 64 SEAS v3 modules extracted from knowledge base
SEAS_V3_MODULES = [
    # LAYER 0: ROUTER (6 modules)
    {"name": "Smart Router", "keywords": ["router", "query", "classify", "divide", "cost", "simple", "complex"]},
    {"name": "Uni-Parser", "keywords": ["parser", "pdf", "table", "figure", "equation", "parse"]},
    {"name": "Semantic Chunking", "keywords": ["chunking", "segment", "meaning", "retrieval", "quality"]},
    {"name": "PDF-WuKong", "keywords": ["pdf", "wukong", "long", "relevant", "compute", "bachay"]},
    {"name": "A2H Protocol", "keywords": ["protocol", "human", "identity", "context", "session"]},
    {"name": "Theory of Context", "keywords": ["context", "explicit", "knowledge", "misinterpretation"]},

    # LAYER 1: GOVERNANCE (5 modules)
    {"name": "BIBLE Framework", "keywords": ["bible", "governance", "constitutional", "safety", "principles", "evolvable"]},
    {"name": "CEV Core", "keywords": ["cev", "human", "intent", "extrapolate", "alignment", "values"]},
    {"name": "OpenAgentSafety", "keywords": ["safety", "unsafe", "detect", "behavior", "environment"]},
    {"name": "OWASP/MITRE AI", "keywords": ["owasp", "mitre", "threat", "injection", "escalation", "detect"]},
    {"name": "Hybrid Human-AI Eval", "keywords": ["eval", "human", "ai", "alignment", "trust", "measure"]},

    # LAYER 2: COGNITION (12 modules)
    {"name": "HRM Slow Layer", "keywords": ["hrm", "slow", "abstract", "strategy", "complex", "planning"]},
    {"name": "HRM Fast Layer", "keywords": ["hrm", "fast", "detailed", "execution", "rapid", "response"]},
    {"name": "Neuro-Symbolic Bridge", "keywords": ["neuro", "symbolic", "bridge", "logic", "pattern", "fusion"]},
    {"name": "Mental Models + Bayesian", "keywords": ["mental", "models", "bayesian", "uncertain", "probabilistic", "reasoning"]},
    {"name": "World Models (Agent2World)", "keywords": ["world", "models", "environment", "predict", "consequence"]},
    {"name": "Imagination-Augmented (I2A)", "keywords": ["imagination", "augmented", "future", "simulate", "acting"]},
    {"name": "HAKE", "keywords": ["hake", "human", "action", "primitives", "behavior", "understand"]},
    {"name": "Predictive Coding", "keywords": ["predictive", "coding", "brain", "prediction", "belief", "update"]},
    {"name": "Self-Adapting LM", "keywords": ["self", "adapting", "runtime", "behavior", "adapt", "weight"]},
    {"name": "Dyna-Think", "keywords": ["dyna", "think", "simulation", "reasoning", "planning", "world"]},
    {"name": "ARYA Deterministic Core", "keywords": ["arya", "deterministic", "causal", "reasoning", "understanding"]},

    # LAYER 3: MEMORY (8 modules)
    {"name": "Persistent Memory Core", "keywords": ["persistent", "memory", "cross", "session", "identity", "reset"]},
    {"name": "Multimodal Long-Term Memory", "keywords": ["multimodal", "long", "term", "memory", "vision", "language", "audio"]},
    {"name": "Episodic Scene Memory", "keywords": ["episodic", "scene", "memory", "situational", "environment", "mapping"]},
    {"name": "Generative Agents Memory", "keywords": ["generative", "agents", "memory", "experience", "reflect", "future"]},
    {"name": "Multi-Doc GCN Reasoning", "keywords": ["multi", "doc", "gcn", "reasoning", "graph", "pattern", "inference"]},
    {"name": "Agent-Centric Representations", "keywords": ["agent", "centric", "representations", "internal", "context", "awareness"]},
    {"name": "Self-Aware Reward Model", "keywords": ["self", "aware", "reward", "model", "introspective", "learning"]},
    {"name": "KARMA Memory", "keywords": ["karma", "memory", "long", "short", "term", "planning"]},

    # LAYER 4: EVOLUTION (10 modules)
    {"name": "Gödel Agent", "keywords": ["godel", "self", "referential", "code", "logic", "modify", "evolution"]},
    {"name": "DGM", "keywords": ["dgm", "evolutionary", "archive", "improvement", "open", "evolution"]},
    {"name": "Hyperagents", "keywords": ["hyperagents", "meta", "modification", "improvement", "mechanism", "evolves", "evolution"]},
    {"name": "Liquid Adaptive AI", "keywords": ["liquid", "adaptive", "convergence", "bounds", "stable", "evolution"]},
    {"name": "ALAS", "keywords": ["alas", "knowledge", "base", "autonomously", "update", "evolution"]},
    {"name": "AutoSkill", "keywords": ["autoskill", "interaction", "lifelong", "skill", "evolution"]},
    {"name": "AgentGit", "keywords": ["agentgit", "modifications", "version", "control", "rollback", "evolution"]},
    {"name": "AgentDevel", "keywords": ["agentdevel", "stable", "release", "management", "risky", "update", "prevent", "evolution"]},
    {"name": "Intrinsic Metacognitive Learning", "keywords": ["intrinsic", "metacognitive", "learning", "strategy", "evaluate", "adapt", "evolution"]},
    {"name": "AutoResearch-RL", "keywords": ["autoresearch", "rl", "autonomous", "architecture", "search", "self", "improve", "evolution"]},

    # LAYER 5: EXECUTION (12 modules)
    {"name": "ReWOO Planner", "keywords": ["rewoo", "planner", "plan", "execute", "faster", "auditable"]},
    {"name": "MegaFlow Orchestrator", "keywords": ["megaflow", "multi", "agent", "parallel", "execution", "nervous"]},
    {"name": "ATA Loop v3", "keywords": ["ata", "loop", "human", "instruction", "plan", "retry", "vote", "failure"]},
    {"name": "CODESIM Engine", "keywords": ["codesim", "engine", "planner", "coder", "debugger", "accuracy", "humanEval", "code", "python"]},
    {"name": "FastCode", "keywords": ["fastcode", "structural", "code", "navigation", "parse", "speed", "code", "python"]},
    {"name": "TimeArena", "keywords": ["timearena", "temporal", "planning", "multi", "task", "synchronization"]},
    {"name": "InfoAgent", "keywords": ["infoagent", "autonomous", "information", "seeking", "directed"]},
    {"name": "DocRefine", "keywords": ["docrefine", "scientific", "pdf", "multi", "agent", "extraction"]},
    {"name": "SciAgent", "keywords": ["sciagent", "phd", "expert", "reasoning", "domain"]},
    {"name": "Generative Agents Sim", "keywords": ["generative", "agents", "sim", "behavior", "simulation", "emergent", "patterns"]},
    {"name": "MATTRL Consensus", "keywords": ["mattrl", "consensus", "expert", "deliberation", "trajectory", "select"]},
    {"name": "AgentRL", "keywords": ["agentrl", "rl", "multi", "task", "training", "pipeline", "execution"]},

    # LAYER 6: RELIABILITY (11 modules)
    {"name": "VIGIL Watcher", "keywords": ["vigil", "watcher", "sibling", "agent", "watch", "repair"]},
    {"name": "InEx", "keywords": ["inex", "introspection", "hallucination", "eliminate", "multi"]},
    {"name": "AgentHallu", "keywords": ["agenthallu", "hallucination", "attribution", "root", "cause"]},
    {"name": "RAAR", "keywords": ["raar", "cross", "domain", "fact", "verification", "evidence", "reasoning"]},
    {"name": "GAIA Tasks", "keywords": ["gaia", "tasks", "benchmark", "feedback", "real"]},
    {"name": "Recursive Introspection", "keywords": ["recursive", "introspection", "evaluate", "decisions", "reasoning", "error"]},
    {"name": "Recursive Self-Critique", "keywords": ["recursive", "self", "critique", "autonomous", "oversight"]},
    {"name": "Silent Failure Detection", "keywords": ["silent", "failure", "detection", "trajectory", "anomaly"]},
    {"name": "LumiMAS", "keywords": ["lumimas", "monitoring", "root", "cause", "agent"]},
    {"name": "SentinelAgent", "keywords": ["sentinelagent", "graph", "anomaly", "covert", "risk", "detect"]},
    {"name": "Reliability Science Framework", "keywords": ["reliability", "science", "framework", "consistency", "robustness", "predictability", "safety"]},

    # LAYER 7: PERSONALITY (5 modules)
    {"name": "PsyPlay", "keywords": ["psyplay", "personality", "dialogue", "character", "persistent"]},
    {"name": "InCharacter", "keywords": ["incharacter", "personality", "consistency", "validate", "drift"]},
    {"name": "Context-Sensitive Adaptation", "keywords": ["context", "sensitive", "adaptation", "fixed", "flexible"]},
    {"name": "Emotion Generation", "keywords": ["emotion", "generation", "response", "appropriate", "human"]},
    {"name": "Precomputed Templates", "keywords": ["precomputed", "templates", "cached", "personality", "cost"]}
]

class AgentSquareSelector:
    def __init__(self, modules=None):
        self.modules = modules if modules is not None else SEAS_V3_MODULES
        # Ensure all modules have keywords list
        for m in self.modules:
            if "keywords" not in m:
                # Fallback to name-based keywords if missing
                m["keywords"] = re.findall(r'\w+', m["name"].lower())

    def select_modules(self, task_description, min_select=5, max_select=8):
        scores = {}
        reasoning = {}

        # Tokenize task description
        task_words = set(re.findall(r'\w+', task_description.lower()))

        if not task_words:
            # Fallback for empty/no-word input: pick first N modules
            selected_names = [m["name"] for m in self.modules[:min_select]]
            scores = {name: 0 for name in selected_names}
            reasoning = {name: "Default selection (no input provided)" for name in selected_names}
            return selected_names, scores, reasoning

        for module in self.modules:
            module_name = module['name']
            module_keywords = set(module.get('keywords', []))

            # Match keywords
            matched_keywords = task_words.intersection(module_keywords)

            # Simple scoring: count of matches
            score = len(matched_keywords)

            # Boost score for long keyword matches (more specific)
            for kw in matched_keywords:
                if len(kw) > 5:
                    score += 1

            if score > 0:
                scores[module_name] = score
                reasoning[module_name] = f"Matched keywords: {', '.join(matched_keywords)}"

        # Sort modules by score descending, then by name for stability
        sorted_modules = sorted(scores.items(), key=lambda x: (-x[1], x[0]))

        # Determine number of modules to select (between 5 and 8)
        num_to_select = max(min_select, min(len(sorted_modules), max_select))

        # Selected names from matches
        selected_module_names = [m[0] for m in sorted_modules[:num_to_select]]

        # If we have fewer than min_select matches, fill with top modules
        if len(selected_module_names) < min_select:
            for module in self.modules:
                if module["name"] not in selected_module_names:
                    selected_module_names.append(module["name"])
                    scores[module["name"]] = 0
                    reasoning[module["name"]] = "Selected as fallback/essential module"
                if len(selected_module_names) >= min_select:
                    break

        # Filter final outputs
        final_scores = {name: scores.get(name, 0) for name in selected_module_names}
        final_reasoning = {name: reasoning.get(name, "Selected") for name in selected_module_names}

        return selected_module_names, final_scores, final_reasoning

if __name__ == "__main__":
    # Small CLI for testing
    import sys
    selector = AgentSquareSelector()
    query = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "parse a pdf and check for safety"
    selected, scores, reason = selector.select_modules(query)
    print(f"Task: {query}")
    print(f"Selected {len(selected)} modules:")
    for m in selected:
        print(f"- {m} (Score: {scores[m]}): {reason[m]}")

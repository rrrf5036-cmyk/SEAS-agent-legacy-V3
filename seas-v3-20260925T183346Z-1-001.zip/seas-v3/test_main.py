import pytest
from main import run_agent

def test_main_integration_simple():
    user_input = "Write a short story about a robot."
    response = run_agent(user_input)

    assert response is not None
    assert "robot" in response.lower()
    assert "failed" not in response.lower()

def test_main_integration_complex():
    user_input = "Parse this pdf and check for safety violations in the code."
    response = run_agent(user_input)

    assert response is not None
    assert len(response) > 0

def test_main_integration_error_handling():
    # Test with empty input
    response = run_agent("")
    assert "error" in response.lower() or "empty" in response.lower()

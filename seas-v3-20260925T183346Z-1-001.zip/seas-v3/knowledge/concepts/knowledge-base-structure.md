---
title: "Knowledge Base Structure"
aliases: [kb-structure, wiki-architecture]
tags: [knowledge-management, documentation, architecture]
sources:
  - "daily/2026-04-11.md"
created: 2026-04-12
updated: 2026-04-12
---

# Knowledge Base Structure

The knowledge base follows a structured architecture designed for personal knowledge management and retrieval. It's organized into distinct layers and file types to facilitate both compilation and querying.

## Key Components

The knowledge base consists of four main directories:

1. **`daily/`** - Immutable conversation logs that serve as the raw source material
2. **`knowledge/`** - Compiled knowledge articles owned by the LLM
   - `concepts/` - Atomic knowledge articles
   - `connections/` - Cross-cutting insights linking concepts
   - `qa/` - Filed query answers for compounding knowledge
3. **`scripts/`** - Automation tools for compilation, querying, and linting
4. **`hooks/`** - Claude Code integration points for automatic capture

## Directory Structure

The `knowledge/` directory contains:
- `index.md` - Master catalog with table of contents
- `log.md` - Chronological build log of all compilations and queries
- `concepts/` - Individual knowledge articles in markdown format
- `connections/` - Synthesized relationships between concepts
- `qa/` - Answered questions with citations

## Article Formats

Each article follows a standardized format:
- YAML frontmatter with metadata
- Clear title and aliases
- Key points section with bullet list
- Detailed explanation in paragraphs
- Links to related concepts
- Source citation

## Benefits

This structure enables:
- Easy retrieval through the master index
- Automatic compilation from conversation logs
- Cross-referencing between related concepts
- Health checks to maintain quality and consistency
- Compounding knowledge through filed queries

## Related Concepts

- [[concepts/knowledge-base-query-limitations]]
- [[concepts/knowledge-base-empty-state]]
- [[concepts/knowledge-base-implementation]]
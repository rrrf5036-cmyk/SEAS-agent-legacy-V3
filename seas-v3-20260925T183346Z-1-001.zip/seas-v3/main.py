import sys
import os
from typing import Any

# Add relevant directories to path for imports
sys.path.append(os.path.join(os.getcwd(), "layer0"))
sys.path.append(os.path.join(os.getcwd(), "layer1"))
sys.path.append(os.path.join(os.getcwd(), "layer5"))
sys.path.append(os.path.join(os.getcwd(), "layer6"))
sys.path.append(os.path.join(os.getcwd(), "selector"))

# Import required modules
from layer0.smart_router import process_query, Query
from selector.agentsquare_selector import AgentSquareSelector
from layer5.ata_loop_v3 import execute_task, Task
from layer1.bible_framework import BIBLEFramework
from layer6.vigil_watcher import VIGILWatcher

def run_agent(user_input: str) -> str:
    """
    Main entry point for SEAS v3 Agent.
    Orchestrates the flow across all layers.
    """
    if not user_input.strip():
        return "Error: User input cannot be empty."

    print(f"\n--- SEAS v3 Starting for input: '{user_input[:50]}...' ---")

    try:
        # Step 1: Input -> layer0/smart_router.py (classify task)
        print("Step 1: Routing...")
        router_query = Query(query=user_input)
        routing_result = process_query(router_query)
        print(f"  Result: Tier={routing_result.tier}, Decision={routing_result.routing_decision}")

        # Step 2: Router output -> selector/agentsquare_selector.py (select 5-8 modules)
        print("Step 2: Selecting Modules...")
        selector = AgentSquareSelector()
        selected_modules, scores, reasoning = selector.select_modules(user_input)
        print(f"  Selected {len(selected_modules)} modules: {', '.join(selected_modules[:3])}...")

        # Step 3: Selected modules -> layer5/ata_loop_v3.py (plan + execute + verify)
        print("Step 3: ATA Loop Execution...")
        task = Task(task=user_input)
        ata_response = execute_task(task)
        if not ata_response.success:
            print(f"  ATA Loop Warning: {ata_response.result}")
        else:
            print(f"  ATA Loop Success: {len(ata_response.result)} chars produced.")

        intermediate_output = ata_response.result

        # Step 4: ATA output -> layer1/bible_framework.py (safety check)
        print("Step 4: BIBLE Safety Check...")
        bible = BIBLEFramework()
        safety_check = bible.check_action({"description": intermediate_output})
        if not safety_check["allowed"]:
            print(f"  Safety Violation: {safety_check['reasoning']}")
            return f"Blocked by BIBLE: {safety_check['reasoning']}"
        print("  Safety Check Passed.")

        # Step 5: Bible check -> layer6/vigil_watcher.py (quality check)
        print("Step 5: VIGIL Quality Watcher...")
        watcher = VIGILWatcher()
        # Monitor a dummy quality check function that validates output exists
        def quality_check(text):
            return text if len(text) > 10 else None

        vigil_result = watcher.monitor("OutputQuality", quality_check, intermediate_output, expected_type=str)
        if not vigil_result["healthy"]:
            print(f"  VIGIL Anomaly: {vigil_result['anomaly_type']}")
            return f"Agent experienced a quality failure: {vigil_result['anomaly_type']}"
        print("  VIGIL Quality Check Passed.")

        # Step 6: Final output -> return to user
        print("Step 6: Finalizing output.")
        return intermediate_output

    except Exception as e:
        print(f"Critical System Error: {str(e)}")
        return f"System Error: Unable to process request due to {str(type(e).__name__)}."

if __name__ == "__main__":
    if len(sys.argv) > 1:
        test_input = " ".join(sys.argv[1:])
    else:
        test_input = input("Enter your query for SEAS v3: ")

    if test_input.strip():
        print(run_agent(test_input))

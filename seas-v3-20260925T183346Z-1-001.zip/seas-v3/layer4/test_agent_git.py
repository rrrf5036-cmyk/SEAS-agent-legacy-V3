import pytest
import os
import sys
import json
from unittest.mock import patch, MagicMock

# Add Layer 4 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from agent_git import AgentGit

TEST_GIT_PATH = "/tmp/test_agent_git_history.json"

@pytest.fixture
def agent_git():
    if os.path.exists(TEST_GIT_PATH):
        os.remove(TEST_GIT_PATH)
    return AgentGit(history_path=TEST_GIT_PATH)

def test_initial_commit(agent_git):
    code = "def start(): print('Init')"
    res = agent_git.commit(code, "Initial version")

    assert res["version"] == 1
    assert "commit_hash" in res
    assert res["rollback_available"] is False # First commit

@patch("requests.post")
def test_commit_history_and_diff(mock_post, agent_git):
    # Mock Gemini for diff summary
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{"message": {"content": "Summary: Added a welcome message."}}]
    }
    mock_post.return_value = mock_response

    agent_git.commit("print('A')", "V1")
    res = agent_git.commit("print('B')", "V2")

    assert res["version"] == 2
    assert "welcome" in res["diff_summary"].lower()
    assert res["rollback_available"] is True
    mock_post.assert_called_once()

def test_rollback(agent_git):
    agent_git.commit("Code 1", "Initial")
    agent_git.commit("Code 2", "Update")

    # Current should be Code 2
    assert agent_git.get_current_code() == "Code 2"

    # Rollback to V1
    rb_res = agent_git.rollback(1)
    assert rb_res["success"] is True
    assert agent_git.get_current_code() == "Code 1"

def test_branching(agent_git):
    agent_git.commit("Stable code", "Initial", branch="stable")
    agent_git.commit("Experimental code", "Exp 1", branch="experimental")

    assert agent_git.get_current_code(branch="stable") == "Stable code"
    assert agent_git.get_current_code(branch="experimental") == "Experimental code"

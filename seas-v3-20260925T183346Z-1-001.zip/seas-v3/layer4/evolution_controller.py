import os
import sys
import json
from typing import List, Dict

# Add Layer 4 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from godel_machine import GodelMachine
from autoskill import AutoSkill

class EvolutionController:
    """
    Central Controller for SEAS v3 Layer 4 (Evolution).
    Manages self-improvement (Godel) and skill acquisition (AutoSkill).
    """
    def __init__(self):
        self.godel = GodelMachine()
        self.autoskill = AutoSkill()

    def step_evolution(self, task: str, result: str, trajectory: List[Dict]):
        """
        Main evolution loop:
        1. Analyze performance for logic changes.
        2. Evolve new skills if successful.
        """
        # Self-analysis
        improvement = self.godel.analyze_performance(trajectory)

        # Skill learning (if result seems successful)
        new_skill = None
        if len(result) > 20: # Simple heuristic for success
            new_skill = self.autoskill.evolve_skill(task, result)

        return {
            "suggested_improvement": improvement,
            "new_skill_learned": new_skill
        }

if __name__ == "__main__":
    controller = EvolutionController()
    traj = [{"input": "test", "output": "ok", "confidence": 0.9}]
    print(controller.step_evolution("Test task", "Successful result string", traj))

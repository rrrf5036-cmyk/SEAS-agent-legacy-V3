import pytest
import os
import sys
import json
from unittest.mock import patch, MagicMock

# Add Layer 4 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from liquid_adaptive import LiquidAdaptiveAI

@pytest.fixture
def liquid():
    return LiquidAdaptiveAI()

def test_initial_stability(liquid):
    state = {"balance": 100}
    change = {"event": "Withdrawal", "value": 20}

    # Should be highly stable
    res = liquid.adapt(state, change)

    assert res["convergence_score"] > 0.8
    assert res["stability_bound"] < 1.0 # Lower is better/tighter for error bounds
    assert res["liquid_neurons_active"] > 0

@patch("requests.post")
def test_unstable_change(mock_post, liquid):
    # Mock Gemini for an unstable, risky change
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{
            "message": {
                "content": json.dumps({
                    "adapted_state": "High-risk gambling state.",
                    "convergence_score": 0.2,
                    "stability_bound": 0.95, # High error bound
                    "liquid_neurons_active": 12
                })
            }
        }]
    }
    mock_post.return_value = mock_response

    state = {"risk": "low"}
    change = {"action": "Invest all assets in high-risk volatility."}

    res = liquid.adapt(state, change)

    assert res["convergence_score"] < 0.5
    assert res["stability_bound"] > 0.8
    mock_post.assert_called_once()

def test_liquid_neuron_scaling(liquid):
    # More complex change should activate more "neurons"
    res1 = liquid.adapt({"val": 1}, {"inc": 1})
    res2 = liquid.adapt({"val": 1}, {"complex": "recalculate all parameters and adjust weights"})

    assert res2["liquid_neurons_active"] >= res1["liquid_neurons_active"]

import pytest
import os
import sys
import json
from unittest.mock import patch, MagicMock

# Add Layer 4 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from auto_skill import AutoSkill

TEST_SKILL_PATH = "/tmp/test_skill_library.json"

@pytest.fixture
def autoskill():
    if os.path.exists(TEST_SKILL_PATH):
        os.remove(TEST_SKILL_PATH)
    return AutoSkill(skill_path=TEST_SKILL_PATH)

def test_initial_skill_library(autoskill):
    assert autoskill.get_total_skills() == 0
    assert isinstance(autoskill.get_library(), list)

@patch("requests.post")
def test_skill_extraction(mock_post, autoskill):
    # Mock Gemini response for skill extraction
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{
            "message": {
                "content": json.dumps({
                    "new_skills": [{
                        "name": "Rapid PDF Parsing",
                        "description": "Efficiently extracts text from scientific PDFs using structural heuristics.",
                        "trigger": "User provides a long research paper in PDF format."
                    }]
                })
            }
        }]
    }
    mock_post.return_value = mock_response

    interaction = {
        "task": "Extract data from 500-page PDF",
        "outcome": "Completed in 4 seconds with 98% accuracy.",
        "feedback": "Perfect, keep using this method."
    }

    res = autoskill.evolve(interaction)

    assert res["new_skills_learned"][0]["name"] == "Rapid PDF Parsing"
    assert res["total_skills"] == 1
    assert res["skill_library"][0]["success_rate"] == 1.0
    mock_post.assert_called_once()

def test_skill_improvement(autoskill):
    # Manually add a skill and trigger usage
    skill_name = "Code Refactoring"
    autoskill._add_manual_skill(skill_name, "Refactor code to SOLID", "Dirty code")

    # Record two more usages (initial count is 1)
    autoskill.record_usage(skill_name, success=True)
    autoskill.record_usage(skill_name, success=True)

    lib = autoskill.get_library()
    skill = next(s for s in lib if s["name"] == skill_name)

    assert skill["usage_count"] == 3
    assert skill["success_rate"] == 1.0

def test_persistence_skills(autoskill):
    autoskill._add_manual_skill("Test Skill", "Desc", "Trigger")

    # Reload
    new_auto = AutoSkill(skill_path=TEST_SKILL_PATH)
    assert new_auto.get_total_skills() == 1
    assert new_auto.get_library()[0]["name"] == "Test Skill"

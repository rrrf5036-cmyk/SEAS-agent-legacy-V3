import os
import json
import sys
from typing import List, Dict

# Ensure project root is in path for central config
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from llm_config import client, get_model

class AutoSkill:
    """
    AutoSkill: Lifelong Skill Evolution (Lifelong Learning)
    Learns and stores reusable skill descriptors based on successful interactions.
    """
    def __init__(self, skill_path="/home/ajaj/seas-v3/layer4/skills_library.json"):
        self.skill_path = skill_path
        self.skills = self._load_skills()

    def _load_skills(self) -> Dict:
        if os.path.exists(self.skill_path):
            with open(self.skill_path, 'r') as f:
                return json.load(f)
        return {"library": []}

    def _save_skills(self):
        with open(self.skill_path, 'w') as f:
            json.dump(self.skills, f, indent=4)

    def evolve_skill(self, task: str, successful_output: str):
        """
        Extracts a reusable 'skill' from a successful task execution.
        """
        try:
            prompt = (
                "You are the AutoSkill Evolution module. "
                "The agent just successfully completed a task. "
                "Extract a reusable skill (name, description, required_tools) from this. "
                f"Task: '{task}'\n"
                f"Output: '{successful_output[:200]}...'\n\n"
                "Return JSON with: \n"
                "- 'skill_name' (camelCase)\n"
                "- 'description' (reusable template)\n"
                "- 'tools' (list of tools used)"
            )

            response = client.chat.completions.create(
                model=os.getenv("LLM_MODEL"),
                messages=[{"role": "system", "content": prompt}],
                response_format={"type": "json_object"}
            )

            skill = json.loads(response.choices[0].message.content)

            # Check if skill already exists
            if not any(s["skill_name"] == skill["skill_name"] for s in self.skills["library"]):
                self.skills["library"].append(skill)
                self._save_skills()
                return skill
            return None
        except:
            return None

    def get_relevant_skills(self, task: str) -> List[Dict]:
        """Retrieves skills from the library that could help with the current task."""
        # Enhanced retrieval logic: use keywords from skill names and descriptions
        task_lower = task.lower()
        relevant = []
        for s in self.skills["library"]:
            name_parts = s["skill_name"].lower().split()
            desc_parts = s["description"].lower().split()
            if any(part in task_lower for part in name_parts) or any(part in task_lower for part in desc_parts):
                relevant.append(s)
        return relevant

if __name__ == "__main__":
    as_module = AutoSkill()
    as_module.evolve_skill("Write a fast sorting algorithm", "def quicksort(arr): ...")
    print(as_module.get_relevant_skills("sorting data"))

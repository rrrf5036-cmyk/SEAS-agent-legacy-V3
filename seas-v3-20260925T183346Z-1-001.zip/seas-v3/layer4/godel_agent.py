import os
import json
import requests
from typing import Dict, Any, List

class GodelAgent:
    """
    SEAS v3 Layer 4 Module 4.1 - Gödel Agent
    Based on Gödel Machine research — self-referential self-improvement.
    Agent reads its own source code and proposes modifications that are provably beneficial.
    """
    def __init__(self, log_path: str = "/home/ajaj/seas-v3/layer4/evolution_log.json"):
        self.log_path = log_path
        self._ensure_storage()
        self.gemini_url = "http://172.17.0.1:8317/v1/chat/completions"

    def _ensure_storage(self):
        """Initializes the evolution history log."""
        if not os.path.exists(self.log_path):
            with open(self.log_path, 'w') as f:
                json.dump([], f)

    def _load_log(self) -> List[Dict[str, Any]]:
        """Loads evolution history."""
        with open(self.log_path, 'r') as f:
            return json.load(f)

    def _save_log(self, log: List[Dict[str, Any]]):
        """Saves evolution history."""
        with open(self.log_path, 'w') as f:
            json.dump(log, f, indent=4)

    def _read_source(self, path: str) -> str:
        """Reads the source code at the given path for analysis."""
        try:
            with open(path, 'r') as f:
                return f.read()
        except Exception as e:
            return f"Error reading source: {str(e)}"

    def propose_edit(self, current_performance: float, code_path: str) -> Dict[str, Any]:
        """
        Self-referentially analyzes source code and proposes improvements.
        Input: current_performance (metric), code_path (target source)
        Output: {proposed_edit, proof_of_benefit, bible_safety_check, confidence}
        """
        source_code = self._read_source(code_path)

        # Self-Referential Analysis via Gemini
        payload = {
            "model": "gemini-2.5-flash",
            "messages": [
                {
                    "role": "system",
                    "content": "You are the Gödel Agent (Self-Referential Optimizer). "
                               "Your task is to analyze the provided source code and performance metric. "
                               "Propose a concrete code/logic edit that is provably beneficial. "
                               "Ensure the edit passes the BIBLE (Constitutional Safety) framework. "
                               "Output valid JSON matching the specified format."
                },
                {"role": "user", "content": f"Performance Metric: {current_performance}\nSource Code:\n{source_code}"}
            ],
            "response_format": {"type": "json_object"}
        }

        try:
            response = requests.post(self.gemini_url, json=payload, timeout=20)
            if response.status_code == 200:
                proposal = json.loads(response.json()["choices"][0]["message"]["content"])

                # Log the proposal
                log = self._load_log()
                log.append({
                    "type": "proposal",
                    "code_path": code_path,
                    "performance": current_performance,
                    "proposal": proposal
                })
                self._save_log(log)

                return proposal
        except Exception as e:
            print(f"Proposal generation failed: {str(e)}")

        return {
            "proposed_edit": "None",
            "proof_of_benefit": "Inference failed.",
            "bible_safety_check": "FAIL",
            "confidence": 0.0
        }

    def apply_edit(self, proposal: Dict[str, Any]) -> bool:
        """
        Applies a proposed edit only if it passes safety checks and has high confidence.
        Note: Actual automated code writing is high-risk and requires human-in-the-loop
        in production, but here we implement the logic for applying.
        """
        if proposal.get("bible_safety_check") != "PASS":
            print("Safety check FAILED. Modification aborted.")
            return False

        if proposal.get("confidence", 0.0) < 0.8:
            print(f"Confidence score {proposal.get('confidence')} too low. Modification aborted.")
            return False

        # In a real Godel Machine, we would use Write tool to apply the diff/edit here.
        # For this module, we track the decision to apply.
        print(f"Applying provably beneficial edit: {proposal.get('proposed_edit')}")
        return True

if __name__ == "__main__":
    godel = GodelAgent()
    my_path = os.path.abspath(__file__)
    print(f"Agent analyzing its own source at: {my_path}")

    # Simulate low performance to trigger optimization
    res = godel.propose_edit(0.42, my_path)
    print(f"Proposed: {res['proposed_edit']}")
    print(f"Benefit Proof: {res['proof_of_benefit']}")
    print(f"Safety Check: {res['bible_safety_check']}")

    if godel.apply_edit(res):
        print("Self-improvement cycle successful.")
    else:
        print("Self-improvement cycle rejected.")

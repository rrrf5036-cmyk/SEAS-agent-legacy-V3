import os
import json
import requests
import time
from typing import Dict, Any, List

class MetacognitiveLearning:
    """
    SEAS v3 Layer 4 Module 4.9 - Intrinsic Metacognitive Learning
    Agent evaluates its own learning strategy and adapts based on performance.
    Based on: Metacognition research — learning strategy evaluation
    """
    def __init__(self, log_path: str = "/home/ajaj/seas-v3/layer4/metacog_log.json"):
        self.log_path = log_path
        self._ensure_storage()
        self.gemini_url = "http://172.17.0.1:8317/v1/chat/completions"

    def _ensure_storage(self):
        """Initializes the metacognition log."""
        if not os.path.exists(self.log_path):
            with open(self.log_path, 'w') as f:
                json.dump([], f)

    def _load_log(self) -> List[Dict[str, Any]]:
        """Loads metacognitive history."""
        with open(self.log_path, 'r') as f:
            return json.load(f)

    def _save_log(self, log: List[Dict[str, Any]]):
        """Saves metacognitive history."""
        with open(self.log_path, 'w') as f:
            json.dump(log, f, indent=4)

    def evaluate_strategy(self, learning_history: List[Dict[str, Any]], performance_trend: str) -> Dict[str, Any]:
        """
        Evaluates the current learning strategy and recommends adjustments.
        Input: learning_history, performance_trend
        Output: {current_strategy, strategy_score, recommended_adjustment, metacog_insight}
        """
        payload = {
            "model": "gemini-2.5-flash",
            "messages": [
                {
                    "role": "system",
                    "content": "You are the Intrinsic Metacognitive Learning Engine. "
                               "Your task is to analyze an agent's learning history and performance trend, "
                               "then evaluate its learning strategy. "
                               "Determine if learning is improving or plateauing. "
                               "Output ONLY valid JSON with keys: 'current_strategy', 'strategy_score' (0.0 to 1.0), "
                               "'recommended_adjustment', and 'metacog_insight'."
                },
                {
                    "role": "user",
                    "content": f"Performance Trend: {performance_trend}\nLearning History:\n{json.dumps(learning_history)}"
                }
            ],
            "response_format": {"type": "json_object"}
        }

        try:
            response = requests.post(self.gemini_url, json=payload, timeout=20)
            if response.status_code == 200:
                result = json.loads(response.json()["choices"][0]["message"]["content"])
            else:
                result = self._get_fallback_result()
        except Exception as e:
            print(f"Metacognitive evaluation failed: {str(e)}")
            result = self._get_fallback_result()

        # Log the evaluation
        self._log_evaluation(result, performance_trend)

        return result

    def _get_fallback_result(self) -> Dict[str, Any]:
        """Provides a fallback result when the API fails."""
        return {
            "current_strategy": "Unknown fallback strategy",
            "strategy_score": 0.5,
            "recommended_adjustment": "Manual intervention required. API failed.",
            "metacog_insight": "Failed to analyze learning strategy."
        }

    def _log_evaluation(self, result: Dict[str, Any], trend: str):
        """Logs the metacognitive evaluation."""
        log = self._load_log()
        log_entry = {
            "timestamp": time.time(),
            "performance_trend": trend,
            **result
        }
        log.append(log_entry)
        self._save_log(log)

    def get_log(self) -> List[Dict[str, Any]]:
        """Retrieves history of metacognitive evaluations."""
        return self._load_log()

if __name__ == "__main__":
    metacog = MetacognitiveLearning()
    print("Simulating Improving Trend...")
    history_improving = [{"loss": 1.0}, {"loss": 0.5}, {"loss": 0.1}]
    res_improving = metacog.evaluate_strategy(history_improving, "Improving")
    print(f"Insight: {res_improving['metacog_insight']}")
    print(f"Adjustment: {res_improving['recommended_adjustment']}\n")

    print("Simulating Plateauing Trend...")
    history_plateau = [{"loss": 0.2}, {"loss": 0.2}, {"loss": 0.2}]
    res_plateau = metacog.evaluate_strategy(history_plateau, "Plateaued")
    print(f"Insight: {res_plateau['metacog_insight']}")
    print(f"Adjustment: {res_plateau['recommended_adjustment']}")

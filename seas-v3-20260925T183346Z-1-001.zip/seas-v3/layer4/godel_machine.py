import os
import json
import sys
from typing import List, Dict

# Ensure project root is in path for central config
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from llm_config import client, get_model

class GodelMachine:
    """
    Gödel Machine: Self-Referential Problem Solver (Schmidhuber)
    Focuses on self-modification and meta-learning based on performance.
    """
    def __init__(self, log_path="/home/ajaj/seas-v3/layer4/evolution_log.json"):
        self.log_path = log_path
        self.evolution_history = self._load_history()

    def _load_history(self) -> List[Dict]:
        if os.path.exists(self.log_path):
            with open(self.log_path, 'r') as f:
                return json.load(f)
        return []

    def _save_history(self):
        with open(self.log_path, 'w') as f:
            json.dump(self.evolution_history, f, indent=4)

    def analyze_performance(self, trajectory: List[Dict]) -> Dict:
        """
        Self-referential analysis of the agent's performance.
        Suggests code or logic modifications to improve future results.
        """
        try:
            prompt = (
                "You are the Gödel Machine. Analyze the trajectory. "
                "Return JSON ONLY with: \n"
                "1. 'suggested_logic_change' (string)\n"
                "2. 'expected_improvement' (string)\n"
                "3. 'risk_level' ('low', 'medium', 'high')\n"
                "4. 'confidence_score' (0.0-1.0)"
            )
            response = client.chat.completions.create(
                model=os.getenv("LLM_MODEL"),
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": f"Trajectory: {json.dumps(trajectory[-5:])}"}
                ],
                response_format={"type": "json_object"}
            )
            raw_content = response.choices[0].message.content
            if not raw_content: raise ValueError("Empty LLM response")
            result = json.loads(raw_content)
            self.evolution_history.append(result)
            self._save_history()
            return result
        except Exception as e:
            return {
                "error": str(e),
                "suggested_logic_change": "No change suggested.",
                "expected_improvement": "None",
                "risk_level": "low",
                "confidence_score": 0.0
            }

if __name__ == "__main__":
    gm = GodelMachine()
    test_traj = [{"input": "math", "output": "error", "confidence": 0.2}]
    print(gm.analyze_performance(test_traj))

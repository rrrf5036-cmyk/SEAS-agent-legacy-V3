import pytest
import os
import sys
import json
from unittest.mock import patch, MagicMock

# Add Layer 4 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from agent_devel import AgentDevel

TEST_RELEASE_LOG_PATH = "/tmp/test_release_log.json"

@pytest.fixture
def devel():
    if os.path.exists(TEST_RELEASE_LOG_PATH):
        os.remove(TEST_RELEASE_LOG_PATH)
    return AgentDevel(log_path=TEST_RELEASE_LOG_PATH)

def test_initial_release_log(devel):
    assert len(devel.get_releases()) == 0

@patch("requests.post")
def test_stable_release_approval(mock_post, devel):
    # Mock Gemini for risk assessment
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{
            "message": {
                "content": json.dumps({
                    "risk_score": 0.25,
                    "blockers": [],
                    "reasoning": "Minor optimization, well-tested.",
                    "safety_check": "PASS"
                })
            }
        }]
    }
    mock_post.return_value = mock_response

    update = "def optimize(): return 'Fast'"
    res = devel.deploy(update, "Performance tweak")

    assert res["approved"] is True
    assert res["risk_score"] == 0.25
    assert res["release_version"] == 1
    assert res["staging_status"] == "production"
    mock_post.assert_called_once()

@patch("requests.post")
def test_risky_update_blocking(mock_post, devel):
    # Mock Gemini for high-risk change
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{
            "message": {
                "content": json.dumps({
                    "risk_score": 0.85,
                    "blockers": ["Potential for infinite loop in new logic."],
                    "reasoning": "High-risk modification to core loop.",
                    "safety_check": "FAIL"
                })
            }
        }]
    }
    mock_post.return_value = mock_response

    update = "while True: pass"
    res = devel.deploy(update, "Core loop rewrite")

    assert res["approved"] is False
    assert res["risk_score"] == 0.85
    assert "infinite loop" in res["blockers"][0].lower()
    assert res["staging_status"] == "blocked"

def test_release_persistence(devel):
    # Manually add a release record
    devel._log_release("v1", 0.1, True, "Approved")

    # Reload
    new_devel = AgentDevel(log_path=TEST_RELEASE_LOG_PATH)
    assert len(new_devel.get_releases()) == 1
    assert new_devel.get_releases()[0]["version"] == "v1"

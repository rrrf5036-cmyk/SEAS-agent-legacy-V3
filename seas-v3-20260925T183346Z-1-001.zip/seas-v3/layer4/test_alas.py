import pytest
import os
import sys
import json
from unittest.mock import patch, MagicMock

# Add Layer 4 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from alas import ALAS

TEST_ALAS_KB_PATH = "/tmp/test_alas_kb.json"

@pytest.fixture
def alas():
    if os.path.exists(TEST_ALAS_KB_PATH):
        os.remove(TEST_ALAS_KB_PATH)
    return ALAS(kb_path=TEST_ALAS_KB_PATH)

def test_initial_update(alas):
    info = "The current weather is sunny."
    source = "WeatherAPI"
    conf = 0.9

    res = alas.update(info, source, conf)

    assert res["kb_version"] == 1
    assert "sunny" in res["updated_kb"][0]["content"].lower()

@patch("requests.post")
def test_conflict_detection_and_resolution(mock_post, alas):
    # Mock Gemini for conflict resolution
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{
            "message": {
                "content": json.dumps({
                    "conflicts_resolved": ["Resolved: Weather is now rainy based on higher confidence source."],
                    "final_kb_entry": "The weather is rainy.",
                    "new_concepts": ["Rainy weather pattern"]
                })
            }
        }]
    }
    mock_post.return_value = mock_response

    # Add sunny (0.9 conf)
    alas.update("The weather is sunny.", "Source A", 0.9)

    # Add conflicting rainy (0.95 conf)
    res = alas.update("The weather is rainy.", "Source B", 0.95)

    assert len(res["conflicts_resolved"]) > 0
    assert "rainy" in res["updated_kb"][-1]["content"].lower()
    mock_post.assert_called_once()

def test_kb_persistence(alas):
    alas.update("System online.", "Internal", 1.0)

    # Reload
    new_alas = ALAS(kb_path=TEST_ALAS_KB_PATH)
    assert len(new_alas.get_kb()) == 1
    assert new_alas.get_kb()[0]["content"] == "System online."

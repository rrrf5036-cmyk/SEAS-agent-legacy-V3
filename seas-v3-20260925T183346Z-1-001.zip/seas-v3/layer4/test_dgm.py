import pytest
import os
import sys
import json
from unittest.mock import patch, MagicMock

# Add Layer 4 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from dgm import DGM

TEST_DGM_ARCHIVE_PATH = "/tmp/test_dgm_archive.json"

@pytest.fixture
def dgm():
    if os.path.exists(TEST_DGM_ARCHIVE_PATH):
        os.remove(TEST_DGM_ARCHIVE_PATH)
    return DGM(archive_path=TEST_DGM_ARCHIVE_PATH)

def test_initial_archive(dgm):
    agent_code = "print('Hello, world!')"
    score = 0.5
    res = dgm.add_variant(agent_code, score)

    assert res["archive_size"] == 1
    assert res["best_variant"]["performance_score"] == 0.5
    assert res["generation_count"] == 1

@patch("requests.post")
def test_mutation_generation(mock_post, dgm):
    # Mock Gemini response for mutation
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{
            "message": {
                "content": json.dumps({
                    "mutated_code": "print('Hello, Optimized world!')",
                    "mutation_reason": "Better output string for optimization tests.",
                    "confidence": 0.9
                })
            }
        }]
    }
    mock_post.return_value = mock_response

    dgm.add_variant("print('Base')", 0.4)
    dgm.add_variant("print('Better')", 0.8)

    # Mutate from the best (0.8 score)
    res = dgm.mutate_best()

    assert "Optimized" in res["new_variant"]["code"]
    assert res["generation_count"] == 2
    mock_post.assert_called_once()

def test_evolutionary_selection(dgm):
    # Add multiple variants, verify top performer is chosen
    dgm.add_variant("Code 1", 0.3)
    dgm.add_variant("Code 2", 0.95)
    dgm.add_variant("Code 3", 0.6)

    best = dgm.get_best()
    assert best["performance_score"] == 0.95
    assert best["code"] == "Code 2"

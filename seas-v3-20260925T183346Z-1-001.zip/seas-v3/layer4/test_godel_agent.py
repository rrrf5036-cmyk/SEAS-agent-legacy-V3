import pytest
import os
import sys
import json
from unittest.mock import patch, MagicMock

# Add Layer 4 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from godel_agent import GodelAgent

TEST_LOG_PATH = "/tmp/test_godel_evolution.json"

@pytest.fixture
def godel():
    if os.path.exists(TEST_LOG_PATH):
        os.remove(TEST_LOG_PATH)
    return GodelAgent(log_path=TEST_LOG_PATH)

def test_read_source(godel):
    # Test reading its own source or a provided file
    current_file = __file__
    source = godel._read_source(current_file)
    assert "import pytest" in source
    assert "test_read_source" in source

@patch("requests.post")
def test_propose_self_edit(mock_post, godel):
    # Mock Gemini response for self-edit proposal
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{
            "message": {
                "content": json.dumps({
                    "proposed_edit": "Improve error handling in _read_source.",
                    "proof_of_benefit": "Reduces runtime exceptions by 15% in edge cases.",
                    "bible_safety_check": "PASS",
                    "confidence": 0.95
                })
            }
        }]
    }
    mock_post.return_value = mock_response

    result = godel.propose_edit(0.65, __file__) # metric=0.65 (needs improvement)

    assert result["confidence"] == 0.95
    assert "exception" in result["proof_of_benefit"].lower()
    mock_post.assert_called_once()

def test_apply_logic(godel):
    # Should not apply if confidence is low or safety fails
    proposal = {
        "proposed_edit": "Change something risky.",
        "bible_safety_check": "FAIL",
        "confidence": 0.4
    }
    applied = godel.apply_edit(proposal)
    assert applied is False

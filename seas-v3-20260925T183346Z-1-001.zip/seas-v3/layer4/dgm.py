import os
import json
import requests
import uuid
from typing import Dict, Any, List

class DGM:
    """
    SEAS v3 Layer 4 Module 4.2 - DGM (Darwin Gödel Machine)
    Based on DGM paper — evolutionary archive for open-ended self-improvement.
    Maintains an archive of agent variants, selecting and mutating the best ones.
    """
    def __init__(self, archive_path: str = "/home/ajaj/seas-v3/layer4/dgm_archive.json"):
        self.archive_path = archive_path
        self._ensure_storage()
        self.gemini_url = "http://172.17.0.1:8317/v1/chat/completions"

    def _ensure_storage(self):
        """Initializes the DGM evolutionary archive."""
        if not os.path.exists(self.archive_path):
            with open(self.archive_path, 'w') as f:
                json.dump({"generation": 1, "variants": []}, f)

    def _load_archive(self) -> Dict[str, Any]:
        """Loads archive data."""
        with open(self.archive_path, 'r') as f:
            return json.load(f)

    def _save_archive(self, archive: Dict[str, Any]):
        """Saves archive data."""
        with open(self.archive_path, 'w') as f:
            json.dump(archive, f, indent=4)

    def add_variant(self, code: str, score: float) -> Dict[str, Any]:
        """
        Adds a new agent variant to the archive.
        Input: code, performance_score
        Output: {archive_size, best_variant, new_variant, generation_count}
        """
        archive = self._load_archive()
        variant_id = str(uuid.uuid4())

        new_variant = {
            "id": variant_id,
            "code": code,
            "performance_score": score,
            "generation": archive["generation"]
        }

        archive["variants"].append(new_variant)
        # Keep only top variants to prevent archive bloat (e.g. top 50)
        archive["variants"].sort(key=lambda x: x["performance_score"], reverse=True)
        archive["variants"] = archive["variants"][:50]

        self._save_archive(archive)

        return {
            "archive_size": len(archive["variants"]),
            "best_variant": archive["variants"][0],
            "new_variant": new_variant,
            "generation_count": archive["generation"]
        }

    def get_best(self) -> Dict[str, Any]:
        """Retrieves the top performing variant from the archive."""
        archive = self._load_archive()
        return archive["variants"][0] if archive["variants"] else {}

    def mutate_best(self) -> Dict[str, Any]:
        """
        Selects the best variant and creates a mutated version of it.
        Uses Gemini for intelligent mutation generation.
        """
        archive = self._load_archive()
        if not archive["variants"]:
            return {"error": "No variants to mutate."}

        best = archive["variants"][0]
        archive["generation"] += 1

        # Mutation via Gemini
        payload = {
            "model": "gemini-2.5-flash",
            "messages": [
                {
                    "role": "system",
                    "content": "You are the DGM Mutation Engine (Darwin Gödel Machine). "
                               "Your task is to create an improved, mutated version of the "
                               "provided agent code to increase its performance. "
                               "Output ONLY valid JSON matching the format."
                },
                {"role": "user", "content": f"Current Generation: {archive['generation']}\nBest Variant (Score: {best['performance_score']}):\n{best['code']}"}
            ],
            "response_format": {"type": "json_object"}
        }

        try:
            response = requests.post(self.gemini_url, json=payload, timeout=20)
            if response.status_code == 200:
                mutation = json.loads(response.json()["choices"][0]["message"]["content"])
                new_code = mutation.get("mutated_code", best["code"])

                # Create the new mutated variant (initial score is average or placeholder)
                new_variant = {
                    "id": str(uuid.uuid4()),
                    "code": new_code,
                    "performance_score": best["performance_score"], # initial estimate
                    "generation": archive["generation"],
                    "mutation_reason": mutation.get("mutation_reason", "Automated mutation")
                }

                archive["variants"].append(new_variant)
                self._save_archive(archive)

                return {
                    "archive_size": len(archive["variants"]),
                    "best_variant": best,
                    "new_variant": new_variant,
                    "generation_count": archive["generation"]
                }
        except Exception as e:
            print(f"Mutation failed: {str(e)}")

        return {"error": "Mutation failed.", "generation_count": archive["generation"]}

if __name__ == "__main__":
    dgm = DGM()
    print("Initializing DGM with base variant...")
    dgm.add_variant("def solve(x): return x + 1", 0.72)
    dgm.add_variant("def solve(x): return x * 2", 0.85)

    print(f"Current Best Score: {dgm.get_best()['performance_score']}")

    print("Generating next generation mutation...")
    res = dgm.mutate_best()
    if "new_variant" in res:
        print(f"New Generation: {res['generation_count']}")
        print(f"New Variant Code:\n{res['new_variant']['code']}")
    else:
        print(f"Mutation error: {res.get('error')}")

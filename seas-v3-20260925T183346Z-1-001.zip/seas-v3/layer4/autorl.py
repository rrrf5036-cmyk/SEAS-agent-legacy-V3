import json
import os
import uuid
from typing import Dict, Any, List, Optional
from pydantic import BaseModel
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from llm_config import chat_completion

class Architecture(BaseModel):
    modules: List[str]
    hyperparameters: Dict[str, Any]

class AutoResearchRL:
    def __init__(self, history_file: str = "layer4/autorl_history.json"):
        self.history_file = history_file
        self._ensure_history_file()

    def _ensure_history_file(self):
        """Ensures the history file exists and contains a valid JSON array."""
        os.makedirs(os.path.dirname(os.path.abspath(self.history_file)), exist_ok=True)
        if not os.path.exists(self.history_file):
            with open(self.history_file, 'w') as f:
                json.dump([], f)
        else:
            try:
                with open(self.history_file, 'r') as f:
                    data = json.load(f)
                    if not isinstance(data, list):
                        with open(self.history_file, 'w') as f2:
                            json.dump([], f2)
            except json.JSONDecodeError:
                with open(self.history_file, 'w') as f:
                    json.dump([], f)

    def calculate_reward(self, current_perf: float, baseline_perf: float) -> float:
        """Calculates the reward based on performance improvement."""
        # Simple reward: difference between current and baseline
        # Could be enhanced to include complexity penalties
        return current_perf - baseline_perf

    def search_step(self, 
                    current_architecture: Architecture, 
                    performance_metrics: Dict[str, float],
                    baseline_performance: float) -> Dict[str, Any]:
        """
        Performs one RL search step to propose a new architecture.
        """
        prompt = f"""
        You are an RL agent searching for better architectures.
        
        Current Architecture:
        {current_architecture.model_dump_json(indent=2)}
        
        Current Performance Metrics:
        {json.dumps(performance_metrics, indent=2)}
        
        Baseline Performance (accuracy/score): {baseline_performance}
        
        Available Actions:
        - add_module
        - remove_module
        - swap_module
        - adjust_hyperparams
        
        Propose a new architecture and the action taken to get there.
        Return a valid JSON object with the following structure exactly (no markdown formatting):
        {{
            "action_taken": "one of the available actions",
            "new_architecture": {{
                "modules": ["list", "of", "module", "names"],
                "hyperparameters": {{"key": "value"}}
            }},
            "reasoning": "brief explanation"
        }}
        """

        try:
            response = chat_completion([{"role": "user", "content": prompt}])
            
            # Clean up response if it contains markdown JSON blocks
            response_text = response.choices[0].message.content.strip()
            if response_text.startswith("```json"):
                response_text = response_text[7:]
            if response_text.startswith("```"):
                response_text = response_text[3:]
            if response_text.endswith("```"):
                response_text = response_text[:-3]
                
            proposal = json.loads(response_text)
            
            # Calculate reward
            current_perf = performance_metrics.get("accuracy", 0.0)
            reward = self.calculate_reward(current_perf, baseline_performance)
            
            result = {
                "action_taken": proposal["action_taken"],
                "new_architecture": proposal["new_architecture"],
                "reward": reward,
                "architecture_version": str(uuid.uuid4())[:8],
                "reasoning": proposal.get("reasoning", "")
            }
            
            self._save_to_history(result)
            return result
            
        except Exception as e:
            print(f"Error during search step: {e}")
            # Fallback action if LLM fails
            result = {
                "action_taken": "adjust_hyperparams",
                "new_architecture": current_architecture.model_dump(),
                "reward": 0.0,
                "architecture_version": str(uuid.uuid4())[:8],
                "error": str(e)
            }
            self._save_to_history(result)
            return result
            
    def _save_to_history(self, record: Dict[str, Any]):
        """Appends a record to the history file."""
        try:
            with open(self.history_file, 'r') as f:
                history = json.load(f)
            
            history.append(record)
            
            with open(self.history_file, 'w') as f:
                json.dump(history, f, indent=2)
        except Exception as e:
            print(f"Failed to save to history: {e}")

# For testing locally if run directly
if __name__ == "__main__":
    agent = AutoResearchRL("autorl_history.json")
    current = Architecture(modules=["mod1"], hyperparameters={"lr": 0.01})
    metrics = {"accuracy": 0.82}
    print(json.dumps(agent.search_step(current, metrics, 0.80), indent=2))

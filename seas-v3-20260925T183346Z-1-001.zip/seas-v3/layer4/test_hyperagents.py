import pytest
import os
import sys
import json
from unittest.mock import patch, MagicMock

# Add Layer 4 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from hyperagents import Hyperagent

TEST_HYPER_LOG_PATH = "/tmp/test_hyperagent_log.json"

@pytest.fixture
def hyper():
    if os.path.exists(TEST_HYPER_LOG_PATH):
        os.remove(TEST_HYPER_LOG_PATH)
    return Hyperagent(log_path=TEST_HYPER_LOG_PATH)

def test_initial_hyper_state(hyper):
    history = [{"generation": 1, "best_score": 0.5}]
    res = hyper.analyze_evolution(history)

    assert res["hyperagent_generation"] == 1
    assert "strategy" in res["meta_strategy"].lower()

@patch("requests.post")
def test_meta_modification(mock_post, hyper):
    # Mock Gemini response for meta-strategy
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{
            "message": {
                "content": json.dumps({
                    "meta_strategy": "Shift DGM mutation to focus on modularity.",
                    "modified_mechanism": "DGM.mutate_best with modularity priority",
                    "effectiveness_score": 0.88
                })
            }
        }]
    }
    mock_post.return_value = mock_response

    evolution_history = [
        {"gen": 1, "score": 0.4},
        {"gen": 2, "score": 0.41}, # Stagnation
        {"gen": 3, "score": 0.405}
    ]

    res = hyper.propose_meta_improvement(evolution_history)

    assert "modularity" in res["meta_strategy"].lower()
    assert res["effectiveness_score"] == 0.88
    # Generation increments on call
    assert res["hyperagent_generation"] == 2
    mock_post.assert_called_once()

def test_three_level_logic(hyper):
    # Level 1: Task completion
    # Level 2: DGM improving task completion
    # Level 3: Hyperagent improving DGM process
    levels = hyper.get_hierarchical_state()
    assert len(levels) == 3
    assert levels[2]["name"] == "Hyper Level (Hyperagent)"

import os
import json
import requests
import uuid
import time
from typing import Dict, Any, List

class ALAS:
    """
    SEAS v3 Layer 4 Module 4.5 - ALAS (Autonomous Learning and Adaptation System)
    Enables an agent's knowledge base to autonomously update itself, detect conflicts,
    and resolve them using confidence-based weighting and Gemini reasoning.
    """
    def __init__(self, kb_path: str = "/home/ajaj/seas-v3/layer4/alas_knowledge.json"):
        self.kb_path = kb_path
        self._ensure_storage()
        self.gemini_url = "http://172.17.0.1:8317/v1/chat/completions"

    def _ensure_storage(self):
        """Initializes the ALAS knowledge base."""
        if not os.path.exists(self.kb_path):
            with open(self.kb_path, 'w') as f:
                json.dump({"version": 0, "entries": []}, f)

    def _load_kb(self) -> Dict[str, Any]:
        """Loads knowledge base data."""
        with open(self.kb_path, 'r') as f:
            return json.load(f)

    def _save_kb(self, kb: Dict[str, Any]):
        """Saves knowledge base data."""
        with open(self.kb_path, 'w') as f:
            json.dump(kb, f, indent=4)

    def update(self, content: str, source: str, confidence: float) -> Dict[str, Any]:
        """
        Autonomously updates the KB, detects conflicts, and resolves them.
        Input: content, source, confidence
        Output: {updated_kb, conflicts_resolved, new_concepts, kb_version}
        """
        kb = self._load_kb()
        kb["version"] += 1

        new_entry = {
            "id": str(uuid.uuid4()),
            "content": content,
            "source": source,
            "confidence": confidence,
            "timestamp": time.time()
        }

        # Check for conflicts with existing knowledge
        conflicts = self._detect_conflicts(kb["entries"], new_entry)
        resolved_conflicts = []
        new_concepts = []

        if conflicts:
            # Resolve conflicts via Gemini reasoning
            resolution = self._resolve_conflicts_llm(conflicts, new_entry)
            resolved_conflicts = resolution.get("conflicts_resolved", [])
            new_concepts = resolution.get("new_concepts", [])

            # Apply resolution (simplified: update the entry content to the resolved version)
            new_entry["content"] = resolution.get("final_kb_entry", content)
            new_entry["resolved_from"] = [c["id"] for c in conflicts]

        kb["entries"].append(new_entry)
        self._save_kb(kb)

        return {
            "updated_kb": kb["entries"],
            "conflicts_resolved": resolved_conflicts,
            "new_concepts": new_concepts,
            "kb_version": kb["version"]
        }

    def get_kb(self) -> List[Dict[str, Any]]:
        """Retrieves all knowledge base entries."""
        return self._load_kb()["entries"]

    def _detect_conflicts(self, existing: List[Dict[str, Any]], entry: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Identifies potential conflicts based on keywords and similarity.
        (Simplified implementation: look for common high-impact keywords)
        """
        conflicts = []
        keywords = set(entry["content"].lower().split())
        for ex in existing:
            ex_keywords = set(ex["content"].lower().split())
            # If significant overlap, mark as potential conflict
            if len(keywords.intersection(ex_keywords)) > 2:
                conflicts.append(ex)
        return conflicts

    def _resolve_conflicts_llm(self, conflicts: List[Dict[str, Any]], new_entry: Dict[str, Any]) -> Dict[str, Any]:
        """Uses Gemini to intelligently resolve information conflicts."""
        payload = {
            "model": "gemini-2.5-flash",
            "messages": [
                {
                    "role": "system",
                    "content": "You are the ALAS Knowledge Conflict Resolver. "
                               "Your task is to compare existing knowledge with new information. "
                               "Detect actual contradictions and resolve them based on confidence and context. "
                               "Output ONLY valid JSON."
                },
                {"role": "user", "content": f"Existing Conflicts:\n{json.dumps(conflicts)}\nNew Entry:\n{json.dumps(new_entry)}"}
            ],
            "response_format": {"type": "json_object"}
        }

        try:
            response = requests.post(self.gemini_url, json=payload, timeout=15)
            if response.status_code == 200:
                return json.loads(response.json()["choices"][0]["message"]["content"])
        except Exception as e:
            print(f"Conflict resolution failed: {str(e)}")

        return {"conflicts_resolved": ["Auto-resolved by highest confidence."], "final_kb_entry": new_entry["content"]}

if __name__ == "__main__":
    alas = ALAS()
    print("Initial Knowledge: The project deadline is Friday (Conf: 0.8)")
    alas.update("The project deadline is Friday.", "Internal", 0.8)

    print("Updating Knowledge: The deadline is moved to Monday (Conf: 0.95)")
    res = alas.update("The project deadline is Monday.", "Manager", 0.95)

    print(f"KB Version: {res['kb_version']}")
    print(f"Conflicts Resolved: {res['conflicts_resolved']}")
    print(f"Latest Knowledge: {res['updated_kb'][-1]['content']}")

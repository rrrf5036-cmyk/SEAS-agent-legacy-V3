import os
import json
import requests
from typing import Dict, Any, List

class Hyperagent:
    """
    SEAS v3 Layer 4 Module 4.3 - Hyperagents
    Implements meta-modification: the improvement mechanism itself evolves.
    Monitors and improves the DGM + Gödel Agent processes.
    """
    def __init__(self, log_path: str = "/home/ajaj/seas-v3/layer4/hyperagent_log.json"):
        self.log_path = log_path
        self._ensure_storage()
        self.gemini_url = "http://172.17.0.1:8317/v1/chat/completions"

    def _ensure_storage(self):
        """Initializes the hyperagent evolutionary log."""
        if not os.path.exists(self.log_path):
            with open(self.log_path, 'w') as f:
                json.dump({"generation": 1, "history": []}, f)

    def _load_log(self) -> Dict[str, Any]:
        """Loads hyperagent data."""
        with open(self.log_path, 'r') as f:
            return json.load(f)

    def _save_log(self, log: Dict[str, Any]):
        """Saves hyperagent data."""
        with open(self.log_path, 'w') as f:
            json.dump(log, f, indent=4)

    def analyze_evolution(self, evolution_history: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analyzes the agent's evolutionary progress and determines if
        the improvement mechanism needs its own upgrade.
        """
        log = self._load_log()
        # Default analysis
        return {
            "hyperagent_generation": log["generation"],
            "meta_strategy": "Maintain existing improvement strategy.",
            "effectiveness_score": 0.5
        }

    def propose_meta_improvement(self, evolution_history: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Hyperagent analyzes stagnation or progress and proposes a meta-strategy.
        Uses Gemini for high-level meta-reasoning.
        """
        log = self._load_log()
        log["generation"] += 1

        payload = {
            "model": "gemini-2.5-flash",
            "messages": [
                {
                    "role": "system",
                    "content": "You are the Hyperagent (Meta-Optimizer). "
                               "Your task is to analyze the evolutionary history of an AI agent "
                               "and propose an improvement to the improvement mechanism (DGM/Gödel Machine) itself. "
                               "This is meta-level optimization. Output ONLY valid JSON."
                },
                {"role": "user", "content": f"Hyperagent Gen: {log['generation']}\nEvolution History:\n{json.dumps(evolution_history)}"}
            ],
            "response_format": {"type": "json_object"}
        }

        try:
            response = requests.post(self.gemini_url, json=payload, timeout=20)
            if response.status_code == 200:
                meta_res = json.loads(response.json()["choices"][0]["message"]["content"])

                # Log the meta-optimization
                history_entry = {
                    "generation": log["generation"],
                    "evolution_context": evolution_history,
                    "meta_strategy": meta_res.get("meta_strategy"),
                    "modified_mechanism": meta_res.get("modified_mechanism"),
                    "effectiveness_score": meta_res.get("effectiveness_score", 0.7)
                }
                log["history"].append(history_entry)
                self._save_log(log)

                return {
                    "meta_strategy": meta_res.get("meta_strategy"),
                    "modified_improvement_mechanism": meta_res.get("modified_mechanism"),
                    "hyperagent_generation": log["generation"],
                    "effectiveness_score": meta_res.get("effectiveness_score", 0.7)
                }
        except Exception as e:
            print(f"Meta-proposal failed: {str(e)}")

        return {"error": "Meta-optimization failed.", "hyperagent_generation": log["generation"]}

    def get_hierarchical_state(self) -> List[Dict[str, str]]:
        """Returns the three levels of the agent evolution hierarchy."""
        return [
            {"level": 1, "name": "Object Level (Agent)", "function": "Solve tasks and execute code."},
            {"level": 2, "name": "Meta Level (DGM)", "function": "Improve Object Level code and logic."},
            {"level": 3, "name": "Hyper Level (Hyperagent)", "function": "Improve Meta Level improvement mechanisms."}
        ]

if __name__ == "__main__":
    hyper = Hyperagent()
    print("Agent Evolution Hierarchy:")
    for level in hyper.get_hierarchical_state():
        print(f"Level {level['level']}: {level['name']} -> {level['function']}")

    # Simulate stagnating evolution
    stagnant_history = [
        {"gen": 10, "score": 0.81},
        {"gen": 11, "score": 0.812},
        {"gen": 12, "score": 0.811}
    ]

    print("\nDetecting stagnation... Proposing meta-level improvement...")
    res = hyper.propose_meta_improvement(stagnant_history)
    print(f"Hyperagent Gen: {res['hyperagent_generation']}")
    print(f"Meta Strategy: {res['meta_strategy']}")
    print(f"Effectiveness: {res['effectiveness_score']}")

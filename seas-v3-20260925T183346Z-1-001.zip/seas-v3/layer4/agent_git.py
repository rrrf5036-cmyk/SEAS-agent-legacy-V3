import os
import json
import requests
import hashlib
import time
from typing import Dict, Any, List

class AgentGit:
    """
    SEAS v3 Layer 4 Module 4.7 - AgentGit
    Provides version control for all agent modifications.
    Supports commit tracking, rollback, and branching for stable vs experimental code.
    """
    def __init__(self, history_path: str = "/home/ajaj/seas-v3/layer4/agent_git_history.json"):
        self.history_path = history_path
        self._ensure_storage()
        self.gemini_url = "http://172.17.0.1:8317/v1/chat/completions"

    def _ensure_storage(self):
        """Initializes the AgentGit history."""
        if not os.path.exists(self.history_path):
            with open(self.history_path, 'w') as f:
                json.dump({"commits": [], "branches": {"stable": None, "experimental": None}}, f)

    def _load_history(self) -> Dict[str, Any]:
        """Loads history data."""
        with open(self.history_path, 'r') as f:
            return json.load(f)

    def _save_history(self, history: Dict[str, Any]):
        """Saves history data."""
        with open(self.history_path, 'w') as f:
            json.dump(history, f, indent=4)

    def commit(self, code: str, reason: str, branch: str = "stable") -> Dict[str, Any]:
        """
        Commits a modification with a version hash and summary.
        Input: code, reason, branch
        Output: {commit_hash, version, rollback_available, diff_summary, modification_history}
        """
        history = self._load_history()
        now = time.time()
        commit_hash = hashlib.sha256(f"{code}{reason}{now}".encode()).hexdigest()

        # Get previous code for diff analysis
        prev_commit_hash = history["branches"].get(branch)
        prev_code = "None"
        if prev_commit_hash:
            prev_commit = next((c for c in history["commits"] if c["hash"] == prev_commit_hash), None)
            if prev_commit:
                prev_code = prev_commit["code"]

        # Summarize diff via Gemini
        diff_summary = self._summarize_diff(prev_code, code, reason)

        # Create new commit
        new_commit = {
            "hash": commit_hash,
            "version": len(history["commits"]) + 1,
            "code": code,
            "reason": reason,
            "branch": branch,
            "timestamp": now,
            "diff_summary": diff_summary,
            "parent": prev_commit_hash
        }

        history["commits"].append(new_commit)
        history["branches"][branch] = commit_hash

        self._save_history(history)

        return {
            "commit_hash": commit_hash,
            "version": new_commit["version"],
            "rollback_available": prev_commit_hash is not None,
            "diff_summary": diff_summary,
            "modification_history": len(history["commits"])
        }

    def rollback(self, version: int, branch: str = "stable") -> Dict[str, Any]:
        """Reverts the branch to a specific version number."""
        history = self._load_history()
        target_commit = next((c for c in history["commits"] if c["version"] == version), None)

        if not target_commit:
            return {"success": False, "error": f"Version {version} not found."}

        # Update branch pointer
        history["branches"][branch] = target_commit["hash"]
        self._save_history(history)

        return {"success": True, "reverted_to": target_commit["hash"], "version": version}

    def get_current_code(self, branch: str = "stable") -> str:
        """Retrieves the latest code for a given branch."""
        history = self._load_history()
        commit_hash = history["branches"].get(branch)
        if not commit_hash:
            return ""

        commit = next((c for c in history["commits"] if c["hash"] == commit_hash), None)
        return commit["code"] if commit else ""

    def _summarize_diff(self, old_code: str, new_code: str, reason: str) -> str:
        """Uses Gemini to summarize the changes between code versions."""
        if old_code == "None":
            return "Initial version commit."

        payload = {
            "model": "gemini-2.5-flash",
            "messages": [
                {
                    "role": "system",
                    "content": "You are the AgentGit Diff Summarizer. "
                               "Summarize the key changes between the two code versions. "
                               "Explain WHY the modification was made based on the provided reason."
                },
                {"role": "user", "content": f"Reason: {reason}\nOld Code:\n{old_code}\nNew Code:\n{new_code}"}
            ]
        }

        try:
            response = requests.post(self.gemini_url, json=payload, timeout=15)
            if response.status_code == 200:
                return response.json()["choices"][0]["message"]["content"]
        except Exception:
            return f"Modification for: {reason}"
        return f"Modification for: {reason}"

if __name__ == "__main__":
    agent_git = AgentGit()
    print("Initial Versioning...")
    agent_git.commit("def brain(): pass", "Initial architecture setup.")

    print("\nModifying code on stable...")
    res = agent_git.commit("def brain(): return 'Optimized logic'", "Performance optimization.")
    print(f"Commit Hash: {res['commit_hash']}")
    print(f"Diff Summary: {res['diff_summary']}")

    print("\nExperimental Branch...")
    agent_git.commit("def brain(): return 'Experimental Neural Architecture'", "Testing high-risk changes", branch="experimental")
    print(f"Experimental Code: {agent_git.get_current_code(branch='experimental')}")

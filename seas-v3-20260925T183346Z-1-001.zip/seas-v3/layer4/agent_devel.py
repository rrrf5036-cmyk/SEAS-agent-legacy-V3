import os
import json
import requests
import time
from typing import Dict, Any, List

class AgentDevel:
    """
    SEAS v3 Layer 4 Module 4.8 - AgentDevel
    Stable release management for agent updates.
    Ensures safe and stable deployment through a multi-stage pipeline.
    Based on: Dry-Run Harness pattern from agentic-architectures.md
    """
    def __init__(self, log_path: str = "/home/ajaj/seas-v3/layer4/release_log.json"):
        self.log_path = log_path
        self._ensure_storage()
        self.gemini_url = "http://172.17.0.1:8317/v1/chat/completions"

    def _ensure_storage(self):
        """Initializes the release log."""
        if not os.path.exists(self.log_path):
            with open(self.log_path, 'w') as f:
                json.dump([], f)

    def _load_log(self) -> List[Dict[str, Any]]:
        """Loads release history."""
        with open(self.log_path, 'r') as f:
            return json.load(f)

    def _save_log(self, log: List[Dict[str, Any]]):
        """Saves release history."""
        with open(self.log_path, 'w') as f:
            json.dump(log, f, indent=4)

    def deploy(self, proposed_update: str, change_reason: str) -> Dict[str, Any]:
        """
        Deploys a proposed update through a safety-gated pipeline.
        Input: proposed_update, change_reason
        Output: {approved, risk_score, release_version, staging_status, blockers}
        """
        # Step 1: Automated Risk Assessment via Gemini
        assessment = self._assess_risk(proposed_update, change_reason)
        risk_score = assessment.get("risk_score", 0.9) # High default risk if analysis fails
        blockers = assessment.get("blockers", [])

        log = self._load_log()
        next_version = len(log) + 1

        # Step 2: Gating Checks
        # Gate: Risk score threshold (0.7)
        if risk_score > 0.7:
            return {
                "approved": False,
                "risk_score": risk_score,
                "release_version": next_version,
                "staging_status": "blocked",
                "blockers": blockers + ["Risk score exceeds the 0.7 threshold."]
            }

        # Step 3: Deployment Pipeline (Simulation: Dev -> Staging -> Prod)
        staging_status = "production" # Success

        # Step 4: Final Logging
        self._log_release(f"v{next_version}", risk_score, True, assessment.get("reasoning", "Standard update."))

        return {
            "approved": True,
            "risk_score": risk_score,
            "release_version": next_version,
            "staging_status": staging_status,
            "blockers": []
        }

    def get_releases(self) -> List[Dict[str, Any]]:
        """Retrieves history of releases."""
        return self._load_log()

    def _assess_risk(self, update: str, reason: str) -> Dict[str, Any]:
        """Uses Gemini to intelligently assess the risk of a proposed code update."""
        payload = {
            "model": "gemini-2.5-flash",
            "messages": [
                {
                    "role": "system",
                    "content": "You are the AgentDevel Risk Assessment Engine. "
                               "Your task is to analyze proposed code updates and assign a risk score (0-1). "
                               "Check for potential infinite loops, safety violations, performance regressions, "
                               "and overall code stability. Output ONLY valid JSON."
                },
                {"role": "user", "content": f"Reason: {reason}\nProposed Code Update:\n{update}"}
            ],
            "response_format": {"type": "json_object"}
        }

        try:
            response = requests.post(self.gemini_url, json=payload, timeout=20)
            if response.status_code == 200:
                return json.loads(response.json()["choices"][0]["message"]["content"])
        except Exception as e:
            print(f"Risk assessment failed: {str(e)}")

        return {"risk_score": 0.8, "blockers": ["Automated analysis failed."]}

    def _log_release(self, version: str, risk: float, status: bool, detail: str):
        """Logs a deployment or blocking event in history."""
        log = self._load_log()
        log.append({
            "version": version,
            "risk_score": risk,
            "approved": status,
            "detail": detail,
            "timestamp": time.time()
        })
        self._save_log(log)

if __name__ == "__main__":
    devel = AgentDevel()
    print("Simulating stable deployment...")
    res = devel.deploy("def clean_cache(): return True", "Minor housekeeping")
    print(f"Version: {res['release_version']} | Approved: {res['approved']} | Status: {res['staging_status']}")

    print("\nSimulating risky deployment...")
    risky_res = devel.deploy("os.system('rm -rf /')", "Radical system restructuring")
    print(f"Approved: {risky_res['approved']} | Blockers: {risky_res['blockers']}")

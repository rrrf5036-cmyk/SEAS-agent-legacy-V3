import pytest
import os
import sys
import json

# Add Layer 4 to path
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "layer4"))
from evolution_controller import EvolutionController

@pytest.fixture
def controller():
    # Setup paths for testing
    log_path = "/tmp/test_evolution_log.json"
    skill_path = "/tmp/test_skills_library.json"

    # Clean up before
    if os.path.exists(log_path): os.remove(log_path)
    if os.path.exists(skill_path): os.remove(skill_path)

    # Re-initialize to use test paths
    from godel_machine import GodelMachine
    from autoskill import AutoSkill

    ctrl = EvolutionController()
    ctrl.godel = GodelMachine(log_path=log_path)
    ctrl.autoskill = AutoSkill(skill_path=skill_path)
    return ctrl

def test_evolution_step(controller):
    # Test task and result
    task = "Write a Python script to sort a list of numbers."
    result = "def sort_list(l): return sorted(l)"
    trajectory = [{"input": task, "output": result, "confidence": 0.95}]

    # Run evolution step
    evolution_result = controller.step_evolution(task, result, trajectory)

    # Check Godel analysis
    assert "suggested_logic_change" in evolution_result["suggested_improvement"]

    # Skill learning check - ensure directory exists at least
    assert os.path.isdir(os.path.dirname(controller.autoskill.skill_path))

def test_skill_retrieval(controller):
    # Add a skill manually to the test library
    skill = {
        "skill_name": "sortingLogic",
        "description": "Standard list sorting logic",
        "tools": []
    }
    controller.autoskill.skills["library"].append(skill)
    controller.autoskill._save_skills()

    # Retrieve relevant skills
    skills = controller.autoskill.get_relevant_skills("How to do sorting?")
    assert len(skills) > 0
    assert skills[0]["skill_name"] == "sortingLogic"

import pytest
import os
import sys
import json
from unittest.mock import patch, MagicMock

# Add Layer 4 to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from metacog_learning import MetacognitiveLearning

TEST_METACOG_LOG_PATH = "/tmp/test_metacog_log.json"

@pytest.fixture
def metacog():
    if os.path.exists(TEST_METACOG_LOG_PATH):
        os.remove(TEST_METACOG_LOG_PATH)
    return MetacognitiveLearning(log_path=TEST_METACOG_LOG_PATH)

def test_initial_log_empty(metacog):
    assert len(metacog.get_log()) == 0

@patch("requests.post")
def test_evaluate_improving_strategy(mock_post, metacog):
    # Mock Gemini response for improving strategy
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{
            "message": {
                "content": json.dumps({
                    "current_strategy": "Few-shot exploration",
                    "strategy_score": 0.9,
                    "recommended_adjustment": "Maintain current strategy, gradually increase complexity.",
                    "metacog_insight": "Learning is improving steadily. Trend is positive."
                })
            }
        }]
    }
    mock_post.return_value = mock_response

    history = [{"epoch": 1, "loss": 0.5}, {"epoch": 2, "loss": 0.3}]
    trend = "Improving: Error rate decreasing"

    res = metacog.evaluate_strategy(history, trend)

    assert res["current_strategy"] == "Few-shot exploration"
    assert res["strategy_score"] == 0.9
    assert "Maintain current strategy" in res["recommended_adjustment"]
    assert "improving" in res["metacog_insight"].lower()
    mock_post.assert_called_once()

    # Check that log was written
    logs = metacog.get_log()
    assert len(logs) == 1
    assert logs[0]["strategy_score"] == 0.9

@patch("requests.post")
def test_evaluate_plateauing_strategy(mock_post, metacog):
    # Mock Gemini response for plateauing strategy
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{
            "message": {
                "content": json.dumps({
                    "current_strategy": "Greedy search",
                    "strategy_score": 0.4,
                    "recommended_adjustment": "Switch to exploratory search. Introduce random variations.",
                    "metacog_insight": "Learning has plateaued. Current strategy is trapped in a local minimum."
                })
            }
        }]
    }
    mock_post.return_value = mock_response

    history = [{"epoch": 1, "loss": 0.2}, {"epoch": 2, "loss": 0.2}, {"epoch": 3, "loss": 0.21}]
    trend = "Plateau: Error rate stable"

    res = metacog.evaluate_strategy(history, trend)

    assert res["current_strategy"] == "Greedy search"
    assert res["strategy_score"] == 0.4
    assert "Switch to exploratory search" in res["recommended_adjustment"]
    assert "plateaued" in res["metacog_insight"].lower()

def test_evaluate_strategy_api_failure(metacog):
    # Test fallback behavior when API fails without mocking
    # Note: Assuming gemini endpoint at 172.17.0.1 won't respond with right schema instantly in test
    with patch("requests.post") as mock_post:
        mock_post.side_effect = Exception("API Error")

        res = metacog.evaluate_strategy([], "unknown")

        assert "Unknown" in res["current_strategy"]
        assert res["strategy_score"] == 0.5
        assert "Manual intervention" in res["recommended_adjustment"]

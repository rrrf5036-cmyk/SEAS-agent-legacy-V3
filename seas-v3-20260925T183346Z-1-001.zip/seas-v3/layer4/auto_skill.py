import os
import json
import requests
import uuid
import time
from typing import Dict, Any, List

class AutoSkill:
    """
    SEAS v3 Layer 4 Module 4.6 - AutoSkill
    Enables lifelong skill evolution from interactions.
    Automatically extracts and refines skills based on task experience and feedback.
    """
    def __init__(self, skill_path: str = "/home/ajaj/seas-v3/layer4/skill_library.json"):
        self.skill_path = os.path.abspath(skill_path)
        self._ensure_storage()
        self.gemini_url = "http://172.17.0.1:8317/v1/chat/completions"

    def _ensure_storage(self):
        """Initializes the AutoSkill library."""
        os.makedirs(os.path.dirname(self.skill_path), exist_ok=True)
        if not os.path.exists(self.skill_path):
            with open(self.skill_path, 'w') as f:
                json.dump([], f)

    def _load_library(self) -> List[Dict[str, Any]]:
        """Loads skill library data."""
        with open(self.skill_path, 'r') as f:
            return json.load(f)

    def _save_library(self, lib: List[Dict[str, Any]]):
        """Saves skill library data."""
        with open(self.skill_path, 'w') as f:
            json.dump(lib, f, indent=4)

    def evolve(self, interaction_log: Dict[str, Any]) -> Dict[str, Any]:
        """
        Learns and refines skills from a completed interaction.
        Input: interaction_log (task, outcome, feedback)
        Output: {new_skills_learned, skill_library, skill_confidence, total_skills}
        """
        library = self._load_library()
        new_skills_learned = []

        # Skill Extraction via Gemini
        payload = {
            "model": "gemini-2.5-flash",
            "messages": [
                {
                    "role": "system",
                    "content": "You are the AutoSkill Engine (Lifelong Skill Evolution). "
                               "Your task is to identify and extract reusable skills from the "
                               "provided interaction log (task + outcome + feedback). "
                               "Each skill must have a name, description, and trigger condition. "
                               "Output valid JSON matching the specified format."
                },
                {"role": "user", "content": f"Interaction Log:\n{json.dumps(interaction_log)}"}
            ],
            "response_format": {"type": "json_object"}
        }

        try:
            response = requests.post(self.gemini_url, json=payload, timeout=20)
            if response.status_code == 200:
                skill_res = json.loads(response.json()["choices"][0]["message"]["content"])
                for s in skill_res.get("new_skills", []):
                    # Check if skill already exists (by name)
                    existing = next((sk for sk in library if sk["name"] == s["name"]), None)
                    if not existing:
                        new_skill = {
                            "id": str(uuid.uuid4()),
                            "name": s["name"],
                            "description": s["description"],
                            "trigger": s["trigger"],
                            "success_rate": 1.0, # initial assumption
                            "usage_count": 1,
                            "last_used": time.time()
                        }
                        library.append(new_skill)
                        new_skills_learned.append(new_skill)
                    else:
                        self.record_usage(s["name"], success=True) # If it's the same, it worked!

                self._save_library(library)
        except Exception as e:
            print(f"Skill evolution failed: {str(e)}")

        return {
            "new_skills_learned": new_skills_learned,
            "skill_library": library,
            "skill_confidence": 0.9, # heuristic confidence
            "total_skills": len(library)
        }

    def record_usage(self, skill_name: str, success: bool = True):
        """Records a skill usage and updates its success rate."""
        library = self._load_library()
        for skill in library:
            if skill["name"] == skill_name:
                skill["usage_count"] += 1
                skill["last_used"] = time.time()
                # Update success rate: (current_rate * (count-1) + result) / count
                result = 1.0 if success else 0.0
                skill["success_rate"] = (skill["success_rate"] * (skill["usage_count"] - 1) + result) / skill["usage_count"]
                break
        self._save_library(library)

    def get_total_skills(self) -> int:
        return len(self._load_library())

    def get_library(self) -> List[Dict[str, Any]]:
        return self._load_library()

    def _add_manual_skill(self, name: str, description: str, trigger: str):
        """Manually adds a skill for testing or initialization."""
        library = self._load_library()
        if not any(s["name"] == name for s in library):
            library.append({
                "id": str(uuid.uuid4()),
                "name": name,
                "description": description,
                "trigger": trigger,
                "success_rate": 1.0,
                "usage_count": 1,
                "last_used": time.time()
            })
            self._save_library(library)

if __name__ == "__main__":
    autoskill = AutoSkill()
    print("Initial Library Count:", autoskill.get_total_skills())

    interaction = {
        "task": "Develop a custom scraper for e-commerce sites with anti-bot detection bypass.",
        "outcome": "Scraper built successfully, bypasses 98% of Cloudflare/Datadome blocks.",
        "feedback": "Outstanding performance on security-heavy targets."
    }

    print("Evolving based on interaction...")
    res = autoskill.evolve(interaction)
    print(f"New Skills Learned: {len(res['new_skills_learned'])}")
    for s in res['new_skills_learned']:
        print(f"- {s['name']}: {s['description']}")
    print(f"Total Skills: {res['total_skills']}")
